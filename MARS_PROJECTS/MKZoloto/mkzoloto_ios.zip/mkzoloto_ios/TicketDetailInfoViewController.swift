
import UIKit
import Cartography

class TicketDetailInfoViewController: UIViewController {
    
    lazy var scrollView : UIScrollView = {
        let view = UIScrollView()
        view.isScrollEnabled = true
        view.showsVerticalScrollIndicator = false
        view.contentSize = CGSize(width: UIScreen.main.bounds.width, height: 1000)
        //        scrollView.delegate = self
        view.bounces = false
        return view
    }()
    
    lazy var whiteView : UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 4
        return view
    }()
    
    lazy var dolg : UILabel = {
        let label = UILabel()
        label.text = "Задолженность"
        label.adjustsFontSizeToFitWidth = true
        label.label15Properties()
        return label
    }()
    
    lazy var dolgNum : UILabel = {
        let label = UILabel()
        label.text = "10000 тг"
        label.textAlignment = .right
        label.adjustsFontSizeToFitWidth = true
        label.label15Properties()
        return label
    }()
    
    lazy var percent : UILabel = {
        let label = UILabel()
        label.text = "Процент за просрочку"
        label.adjustsFontSizeToFitWidth = true
        label.label15Properties()
        return label
    }()
    
    lazy var percentNum : UILabel = {
        let label = UILabel()
        label.text = "12% ~ 1200 тг"
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .right
        label.label15Properties()
        return label
    }()
    
    lazy var reward : UILabel = {
        let label = UILabel()
        label.text = "Вознаграждение"
        label.adjustsFontSizeToFitWidth = true
        label.label15Properties()
        return label
    }()
    
    lazy var rewardNum : UILabel = {
        let label = UILabel()
        label.text = "1000 тг"
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .right
        label.label15Properties()
        return label
    }()
    
    lazy var standartTime : UILabel = {
        let label = UILabel()
        label.text = "Стандартный срок"
        label.adjustsFontSizeToFitWidth = true
        label.label15Properties()
        return label
    }()
    
    lazy var standartTimeDate : UILabel = {
        let label = UILabel()
        label.text = "до 13.08.19"
        label.textAlignment = .right
        label.adjustsFontSizeToFitWidth = true
        label.label15Properties()
        return label
    }()
    
    lazy var guarantTime : UILabel = {
        let label = UILabel()
        label.text = "Гарантированный срок"
        label.adjustsFontSizeToFitWidth = true
        label.label15Properties()
        return label
    }()
    
    lazy var guarantTimeDate : UILabel = {
        let label = UILabel()
        label.text = "до 13.08.19"
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .right
        label.label15Properties()
        return label
    }()
    
    lazy var filial : UILabel = {
       let label = UILabel()
        label.text = "Филиал получения займа"
        label.adjustsFontSizeToFitWidth = true
        label.label15Properties()
        return label
    }()
    
    lazy var filialDetails : UILabel = {
        let label = UILabel()
        label.text = "Алматы, 754 Leatha Extensions Suite 310 \n+7(747)9998877 \nОткрыто до 23:00"
        label.numberOfLines = 0
        label.label15Properties()
        return label
    }()
    
    lazy var lastOperation : UILabel = {
        let label = UILabel()
        label.text = "Последняя операция по займу".uppercased()
        label.label13Properties()
        return label
    }()
    
    lazy var secondWhiteView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    
    private lazy var menuTableView: UITableView = {
        let tableView = UITableView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 132))
        tableView.delegate   = self
        tableView.dataSource = self
        tableView.isScrollEnabled = false
        tableView.register(TicketDetailTableViewCell.self, forCellReuseIdentifier: "cell")
        return tableView
    }()
    
    var summa = "32000"
    var addr = "Филиал №1233, Бостандыкский район, Алматы, 050057/Малоэтажный жилой дом, 4 этажа"
    
    
    lazy var prodlit : UIButton = {
        let button = UIButton()
        button.blueBtnProperty()
        button.setTitle("Продлить", for: UIControl.State.normal)
        button.addTarget(self, action: #selector(prodlitButton), for: .touchUpInside)
        return button
    }()
    
    lazy var oplatit : UIButton = {
        let button = UIButton()
        button.blueBtnProperty()
        button.setTitle("Оплатить", for: UIControl.State.normal)
        return button
    }()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        setupButtons()
        setConstraints()
        self.view.backgroundColor = UIColor(rgb: 0xE4F1FD)
        
        navigationItem.title = "№120993"
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tabBarController?.tabBar.isHidden = true
    }
    
}


extension TicketDetailInfoViewController {
    func setupButtons(){

        self.view.addSubview(scrollView)
        
        self.scrollView.addSubviews([whiteView, dolg, dolgNum, percent, percentNum, reward, rewardNum, standartTime, standartTimeDate, guarantTime, guarantTimeDate, filial, filialDetails, lastOperation, menuTableView, prodlit, oplatit])
    }
    
    @objc func prodlitButton() {
        let vc = FastExtensionViewController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
}



extension TicketDetailInfoViewController {
    func setConstraints() {
        constrain(scrollView, whiteView, dolg, dolgNum, percent, percentNum, reward, rewardNum) { scrollView, whiteView, dolg, dolgNum, percent, percentNum, reward, rewardNum in
            
            scrollView.top    == scrollView.superview!.top
            scrollView.left   == scrollView.superview!.left
            scrollView.right  == scrollView.superview!.right
            scrollView.bottom == scrollView.superview!.bottom
            
            whiteView.top    == scrollView.top + 16
            whiteView.left   == scrollView.superview!.left + 8
            whiteView.right  == scrollView.superview!.right - 8
            whiteView.height == 308
            
            dolg.top     == whiteView.top + 12
            dolg.left    == whiteView.left + 12
            dolg.height  == 20
            
            dolgNum.top    == dolg.top
            dolgNum.right  == whiteView.right - 12
            dolgNum.height == 20
            dolgNum.left   == dolg.right
            
            percent.top     == dolg.bottom + 16
            percent.left    == whiteView.left + 12
            percent.height  == 20
            
            percentNum.top    == percent.top
            percentNum.right  == dolgNum.right
            percentNum.height == 20
            percentNum.left   == percent.right
            
            reward.top     == percent.bottom + 16
            reward.left    == whiteView.left + 12
            reward.height  == 20
            
            rewardNum.top    == reward.top
            rewardNum.right  == dolgNum.right
            rewardNum.height == 20
            rewardNum.left   == reward.right
        }
        
        
        constrain (reward, whiteView, standartTime, guarantTime, filial, standartTimeDate, guarantTimeDate, filialDetails) { reward, whiteView, standartTime, guarantTime, filial, standartTimeDate, guarantTimeDate, filialDetails in
            
            standartTime.top     == reward.bottom + 12
            standartTime.left    == whiteView.left + 12
            standartTime.height  == 20
            
            standartTimeDate.top    == standartTime.top
            standartTimeDate.right  == whiteView.right - 12
            standartTimeDate.height == 20
            standartTimeDate.left   == standartTime.right
            
            guarantTime.top     == standartTime.bottom + 12
            guarantTime.left    == whiteView.left + 12
            guarantTime.height  == 20
            
            guarantTimeDate.top    == guarantTime.top
            guarantTimeDate.right  == standartTimeDate.right
            guarantTimeDate.height == 20
            guarantTimeDate.left   == guarantTime.right
            
            filial.top     == guarantTime.bottom + 12
            filial.left    == whiteView.left + 12
            filial.bottom  == whiteView.bottom - 96
            filial.height  == 20
            
            filialDetails.top    == filial.bottom + 8
            filialDetails.right  == whiteView.right - 16
            //            filialDetails.height == 58
            filialDetails.left   == whiteView.left + 20
            filialDetails.bottom == whiteView.bottom - 5
            
            
        }
        
        constrain(scrollView, whiteView, lastOperation, menuTableView, prodlit, oplatit ) { scrollView, whiteView, lastOperation, secondWhiteView, prodlit, oplatit in
            
            lastOperation.top    == whiteView.bottom + 32
            lastOperation.left   == scrollView.superview!.left + 16
            lastOperation.right  == scrollView.superview!.right
            
            secondWhiteView.top    == lastOperation.bottom + 8
            secondWhiteView.left   == scrollView.superview!.left
            secondWhiteView.right  == scrollView.superview!.right
            secondWhiteView.height == 131
            
            prodlit.top     == secondWhiteView.bottom + 32
            prodlit.left    == oplatit.left
            prodlit.right   == oplatit.right
            prodlit.bottom  == oplatit.top - 8
            prodlit.height  == 44
            
            oplatit.left   == scrollView.superview!.left + 16
            oplatit.right  == scrollView.superview!.right - 16
            oplatit.bottom == scrollView.bottom - 20
            oplatit.height == 44
        }
    }
}


extension TicketDetailInfoViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        
    }
}



extension TicketDetailInfoViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TicketDetailTableViewCell
        cell.setUpDetails(image: "checked", title: "16:11 | 12.09.2018 ", secondTitle: "Сумма к оплате: \(summa) тг", thirdTitle: addr)
        return cell
        
    }
    
    // MARK - Настройка Header
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
}
