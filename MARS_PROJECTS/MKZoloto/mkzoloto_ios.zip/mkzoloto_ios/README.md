#Project MKZoloto

### Installing

```
git clone https://gitlab.mars.studio/root/mkzoloto_ios.git
```

```
pod install
```

## Running the project

open .xcworkspace file and run 

