

import Foundation
import UIKit

/**
 MainTableViewCellTypes
 */
enum MainTableViewCellTypes: Int {
    /// - defaultType: Default type of cell with textLabel
    case defaultType
    /// - goldenType: Cell with Collection view that displays main gold contents
    case goldenType
    /// - calculatorCell: Cell with picker view
    case calculatorType
}

enum CalculatorType: Int {
    
    case goldSample
    
    case goldWeight
    
    case loanTerm
    
}

extension MainViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return MainTableViewCellTypes.calculatorType.rawValue + 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        /// TODO this with enum cases with understandable types
        
        guard let sectionType = MainTableViewCellTypes(rawValue: section) else {
            return 0
        }
        
        switch sectionType {
        case .defaultType:
            return 1
        case .goldenType:
            return 1
        case .calculatorType:
            return (self.mainViewModel.calculatorViewModel.data.count == 0) ? 0 : self.mainViewModel.calculatorViewModel.data.count + 1
        }
        
    }
    
    fileprivate func setExpressCell(_ cell: UITableViewCell) {
        
        cell.accessoryType = .disclosureIndicator
        cell.textLabel?.text = "Экспресс продление".localized()
        cell.textLabel?.font = Global.stroke(size: StaticSize.s14)
        
        cell.contentView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(Constants.s16)
            make.right.equalToSuperview().offset(-Constants.s16)
            make.top.bottom.equalToSuperview()
        }
        
        cell.backgroundColor = .clear
        cell.contentView.backgroundColor = .white
        cell.contentView.cornerRadius = 5
        
        cell.imageView?.image = #imageLiteral(resourceName: "fly")
        cell.accessoryView = UIImageView(image: #imageLiteral(resourceName: "right_arrow"))
        cell.imageView?.snp.makeConstraints({ (make) in
            make.left.equalToSuperview().offset(Constants.s16 / 2)
            make.centerY.equalToSuperview()
        })
        
        cell.textLabel?.snp.makeConstraints({ (make) in
            make.left.equalTo(cell.imageView?.snp.right ?? 0).offset(Constants.s16 / 2)
            make.centerY.equalToSuperview()
        })
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
//        MARK: TODO cell configure
        guard let sectionType = MainTableViewCellTypes(rawValue: indexPath.section) else {
            return UITableViewCell()
        }
        
        switch sectionType {
        case .defaultType:
            let cell = UITableViewCell(style: .value1, reuseIdentifier: String(describing: UITableViewCell.self))
            cell.selectionStyle = .none
            setExpressCell(cell)
            
            return cell
        case .goldenType:
            let cell = tableView.dequeueReusableCell(withClass: GoldContentCell.self, for: indexPath)
            cell.mainViewModel = self.mainViewModel
            cell.selectionStyle = .none
            return cell
        case .calculatorType:
            
            switch indexPath.row {
            case 0:
                return goldSampleCalculatorCell
            case 1:
                return goldWeightCalculatorCell
            case 2:
                return loanTermCalculatorCell
            default:
                return amountTableViewCell
            }
        }
    
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        
        guard let sectionType = MainTableViewCellTypes(rawValue: indexPath.section) else {
            return ()
        }
        switch sectionType {
        case .defaultType:
            let vc = FastExtensionViewController()
            self.navigationController?.pushViewController(vc, animated: true)
        default:
            break
        }
    }
    
}

extension MainViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        guard let sectionType = MainTableViewCellTypes(rawValue: indexPath.section) else {
            return UITableView.automaticDimension
        }
        
        switch sectionType {
        case .goldenType:
            return StaticSize.s80
        case .calculatorType:
            if (indexPath.row == 3) {
                return StaticSize.s100
            }
            return 52
        default:
            return UITableView.automaticDimension
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        if (section == 2) {
            Constants.mainViewSectionOffset = Constants.s16
        } else {
            Constants.mainViewSectionOffset = 0
        }
        
        let headerView = TableSectionHeaderView()
        
        guard let sectionType = MainTableViewCellTypes(rawValue: section) else {
            return UIView()
        }
        
        if (section == 2) {
            headerView.bgView.layer.cornerRadius = 5
            if #available(iOS 11.0, *) {
                headerView.bgView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
            } else {
                
            }
            headerView.bgView.clipsToBounds = true
        }
        headerView.titleLabel.font = Global.stroke(size: StaticSize.s17)
        switch sectionType {
        case .goldenType:
            let date = Date()
            let formatter = DateFormatter()
            formatter.dateFormat = "dd.MM.yyyy"
            let result = formatter.string(from: date)
            headerView.titleLabel.text = "НАША РАСЦЕНКА НА".localized() + " \(result)"
        case .calculatorType:
            headerView.titleLabel.text = "Посчитаем?".localized()
        default:
            return nil
        }
        
        return headerView
        
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if (section == 3) {
            return 0
        } else if (section == 0) {
            return 8
        } else {
            return StaticSize.s50
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        if section == 0 {
            return StaticSize.s8
        }
        return StaticSize.s16
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        guard let sectionType = MainTableViewCellTypes(rawValue: indexPath.section) else {
            return
        }
        
        cell.layoutIfNeeded()
        /**
         Adding top border separater for .defaultType and .detailedType cells
         */
        switch sectionType {
        case .calculatorType:
            if (indexPath.row == 3) {
                let imageview = UIImageView(image: #imageLiteral(resourceName: "Path 2"))
                let view = UIView()
                view.frame = CGRect(x: StaticSize.s16*2, y: 0, width: cell.bounds.width - StaticSize.s16*4, height: StaticSize.s12 + 1)
                imageview.frame = CGRect(x: 0, y: StaticSize.s12, width: view.width, height: 1)
                view.addSubview(imageview)
                cell.addSubview(view)
            }
        default: break
        }
        
    }
    
}
