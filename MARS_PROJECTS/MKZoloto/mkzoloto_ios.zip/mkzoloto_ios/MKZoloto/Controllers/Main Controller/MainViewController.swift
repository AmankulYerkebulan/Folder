
import UIKit
import SnapKit
import RxSwift
import FSPagerView
import SVProgressHUD

class MainViewController: UIViewController {
    
//    MARK: Properties
    var disposeBag = DisposeBag()
    
//    View Model
    var mainViewModel = MainViewModel()
    
    var stocks = [
        (title: "Акция 1", url: URL(string: "https://www.mk-zoloto-lombard.kz/smartscales")),
        (title: "Акция 2", url: URL(string: "https://www.mk-zoloto-lombard.kz/noscratches"))
    ]

    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.tableHeaderView = tableHeaderView
        
        tableView.register(cellWithClass: GoldContentCell.self)
        tableView.register(cellWithClass: CalculatorCellForMain.self)
        tableView.register(cellWithClass: UITableViewCell.self)
        tableView.register(headerFooterViewClassWith: TableSectionHeaderView.self)
        tableView.register(cellWithClass: AmountTableViewCell.self)
        
        tableView.separatorStyle = .none
        
        tableView.delegate      = self
        tableView.dataSource    = self
        return tableView
    }()
    
    let pager = FSPageControl()
    
    lazy var tableHeaderView: FSPagerView = {
        
        let view = FSPagerView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: StaticSize.s100))
        view.register(FSPagerViewCell.self, forCellWithReuseIdentifier: "pagerCell")
        
        view.delegate = self
        view.dataSource = self
        
        view.addSubview(pager)
        
        pager.snp.makeConstraints({ (make) in
            make.left.bottom.right.equalToSuperview()
            make.height.equalTo(Constants.s16)
        })
        
        pager.setFillColor(.white, for: .normal)
        pager.setFillColor(Global.yellow(), for: .selected)
        pager.setStrokeColor(.black, for: .normal)
        pager.setStrokeColor(.black, for: .selected)
        
        return view
        
    }()
    
    lazy var goldSampleCalculatorCell: CalculatorCellForMain = {
        let cell = CalculatorCellForMain()
        cell.viewModel = self.mainViewModel
        cell.calculatorType = CalculatorType.goldSample
        cell.configure(with: self.mainViewModel.calculatorViewModel.data[0])
        cell.setupRx()
        return cell
    }()
    
    lazy var goldWeightCalculatorCell: CalculatorCellForMain = {
        let cell = CalculatorCellForMain()
        cell.viewModel = self.mainViewModel
        cell.calculatorType = CalculatorType.goldWeight
        cell.configure(with: self.mainViewModel.calculatorViewModel.data[1])
        cell.setupRx()
        return cell
    }()
    
    lazy var loanTermCalculatorCell: CalculatorCellForMain = {
        let cell = CalculatorCellForMain()
        cell.viewModel = self.mainViewModel
        cell.calculatorType = CalculatorType.loanTerm
        cell.configure(with: self.mainViewModel.calculatorViewModel.data[2])
        cell.setupRx()
        return cell
    }()
    
    lazy var amountTableViewCell: AmountTableViewCell = {
        let cell = AmountTableViewCell()
        return cell
    }()
    
    lazy var navBarTitle: UIImageView = {
        
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: StaticSize.s240, height: 44))
        imageView.image = UIImage(named: "newLogo")
        imageView.contentMode = .scaleAspectFit
        let barButton = UIBarButtonItem(customView: imageView)
        return imageView
    }()
    
//    MARK: View controller life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViews()
        setupConstraints()
        
        navigationItem.titleView = navBarTitle
        
        mainViewModel.getSamples()
        mainViewModel.requestsCompleted = {
            SVProgressHUD.dismiss()
            self.tableView.reloadData()
            self.setupRx()
            self.tableHeaderView.reloadData()
            self.pager.numberOfPages = self.mainViewModel.banners.count
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tabBarController?.tabBar.isHidden = false
        
    }
    
    private func setupViews() {
        
        view.addSubviews([tableView])

    }

    private func banners(){
        
    }
    
//    MARK: Constraints
    private func setupConstraints() {
        
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
    }
    
//    MARK: Functions
    func setupRx() {
        
        mainViewModel.calculatorViewModel.calculatedPrice.bind { (result) in
            self.amountTableViewCell.amountOnHand.text = result
        }.disposed(by: disposeBag)
        
        mainViewModel.calculatorViewModel.calculatedLoanPrice.bind { (result) in
            self.amountTableViewCell.refundableAmount.text = result
        }.disposed(by: disposeBag)
        
    }
    
}

extension MainViewController: FSPagerViewDataSource {
    
    func numberOfItems(in pagerView: FSPagerView) -> Int {
        return self.mainViewModel.banners.count
    }
    
    func pagerView(_ pagerView: FSPagerView, cellForItemAt index: Int) -> FSPagerViewCell {
        
        let cell = pagerView.dequeueReusableCell(withReuseIdentifier: "pagerCell", at: index)
        
        if let url = URL(string: self.mainViewModel.banners[index].mobile) {
            cell.imageView?.kf.setImage(with: url)
        }
        cell.imageView?.contentMode = .scaleAspectFill
        
        let label = UILabel()
        label.text = self.mainViewModel.banners[index].text1
        label.font = Global.sfMedium(size: StaticSize.s12)
        label.textColor = Global.black()
        let label1 = UILabel()
        label1.text = self.mainViewModel.banners[index].text2
        label1.font = Global.stroke(size: StaticSize.s20)
        label1.textColor = Global.black()
        let label2 = UILabel()
        label2.font = Global.sfMedium(size: StaticSize.s20)
        label2.textColor = Global.black()
        label2.text = self.mainViewModel.banners[index].text3
        let label3 = UILabel()
        label3.font = Global.sfMedium(size: StaticSize.s12)
        label3.textColor = Global.black()
        label3.text = self.mainViewModel.banners[index].text4
        
        cell.imageView?.addSubviews([label,label1,label2,label3])
        label.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(StaticSize.s14)
            make.left.equalToSuperview().offset(StaticSize.s16)
        }
        label1.snp.makeConstraints { (make) in
            make.top.equalTo(label.snp.bottom)
            make.left.equalToSuperview().offset(StaticSize.s16)
        }
        label2.snp.makeConstraints { (make) in
            make.top.equalTo(label1.snp.bottom).offset(-5)
            make.left.equalToSuperview().offset(StaticSize.s16)
        }
        label3.snp.makeConstraints { (make) in
            make.top.equalTo(label2.snp.bottom)
            make.left.equalToSuperview().offset(StaticSize.s16)
        }
        return cell
        
    }
    
}

extension MainViewController: FSPagerViewDelegate {
    
    func pagerViewDidScroll(_ pagerView: FSPagerView) {
        
        pager.currentPage = pagerView.currentIndex
        
    }
    
    func pagerView(_ pagerView: FSPagerView, shouldHighlightItemAt index: Int) -> Bool {
        return false
    }
    
    func pagerView(_ pagerView: FSPagerView, didSelectItemAt index: Int) {
        
        if let link = self.mainViewModel.banners[index].link {
            
            if let url = URL(string: link) {
                
                let webcontroller = WebViewController()
                webcontroller.webUrl = url
                webcontroller.hidesBottomBarWhenPushed = true
                self.navigationController?.pushViewController(webcontroller)
                
            }
            
        }
        
    }
    
}
