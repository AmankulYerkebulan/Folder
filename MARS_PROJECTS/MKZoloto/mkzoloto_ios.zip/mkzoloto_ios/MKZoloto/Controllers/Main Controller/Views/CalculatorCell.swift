//
//  CalculatorCell.swift
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import UIKit
import RxSwift
import RxAtomic

class CalculatorCell: UITableViewCell {
    
//    MARK: Properties
    
    var goldSample: [GoldSample]?
    
    var viewModel: MainViewModel?
    
    var calculatorType: CalculatorType = CalculatorType.goldSample
    
    var maxWeight: Int?
    
    var pickerDataSource = ["AU585", "AU750", "AU999"]
    
    lazy var pickerView: UIPickerView = {
        let pickerView = UIPickerView()
        pickerView.delegate = self
        pickerView.dataSource = self
        return pickerView
    }()
    
    lazy var textField: UITextField = {
        let textField = UITextField()
        textField.borderWidth = 1
        textField.borderColor = Global.textFiledBorderColor()
        textField.backgroundColor = Global.grey()
        textField.setPlaceHolderTextColor(Global.textFiledPlaceholderColor())
        textField.font = Global.sfMedium(size: StaticSize.s15)
        textField.cornerRadius = 4
        textField.keyboardType = .numberPad
        textField.addTarget(self, action: #selector(checkMax), for: .editingChanged)
        textField.addTarget(self, action: #selector(textDidBeginEditing), for: .editingDidBegin)
        textField.addPaddingLeft(16)
        textField.addPadding(.right(40))
        textField.adjustsFontSizeToFitWidth = true
        return textField
    }()
    
    lazy var dropDownButton: UIButton = {
        let button = UIButton()
        button.setImageForAllStates(#imageLiteral(resourceName: "Arrow Small 50%"))
        button.addTarget(self, action: #selector(showDropDown), for: .touchUpInside)
        return button
    }()
    
    var isDropDownTextField: Bool = false {
        didSet {
            dropDownButton.isHidden = !isDropDownTextField
            if isDropDownTextField {
                setupDropDown()
            }
        }
    }
    
//    MARK: Init
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        setupViews()
        setupConstraints()
        
        self.backgroundColor = .clear
        self.contentView.backgroundColor = .white
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        
        self.contentView.addSubviews([textField, dropDownButton])
        self.selectionStyle = .none
        
    }
    
//    MARK: Constraints
    private func setupConstraints() {
        
        contentView.snp.makeConstraints { (make) in
            make.top.bottom.equalToSuperview()
            make.left.equalToSuperview().offset(Constants.mainViewCellOffset)
            make.right.equalToSuperview().offset(-Constants.mainViewCellOffset)
        }
        
        textField.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(StaticSize.s8)
            make.bottom.equalToSuperview().offset(-StaticSize.s8)
            make.left.equalToSuperview().offset(StaticSize.s16)
            make.right.equalToSuperview().offset(-StaticSize.s16)
        }
        
        dropDownButton.snp.makeConstraints { (make) in
            make.top.equalTo(textField.snp.top)
            make.right.equalTo(textField.snp.right)
            make.height.equalTo(textField.snp.height)
            make.width.equalTo(textField.snp.height)
        }
        
    }
    
    func reSetUpConstreins() {
        textField.snp.remakeConstraints { (make) in
            make.top.equalToSuperview().offset(StaticSize.s8)
            make.bottom.equalToSuperview()
            make.left.equalToSuperview()
            make.right.equalToSuperview()
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        dropDownButton.layer.addBorder(edge: .left, color: UIColor.cellBorderColor, thickness: 1)
    }
    
//    MARK: Functions
    func setupRx() {
        
        guard let calcViewModel = viewModel?.calculatorViewModel else {
            return
        }
        
        switch calculatorType {
        case .goldSample:
            _ = textField.rx.text.orEmpty.bind(to: calcViewModel.goldSample)
        case .goldWeight:
            _ = textField.rx.text.orEmpty.bind(to: calcViewModel.goldWeight)
        case .loanTerm:
            _ = textField.rx.text.orEmpty.bind(to: calcViewModel.loanTerm)
        }
        
    }
    
    public func configure(with model: CalculatorModel) {
        
        self.isDropDownTextField    = model.isPickerTextField
        self.pickerDataSource       = model.pickerDataSource
        self.textField.text         = model.text
        self.textField.placeholder  = model.placeHolder
        self.maxWeight              = model.maxWeight
        
    }
    
    @objc func checkMax() {
        
        if let max = maxWeight {
            if let weight = Int(textField.text?.lastWord() ?? "0") {
                if weight > max {
                    self.parentViewController?.showAlert(title: "", message: "Вес золото не может превышать".localized() + " \(max) " + "грамм")
                    textField.text = "Вес изделия, грамм".localized() + "      \t" + "\(max)"
                }
            }
        }
        
        if calculatorType == .goldSample {
            if textField.text?.count ?? 0 > 24 {
                textField.text = String(textField.text?.dropLast() ?? "")
            }
        }
        
    }
    
    @objc func textDidBeginEditing() {
        
        if self.calculatorType == .goldWeight {
            textField.text = "Вес изделия, грамм".localized() + "      \t"
        }
    }
    
    private func setupDropDown() {
        textField.inputView = pickerView
    }
    
    @objc private func showDropDown() {
        
        textField.becomeFirstResponder()
    }
    
}

//MARK: UIPickerViewDelegate and UIPickerViewDataSource functions
extension CalculatorCell: UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        guard let data = self.goldSample else { return pickerDataSource.count}
        return data.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        guard let data = self.goldSample else { return pickerDataSource[row]}
        return data[row].key
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if let data = self.goldSample {
            textField.text = data[row].key
            if let _ = NetworkManager.shared.golfStorage {
                NetworkManager.shared.golfStorage?.id = data[row].id
                NetworkManager.shared.golfStorage?.key = data[row].key
                NetworkManager.shared.golfStorage?.value = data[row].value
                NetworkManager.shared.golfStorage?.au = data[row].key
            } else {
                NetworkManager.shared.golfStorage = GoldSampleForStorage(id: data[row].id, key: data[row].key, value: data[row].value, name: nil, weight: nil,au: textField.text)
            }
        } else {
            
            switch self.calculatorType {
            case .goldSample:
                textField.text = "Проба золота".localized() + "      \t\t\(pickerDataSource[row])"
            case .goldWeight:
                break
            case .loanTerm:
                textField.text = "Срок займа".localized() + "        \t\t\(pickerDataSource[row])"
            }
        
        }
    }
    
}
