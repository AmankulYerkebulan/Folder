
import UIKit

class TableSectionHeaderView: UITableViewHeaderFooterView {
    
    lazy var bgView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        return label
    }()
    
    override init(reuseIdentifier: String?) {
        super.init(reuseIdentifier: reuseIdentifier)
        
        setupViews()
        setupConstraints()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        
        self.addSubviews([bgView, titleLabel])
        
    }
    
    private func setupConstraints() {
        

        bgView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(Constants.mainViewSectionOffset)
            make.right.equalToSuperview().offset(-Constants.mainViewSectionOffset)
            make.top.bottom.equalToSuperview()
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
        }
        
    }
    
    
    
}
