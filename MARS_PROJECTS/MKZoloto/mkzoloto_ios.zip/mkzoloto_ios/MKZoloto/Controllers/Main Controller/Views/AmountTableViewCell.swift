//
//  AmountTableViewCell.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 5/24/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import UIKit

class AmountTableViewCell: UITableViewCell {
    
    //    MARK: Properties
    lazy var amountOnHandLabel: UILabel = {
        let label = UILabel()
        label.font = Global.sfRegular(size: 14)
        label.textAlignment = .center
        label.text = "Сумма на руки".localized()
        return label
    }()
    
    lazy var amountOnHand: UILabel = {
        let label = UILabel()
        label.font = Global.sfMedium(size: 30)
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        return label
    }()
    
    lazy var refundableAmountLabel: UILabel = {
        let label = UILabel()
        label.text = "Сумма к возврату".localized()
        label.textAlignment = .center
        label.font = Global.sfRegular(size: 14)
        return label
    }()
    
    lazy var refundableAmount: UILabel = {
        let label = UILabel()
        label.font = Global.sfMedium(size: 30)
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .center
        return label
    }()
    
    //    MARK: Init
    fileprivate func setupViewAppearance() {
        self.backgroundColor = .clear
        self.contentView.backgroundColor = .white
        
        self.contentView.layer.cornerRadius = 5
        if #available(iOS 11.0, *) {
            self.contentView.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        } else {
            // Fallback on earlier versions
        }
        
        self.selectionStyle = .none
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        setupViews()
        setupConstraints()
        
        setupViewAppearance()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    /// Adding views to super view
    private func setupViews() {
        
        self.contentView.addSubviews([amountOnHand, amountOnHandLabel, refundableAmount, refundableAmountLabel])
        
    }
    
    //    MARK: Constraints
    /// Setting constraints to views
    private func setupConstraints() {
        
        self.contentView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(Constants.s16)
            make.right.equalToSuperview().offset(-Constants.s16)
            make.bottom.top.equalToSuperview()
        }
        
        amountOnHandLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(Constants.s16)
            make.right.equalTo(self.snp.centerX).offset(-2)
            make.top.equalToSuperview().offset(Constants.s16 + StaticSize.s10)
        }
        
        amountOnHand.snp.makeConstraints { (make) in
            make.left.right.equalTo(self.amountOnHandLabel)
            make.top.equalTo(self.amountOnHandLabel.snp.bottom).offset(5)
        }
        
        refundableAmountLabel.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-Constants.s16)
            make.left.equalTo(self.snp.centerX).offset(2)
            make.top.equalTo(self.amountOnHandLabel)
        }
        
        refundableAmount.snp.makeConstraints { (make) in
            make.left.right.equalTo(self.refundableAmountLabel)
            make.top.equalTo(self.refundableAmountLabel.snp.bottom).offset(5)
        }
        
    }
    
    //    MARK: Targets
    // Targets from buttons, gestures and other targets
    
    
    //    MARK: Functions
    
//    Uncomment this lines for configuring cell with specific Model
//
//    public func configure(withModel: Model) {
//
//
//
//    }
    
}
