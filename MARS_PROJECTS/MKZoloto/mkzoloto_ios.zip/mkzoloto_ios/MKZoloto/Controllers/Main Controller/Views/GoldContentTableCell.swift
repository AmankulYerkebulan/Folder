//
//  GoldContentCell.swift
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import UIKit

/**
 Table view cell from main table view which contains info about Gold Content(Проба)
 And this contents shows with collection view cells 
 */

class GoldContentCell: UITableViewCell {
    
//    MARK: Properties
    var mainViewModel: MainViewModel! {
        didSet {
            self.contentCollectionView.reloadData()
        }
    }
    
    let numberOfRows: CGFloat = CGFloat(integerLiteral: 3)
    let spacingBetweenRows: CGFloat = CGFloat(integerLiteral: 16)
    
    lazy var contentCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        
        let collection = UICollectionView(frame: .zero, collectionViewLayout: layout)
        
        collection.register(cellWithClass: GoldContentTypeCell.self)
        collection.isScrollEnabled = false
        
        collection.dataSource   = self
        collection.delegate     = self
        
        collection.backgroundColor = .white
        return collection
    }()
    
//    MARK: Init
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        setupViews()
        setupConstraints()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        
        self.addSubviews([contentCollectionView])
        
    }
    
//    MARK: Constraints
    private func setupConstraints() {
        
        contentCollectionView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
    }
    
}
