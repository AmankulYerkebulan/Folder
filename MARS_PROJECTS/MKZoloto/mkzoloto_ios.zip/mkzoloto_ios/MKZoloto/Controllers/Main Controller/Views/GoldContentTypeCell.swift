//
//  GoldContentTypeCell.swift
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import UIKit

class GoldContentTypeCell: UICollectionViewCell {
    
    //    MARK: Properties
    lazy var probaLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.text = "AU585"
        label.font = Global.sfMedium(size: 15)
        label.adjustsFontSizeToFitWidth = true
        return label
    }()
    
    lazy var priceLabel: EdgeInsetLabel = {
        let label = EdgeInsetLabel()
        label.textAlignment = .center
        label.text = "8 598 тенге"
        label.backgroundColor = .yellowColor
        label.font = Global.sfBold(size: 15)
        label.sizeToFit()
        label.cornerRadius = 3
        label.leftTextInset = 10
        label.rightTextInset = 10
        label.topTextInset = 5
        label.bottomTextInset = 5
        return label
    }()
    
    //    MARK: Init
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupViews()
        setupConstraints()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        self.backgroundColor = .white
        self.cornerRadius = 4
        self.borderWidth = 1
        self.borderColor = .cellBorderColor
        
        self.addSubviews([probaLabel, priceLabel])
        
    }
    
    //    MARK: Constraints
    private func setupConstraints() {
        
        probaLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(StaticSize.s10)
            make.centerX.equalToSuperview()
            make.width.equalToSuperview().multipliedBy(0.5)
        }
        
        priceLabel.snp.makeConstraints { (make) in
            make.top.equalTo(probaLabel.snp.bottom).offset(StaticSize.s6)
            make.centerX.equalToSuperview()
        }
        
    }
    
//    MARK: Configure cell
    public func configure(with model: GoldSample) {
        
        probaLabel.text = model.key
        priceLabel.text = "\(model.value)".formatToNorm() + " ₸"
        
    }
    
}

class EdgeInsetLabel: UILabel {
    var textInsets = UIEdgeInsets.zero {
        didSet { invalidateIntrinsicContentSize() }
    }
    
    override func textRect(forBounds bounds: CGRect, limitedToNumberOfLines numberOfLines: Int) -> CGRect {
        let insetRect = bounds.inset(by: textInsets)
        let textRect = super.textRect(forBounds: insetRect, limitedToNumberOfLines: numberOfLines)
        let invertedInsets = UIEdgeInsets(top: -textInsets.top,
                                          left: -textInsets.left,
                                          bottom: -textInsets.bottom,
                                          right: -textInsets.right)
        return textRect.inset(by: invertedInsets)
    }
    
    override func drawText(in rect: CGRect) {
        super.drawText(in: rect.inset(by: textInsets))
    }
}

extension EdgeInsetLabel {
    
    var leftTextInset: CGFloat {
        set { textInsets.left = newValue }
        get { return textInsets.left }
    }
    
    
    var rightTextInset: CGFloat {
        set { textInsets.right = newValue }
        get { return textInsets.right }
    }
    
    
    var topTextInset: CGFloat {
        set { textInsets.top = newValue }
        get { return textInsets.top }
    }
    
    
    var bottomTextInset: CGFloat {
        set { textInsets.bottom = newValue }
        get { return textInsets.bottom }
    }
}
