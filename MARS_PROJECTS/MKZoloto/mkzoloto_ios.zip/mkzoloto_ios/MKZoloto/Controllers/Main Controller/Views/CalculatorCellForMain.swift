
import UIKit
import RxSwift
import RxAtomic

class CalculatorCellForMain: UITableViewCell {
    
    //    MARK: Properties
    
    var goldSample: [GoldSample]?
    
    var viewModel: MainViewModel?
    
    var calculatorType: CalculatorType = CalculatorType.goldSample
    
    var maxWeight: Int?
    
    var pickerDataSource = ["AU585", "AU750", "AU999"]
    
    lazy var pickerView: UIPickerView = {
        let pickerView = UIPickerView()
        pickerView.delegate = self
        pickerView.dataSource = self
        return pickerView
    }()
    
    lazy var textField: UITextField = {
        let textField = UITextField()
        textField.borderWidth = 1
        textField.borderColor = Global.textFiledBorderColor()
        textField.backgroundColor = Global.grey()
        textField.setPlaceHolderTextColor(Global.textFiledPlaceholderColor())
        textField.font = Global.sfMedium(size: StaticSize.s15)
        textField.cornerRadius = 4
        textField.keyboardType = .numberPad
        textField.addTarget(self, action: #selector(checkMax), for: .editingChanged)
        textField.addTarget(self, action: #selector(textDidBeginEditing), for: .editingDidBegin)
        textField.addPaddingLeft(16)
        textField.addPadding(.right(40))
        textField.adjustsFontSizeToFitWidth = true
        textField.tintColor = .clear
        return textField
    }()
    
    lazy var dropDownButton: UIButton = {
        let button = UIButton()
        button.setImageForAllStates(#imageLiteral(resourceName: "Arrow Small 50%"))
        button.addTarget(self, action: #selector(showDropDown), for: .touchUpInside)
        return button
    }()
    
    lazy var resultLbl: UILabel = {
        let label = UILabel()
        label.textColor = Global.dark()
        label.font = Global.sfMedium(size: StaticSize.s15)
        label.textAlignment = .right
        label.backgroundColor = Global.grey()
        label.isUserInteractionEnabled = true
        let gesture = UITapGestureRecognizer(target: self, action: #selector(showDropDown))
        label.addGestureRecognizer(gesture)
        return label
    }()
    
    var isDropDownTextField: Bool = false {
        didSet {
            dropDownButton.isHidden = !isDropDownTextField
            if isDropDownTextField {
                setupDropDown()
            }
        }
    }
    
    //    MARK: Init
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        setupViews()
        setupConstraints()
        
        self.backgroundColor = .clear
        self.contentView.backgroundColor = .white
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        
        self.contentView.addSubviews([textField, dropDownButton,resultLbl])
        self.selectionStyle = .none
        
    }
    
    //    MARK: Constraints
    private func setupConstraints() {
        
        contentView.snp.makeConstraints { (make) in
            make.top.bottom.equalToSuperview()
            make.left.equalToSuperview().offset(Constants.mainViewCellOffset)
            make.right.equalToSuperview().offset(-Constants.mainViewCellOffset)
        }
        
        textField.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(StaticSize.s8/2)
            make.bottom.equalToSuperview().offset(-StaticSize.s8/2)
            make.left.equalToSuperview().offset(StaticSize.s16)
            make.right.equalToSuperview().offset(-StaticSize.s16)
        }
        
        dropDownButton.snp.makeConstraints { (make) in
            make.top.equalTo(textField.snp.top)
            make.right.equalTo(textField.snp.right)
            make.height.equalTo(textField.snp.height)
            make.width.equalTo(textField.snp.height)
        }
        
        resultLbl.snp.makeConstraints { (make) in
            make.top.equalTo(textField.snp.top).offset(1)
            make.bottom.equalTo(textField.snp.bottom).offset(-1)
            make.right.equalTo(dropDownButton.snp.left).offset(-StaticSize.s8)
            make.width.equalTo(self.contentView.snp.width).multipliedBy(0.4)
        }
    
    }
    
    func reSetUpConstreins() {
        textField.snp.remakeConstraints { (make) in
            make.top.equalToSuperview().offset(StaticSize.s8/4)
            make.bottom.equalToSuperview().offset(-StaticSize.s8/4)
            make.left.equalToSuperview()
            make.right.equalToSuperview()
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        dropDownButton.layer.addBorder(edge: .left, color: UIColor.cellBorderColor, thickness: 1)
    }
    
    //    MARK: Functions
    func setupRx() {
        
        guard let calcViewModel = viewModel?.calculatorViewModel else {
            return
        }
        
        switch calculatorType {
        case .goldSample:
            _ = textField.rx.text.orEmpty.bind(to: calcViewModel.goldSample)
        case .goldWeight:
            _ = textField.rx.text.orEmpty.bind(to: calcViewModel.goldWeight)
        case .loanTerm:
            _ = textField.rx.text.orEmpty.bind(to: calcViewModel.loanTerm)
        }
        
    }
    
    public func configure(with model: CalculatorModel) {
        
        self.isDropDownTextField    = model.isPickerTextField
        self.pickerDataSource       = model.pickerDataSource
        self.textField.text         = model.text.replacingOccurrences(of: model.text.lastWord() ?? "0", with: "")
        self.textField.placeholder  = model.placeHolder
        self.maxWeight              = model.maxWeight
        resultLbl.text = model.text.lastWord()
        if calculatorType == .goldWeight {
            resultLbl.snp.remakeConstraints { (make) in
                make.top.equalTo(textField.snp.top).offset(1)
                make.bottom.equalTo(textField.snp.bottom).offset(-1)
                make.right.equalTo(textField.snp.right).offset(-StaticSize.s8)
                make.width.equalTo(self.contentView.snp.width).multipliedBy(0.4)
            }
        } else {
            resultLbl.snp.remakeConstraints { (make) in
                make.top.equalTo(textField.snp.top).offset(1)
                make.bottom.equalTo(textField.snp.bottom).offset(-1)
                make.right.equalTo(dropDownButton.snp.left).offset(-StaticSize.s8)
                make.width.equalTo(self.contentView.snp.width).multipliedBy(0.4)
            }
        }
    }
    
    @objc func checkMax() {

        if let max = maxWeight {
            if let weight = Int(self.textField.text?.lastWord() ?? "0") {
                if weight > max {
                    self.parentViewController?.showAlert(title: "", message: "Вес золото не может превышать".localized() + " \(max) " + "грамм".localized())
                    resultLbl.text = "\(max)"
                    self.textField.text = "Вес изделия, грамм".localized() + "     \t\t\(max)"
                } else {
                    if self.textField.text?.lastWord() == "0" {
                        self.textField.text = "Вес изделия, грамм".localized() + "     \t\t0"
                         resultLbl.text = "0"
                    } else {
                        resultLbl.text = String(Int(self.textField.text?.lastWord() ?? "0")!)
                    }
                }
            } else {
                 self.textField.text = "Вес изделия, грамм".localized() + "     \t\t0"
                 resultLbl.text = "0"
            }
        }
    }
    
    @objc func textDidBeginEditing() {
        
        if self.calculatorType == .goldWeight && resultLbl.text == "0" {
            self.textField.text = "Вес изделия, грамм".localized() + "     \t\t0"
        }
    }
    
    private func setupDropDown() {
        textField.inputView = pickerView
    }
    
    @objc private func showDropDown() {
        
        textField.becomeFirstResponder()
    }
    
}

//MARK: UIPickerViewDelegate and UIPickerViewDataSource functions
extension CalculatorCellForMain: UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        guard let data = self.goldSample else { return pickerDataSource.count}
        return data.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        guard let data = self.goldSample else { return pickerDataSource[row]}
        return data[row].key
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if let data = self.goldSample {
            textField.text = data[row].key
            if let _ = NetworkManager.shared.golfStorage {
                NetworkManager.shared.golfStorage?.id = data[row].id
                NetworkManager.shared.golfStorage?.key = data[row].key
                NetworkManager.shared.golfStorage?.value = data[row].value
            } else {
                NetworkManager.shared.golfStorage = GoldSampleForStorage(id: data[row].id, key: data[row].key, value: data[row].value, name: nil, weight: nil,au: textField.text)
            }
        } else {
            
            switch self.calculatorType {
            case .goldSample:
                textField.rx.text.onNext("Пробо золото".localized() + "\t\t\t\(pickerDataSource[row])")
                resultLbl.text = "\(pickerDataSource[row])"
            case .goldWeight:
                break
            case .loanTerm:
                resultLbl.text = "\(pickerDataSource[row].split(separator: " ")[0])"
                textField.rx.text.onNext("Срок займа".localized() + ", \(pickerDataSource[row].split(separator: " ")[1])\t\t\(pickerDataSource[row])")
            }
            
        }
    }
    
}
