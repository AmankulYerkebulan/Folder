//
//  MainViewModel.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 4/29/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import Foundation
import Alamofire
import SVProgressHUD

class MainViewModel {
    
    private var dispatchGroup = DispatchGroup()
    
    var requestsCompleted = { () -> () in }
    
//    All gold samples
    var goldSamples     : [GoldSample] = [] {
        didSet {
            getMainSamples()
        }
    }
//    Three main types of gold
    var mainGoldSamples : [GoldSample] = []
    
    var defaultSample   : GoldSample?
    
    var calculatorViewModel: CalculatorViewModel
    
    var banners: [BannerModel] = []
    
//    Initializer
    init() {
        
        calculatorViewModel = CalculatorViewModel()
        
    }
    
//    Getting all gold samples
    func getBanners() {
        
        dispatchGroup.enter()
        
        NetworkManager.shared.makeRequest(apiRequest: .getBanner) { (result: Result<[BannerModel]>) in
            
            self.dispatchGroup.leave()
            
            switch result {
            case .failure(let error):
                debugPrint(error)
            case .success(let data):
                self.banners = data
            }
            
        }
        
    }
    
    func getSamples() {
        
        SVProgressHUD.show()
        
        dispatchGroup.enter()
        
        NetworkManager.shared.makeRequest(apiRequest: .getGoldSamples) { (result: Result<[GoldSample]>) in
            
            self.dispatchGroup.leave()
            
            switch result {
            case .failure(let error):
                debugPrint(error)
            case .success(let data):
                self.goldSamples = data
            }
            
        }
        
        self.getDefaultGoldSample()
        
    }

//    Getting default gold smaple
    func getDefaultGoldSample() {
        
        dispatchGroup.enter()
        
        let request = ApiRequests.getDefaultGoldSample
        
        NetworkManager.shared.makeRequest(apiRequest: request) { (result: Result<GoldSample>) in
            
            self.dispatchGroup.leave()
            
            switch result {
            case .failure(let error):
                debugPrint(error)
                
            case .success(let data):
                self.defaultSample = data
                self.calculatorViewModel.defaultGoldSample = data
            }
            
        }
        
        self.getCalculatorParameters()
        
    }
    
//    Getting main type of samples
    private func getMainSamples() {
        
        let mainTypeIds = [1, 2, 6]
        
        self.mainGoldSamples = goldSamples.filter({ mainTypeIds.contains($0.id) })
        
    }
    
//    Getting calculator parameters
    private func getCalculatorParameters() {
        
        dispatchGroup.enter()
        
        let request = ApiRequests.getCalculatorParameters
        
        NetworkManager.shared.makeRequest(apiRequest: request) { (result: Result<CalculatorParameters>) in
            
            self.dispatchGroup.leave()
            
            switch result {
            case .failure(let error):
                debugPrint(error)
            case .success(let data):
                self.calculatorViewModel.calculatorParameters = data
            }
            
        }
        
        self.getLoanPercentageParameters()
        
    }
    
    private func getLoanPercentageParameters() {
        
        dispatchGroup.enter()
        
        NetworkManager.shared.makeRequest(apiRequest: .getRates) { (result: Result<[LoanPercentage]>) in
            
            self.dispatchGroup.leave()
            
            switch result {
            case .failure(let error):
                debugPrint(error)
            case .success(let data):
                self.calculatorViewModel.loanParameters = data
            }
            
        }
        
        self.getBanners()
        
        dispatchGroup.notify(queue: .main
            , work: .init(block: {
                self.configureTableViewData()
            }))
        
    }
    
    private func configureTableViewData() {
        
        let calcModels = [
            CalculatorModel(isPickerTextField: true, pickerDataSource: getPickerData(with: 1), allGoldSamples: self.goldSamples, placeHolder: "Проба золота".localized(), text:
                "Проба золота".localized() + "       \t\(self.defaultSample?.key ?? "")", maxWeight: 60),
            CalculatorModel(isPickerTextField: false, pickerDataSource: getPickerData(with: 2), allGoldSamples: self.goldSamples, placeHolder: "Вес изделия, грамм".localized(), text:
                "Вес изделия, грамм".localized() + "     \t0", maxWeight: self.calculatorViewModel.calculatorParameters?.maxWeight ?? 2000),
            CalculatorModel(isPickerTextField: true, pickerDataSource: getPickerData(with: 3), allGoldSamples: self.goldSamples, placeHolder: "Срок займа".localized(), text:
                "Срок займа, дней".localized() + "     \t\(self.calculatorViewModel.calculatorParameters?.defaultTerm ?? 30)" + "".localized(), maxWeight: 60)
        ]
        
        calculatorViewModel.data = calcModels
    
        self.requestsCompleted()
        
    }
    
    private func getPickerData(with tag: Int) -> [String] {
        
        switch tag {
        case 1:
            return self.goldSamples.map({ $0.key })
        case 3:
            return self.getDays()
        default:
            return []
        }
        
    }
    
    private func getDays() -> [String] {
        
        var days: [String] = []
        
        //        если предпоследня цифра 1, то "дней"
        //        иначе если последняя цифра 0 или >=5, то "дней"
        //        иначе если последняя цифра 2,3 или 4, то "дня"
        //        иначе "день".
        
        for day in (1...(self.calculatorViewModel.calculatorParameters?.maxTerm ?? 60)) {
            
            if (day.digits.count > 1) {
                if (day.digits[day.digits.count - 2] == 1) {
                    days.append("\(day) " + "дней".localized())
                    continue
                }
            }
            
            if (day.digits.last! == 0 || day.digits.last! >= 5) {
                days.append("\(day) " + "дней".localized())
            } else if (day.digits.last! == 2 || day.digits.last! == 3 || day.digits.last! == 4) {
                days.append("\(day) " + "дня".localized())
            } else {
                days.append("\(day) " + "день".localized())
            }
            
        }
        
        return days
        
    }

}
