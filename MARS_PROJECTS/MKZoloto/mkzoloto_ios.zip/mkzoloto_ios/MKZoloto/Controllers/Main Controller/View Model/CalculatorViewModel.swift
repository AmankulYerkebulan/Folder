
import Foundation
import RxSwift

struct CalculatorModel {
    var isPickerTextField: Bool
    var pickerDataSource: [String]
    var allGoldSamples: [GoldSample]
    var placeHolder: String
    var text: String
    
    var maxWeight: Int
}

class CalculatorViewModel {
    
    var defaultGoldSample: GoldSample?
    
    var goldSample = BehaviorSubject(value: "")
    
    var goldWeight = BehaviorSubject(value: "")
    
    var loanTerm = BehaviorSubject(value: "")
    
    var calculatedPrice: BehaviorSubject<String> = BehaviorSubject(value: "")
    
    var calculatedLoanPrice: BehaviorSubject<String> = BehaviorSubject(value: "")
    
    var data = [CalculatorModel]()
    
    var calculatorParameters: CalculatorParameters?
    
    var loanParameters: [LoanPercentage]?
    
    func gettingPickerData() -> [String] {
        return [String]()
    }
    
    init() {
        
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .decimal
        numberFormatter.maximumFractionDigits = 0
        
        _ = Observable.combineLatest(self.goldSample.asObservable(), self.goldWeight.asObservable()).subscribe(onNext: { (goldSample, goldWeight) in

            let goldSampleWord = goldSample.split(separator: "\t", maxSplits: 10, omittingEmptySubsequences: true)
            let goldSample1 = goldSampleWord.last
            
            let priceOfGoldSample = self.getGoldSamplePrice(key: String(goldSample1 ?? ""))

            let price = priceOfGoldSample * (Int(goldWeight.numbers) ?? 0)

//            if let formattedPrice = numberFormatter.string(from: NSNumber(value: price)) {
            
                let totalPriceString = "\(price)".formatToNorm()
                
                self.calculatedPrice.onNext("\(totalPriceString) ₸")
//            }

        }, onError: nil, onCompleted: nil, onDisposed: nil)
        
        _ = Observable.combineLatest(self.goldSample.asObservable(), self.goldWeight.asObservable(), self.loanTerm.asObserver()).subscribe(onNext: { (goldSample, goldWeight, loanTerm) in
            
            let goldSampleWord = goldSample.split(separator: "\t", maxSplits: 10, omittingEmptySubsequences: true)
            let goldSample1 = goldSampleWord.last
            
            let priceOfGoldSample = self.getGoldSamplePrice(key: String(goldSample1 ?? ""))

            let price = priceOfGoldSample * (Int(goldWeight.numbers) ?? 0)
            
            guard let loanParams = self.loanParameters else { return }
            
            let loanPrices = self.loanPercentages(loanParams: loanParams)
            
            var totalPrice: Float = 0
            
            let intLoanTerm = Int(loanTerm.numbers) ?? self.calculatorParameters?.defaultTerm ?? 30
            
            switch Int(intLoanTerm) {
            case let term where term <= 30:
                totalPrice = Float(price) * (1 + loanPrices.stavka30 * Float(term) / 100)
                
            case let term where term > 30:
                totalPrice = Float(price) * (1 + loanPrices.stavka30 * Float(term) / 100 + loanPrices.stavka30Plus * Float(term - 30) / 100)
                
            default:
                break
            }
//
//            if let formattedPrice = numberFormatter.string(from: NSNumber(value: totalPrice.rounded())) {
            
                let totalPriceString = "\(Int(totalPrice.rounded()))".formatToNorm()
                
                self.calculatedLoanPrice.onNext("\(totalPriceString) ₸")
//            }
//            self.calculatedLoanPrice.onNext("\(Int(totalPrice.rounded())) ₸")
            
        }, onError: nil, onCompleted: nil, onDisposed: nil)
       
    }
    
    func getGoldSamplePrice(key: String) -> Int {
        
        guard let goldSamples = self.data.first?.allGoldSamples else {
            return 0
        }
        
        let goldSample = goldSamples.first { $0.key == key }
        
        return goldSample?.value ?? (self.defaultGoldSample?.value ?? 0)
        
    }
    
    func loanPercentages(loanParams: [LoanPercentage]) -> (stavka30: Float, stavka30Plus: Float) {
        
        var stavka30: Float = 0
        var stavka30Plus: Float = 0
        
        for loan in loanParams {
            switch loan.key {
            case "Stavka30":
                stavka30 = Float(loan.value) ?? 0
            case "Stavka30Plus":
                stavka30Plus = Float(loan.value) ?? 0
            default:
                break
            }
        }
        
        return (stavka30: stavka30, stavka30Plus: stavka30Plus)
        
    }
    
}


extension String {
    var numbers: String {
        return String(characters.filter { "0"..."9" ~= $0 })
    }
}
