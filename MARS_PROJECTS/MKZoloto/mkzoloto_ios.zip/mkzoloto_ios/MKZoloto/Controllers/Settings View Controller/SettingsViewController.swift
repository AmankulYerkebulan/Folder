
import UIKit
import LocalAuthentication
class SettingsViewController: UIViewController {
    
    //    MARK: Properties
    let data = ["Язык".localized(), "Уведомления".localized(), "Touch ID"]
    
    let languages: [LanguageModel] = [LanguageModel(languageTitle: "Руcский".localized(), language: "ru"), LanguageModel(languageTitle: "Английский".localized(), language: "en")]
    
    lazy var notificationSwitch: UISwitch = {
        let nswitch = UISwitch()
        nswitch.tag = 1
        nswitch.isOn = StoreManager.shared().isNotificationTurnedOn()
        nswitch.addTarget(self, action: #selector(switchChanged(sender:)), for: .valueChanged)
        return nswitch
    }()
    
    lazy var touchIdSwitch: UISwitch = {
        let nswitch = UISwitch()
        nswitch.tag = 2
        nswitch.isOn = StoreManager.shared().isTouchIdUsable()
        nswitch.addTarget(self, action: #selector(switchChanged(sender:)), for: .valueChanged)
        return nswitch
    }()
    
    lazy var langPickerView: UIPickerView = {
        let pickerView = UIPickerView()
        pickerView.delegate = self
        pickerView.dataSource = self
        return pickerView
    }()
    
    lazy var textField: UITextField = {
        let textField = UITextField()
        textField.inputView = self.langPickerView
        textField.addRightButtonOnKeyboardWithText("Done", target: self, action: #selector(selectLanguage))
        return textField
    }()
    
    lazy var tableView: UITableView = {
        let tableView = UITableView()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = Global.grey()
        tableView.separatorStyle = .none
        tableView.tintColor = Global.dark()
        tableView.register(cellWithClass: UITableViewCell.self)
        return tableView
    }()
    
    //MARK: Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViews()
        setupConstraints()
        
        navigationItem.title = "Настройка кабинета".localized()
        
    }
    
    private func setupViews() {
        
        self.view.addSubviews([tableView, textField])
        
    }
    
    //    MARK: Constraints
    private func setupConstraints() {
        
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
    }
    
    @objc private func selectLanguage() {
        
        let row = langPickerView.selectedRow(inComponent: 0)
        
        StoreManager.shared().setLanguage(lang: self.languages[row])
        
        self.tableView.visibleCells.first?.detailTextLabel?.text = self.languages[row].languageTitle
        
        view.endEditing(true)
        
    }
    
    @objc private func switchChanged(sender: UISwitch) {
        
        if (sender.tag == 1) {
            StoreManager.shared().setNotificationState(isTurnedOn: self.notificationSwitch.isOn)
        } else {
            
            
            if (self.touchIdSwitch.isOn == true) {
                let context = LAContext()
                
                if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: nil) {
                    let reason = "Authenticate with Touch ID"
                    context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason, reply:
                        {(success, error) in
                            if success {
                                
                            }
                            else {
                                self.showAlertController("Touch ID Authentication Failed", completion: {
                                    self.touchIdSwitch.setOn(false, animated: true)
                                    StoreManager.shared().setTouchIdUsable(isUsable: self.touchIdSwitch.isOn)
                                })
                                
                            }
                    })
                }
                else {
                    showAlertController("Touch ID not available", completion: {
                        self.touchIdSwitch.setOn(false, animated: true)
                        StoreManager.shared().setTouchIdUsable(isUsable: self.touchIdSwitch.isOn)
                    })
                }
            }
            
        }
        
    }
    
    private func showAlertController(_ message: String, completion: @escaping () -> ()) {
        let alertController = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in completion() }))
        present(alertController, animated: true, completion: nil)
    }
    
}

//MARK: UITableViewDelegate and UITableViewDataSource functions
extension SettingsViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        switch indexPath.row {
        case 0:
            let cell = UITableViewCell(style: .value1, reuseIdentifier: String(describing: UITableViewCell.self))
            cell.textLabel?.text = self.data[indexPath.row]
            cell.textLabel?.font = Global.sfMedium(size: StaticSize.s15)
            cell.detailTextLabel?.font = Global.sfMedium(size: StaticSize.s15)
            cell.detailTextLabel?.textColor = Global.dark()
            cell.textLabel?.textColor = Global.dark()
            cell.setUpCellShadow()
            cell.detailTextLabel?.text = StoreManager.shared().getLanguage()?.languageTitle ?? "Русский".localized()
            cell.accessoryType = .disclosureIndicator
            cell.backgroundColor = Global.white()
            cell.selectionStyle = .none
            return cell
        default:
            let cell = tableView.dequeueReusableCell(withClass: UITableViewCell.self, for: indexPath)
            cell.setUpCellShadow()
            cell.textLabel?.text = self.data[indexPath.row]
            cell.textLabel?.textColor = Global.dark()
            cell.textLabel?.font = Global.sfMedium(size: StaticSize.s15)
            cell.backgroundColor = Global.white()
            if (indexPath.row == 1) {
                cell.accessoryView = self.notificationSwitch
            } else {
                cell.accessoryView = self.touchIdSwitch
            }
            cell.selectionStyle = .none
            return cell
        }
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.row == 0 {
            textField.becomeFirstResponder()
        }
        
    }
    
}

extension SettingsViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.languages.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return self.languages[row].languageTitle
    }
    
}
