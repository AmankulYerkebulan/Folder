
import UIKit

class ServicesTableViewCell: UITableViewCell {
    
    private lazy var imageH: UIImageView = {
        let image = UIImageView()
        image.layer.cornerRadius = 4
        return image
    }()
    
    lazy var titleH: UILabel = {
        let label = UILabel()
        label.textColor = Global.dark()
        label.font = Global.sfMedium(size: StaticSize.s15)
        return label
    }()
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("Some error")
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.setUp()
    }
}


extension ServicesTableViewCell {
    
    private func setUp() {
        
        self.addSubview(imageH)
        self.addSubview(titleH)
        self.setUpCellShadow()
        titleH.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(10)
            make.left.equalToSuperview().offset(16)
            make.right.equalTo(imageH.snp.left)
            make.height.equalTo(24)
        }
        
        imageH.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(15)
            make.right.bottom.equalToSuperview().offset(-16)
            make.height.equalTo(14)
            make.width.equalTo(8)
        }
        
    }
    
    func setUpDetails(image: String, title: String) {
        self.imageH.image   = UIImage(named: image)
        self.titleH.text    = title
    }
}





