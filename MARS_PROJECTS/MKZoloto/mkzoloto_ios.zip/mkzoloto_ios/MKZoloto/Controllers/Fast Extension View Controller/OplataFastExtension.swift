
import UIKit
import ValueStepper
import SnapKit
import Alamofire
import SVProgressHUD

class OplataFastExtension: UIViewController {
    
    var loanId : Int?
    var count  : String?
    
    var data : OrderModel?
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.register(cellWithClass: UITableViewCell.self)
        tableView.register(cellWithClass: OplataZaimViewCell.self)
        tableView.register(cellWithClass: UITableViewCell.self)
        
        tableView.separatorStyle = .none
        tableView.delegate      = self
        tableView.dataSource    = self
        var frame = CGRect.zero
        frame.size.height = .leastNormalMagnitude
        tableView.tableHeaderView = UIView(frame: frame)

        tableView.backgroundColor = Global.grey()
        return tableView
    }()
    
    private lazy var button : UIButton = {
        let button = UIButton()
        button.setTitle("Подтвердить и оплатить".localized(), for: .normal)
        button.yellowBtnProperty()
        button.addTarget(self, action: #selector(orderPayment), for: .touchUpInside)
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupViews()
        setupConstraints()
        
//        setupInformation()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tabBarController?.tabBar.isHidden = true
    }

    @objc func orderPayment() {
        
        guard let _data = self.data else {
            return
        }
        
        let request = ApiRequests.orderPayment(orderId: "\(_data.order)")
        
        SVProgressHUD.show()
        
        NetworkManager.shared.makeRequest(apiRequest: request) { (result: Result<PaymentModel>) in
            switch result {
            case .failure(let error):
                SVProgressHUD.showError(withStatus: error.localizedDescription)
            case .success(let data):
                SVProgressHUD.dismiss()
                
                let webVC = WebViewController()
                webVC.webUrl = URL(string: data.url)
                self.navigationController?.pushViewController(webVC)
                
            }
        }
        
    }
    
}


extension OplataFastExtension {
    
    private func setupViews(){
        self.view.addSubviews([tableView, button])
        self.view.backgroundColor = .white
        navigationItem.title = "Заказ".localized().uppercased()
        
        tableView.contentInset = UIEdgeInsets(top: 2, left: 0, bottom: 0, right: 0)
        
    }
    
    private func setupConstraints() {
        tableView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        button.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(self.view.safeAreaLayoutGuide).offset(-16)
            } else {
                make.bottom.equalTo(self.view.snp.bottom).offset(-16)
            }
            make.left.equalTo(self.view).offset(16)
            make.right.equalTo(self.view).offset(-16)
            make.height.equalTo(44)
        }
        
    }
}

extension OplataFastExtension: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.section {
        case 0:
            let cell = UITableViewCell(style: .value1, reuseIdentifier: String(describing: UITableViewCell.self))
            cell.textLabel?.text = "Заказ".localized() + " №\(self.data?.order ?? 0)"
            cell.textLabel?.font = Global.sfRegular(size: 15)
            cell.selectionStyle = .none
            return cell
        case 1:
            let cell = tableView.dequeueReusableCell(withClass: OplataZaimViewCell.self, for: indexPath)
            
            cell.zaimLabel.text = "Залоговый билет".localized() + " №\(self.data?.loans[indexPath.row].loanId ?? 0)"
            cell.prodlenieLabel.text = self.data?.loans[indexPath.row].operationType ?? ""
            cell.zaimNumberLabel.text = "\(self.data?.loans[indexPath.row].amount ?? 0) тг"
            
            return cell
        default:
            let cell = UITableViewCell(style: .value1, reuseIdentifier: String(describing: UITableViewCell.self))
            cell.textLabel?.text = "Итого к оплате".localized()
            cell.textLabel?.font = Global.sfMedium(size: 15)
            cell.detailTextLabel?.text = "\(self.data?.totalSum ?? 0) тг"
            cell.detailTextLabel?.font = Global.sfSemiBold(size: 17)
            cell.selectionStyle = .none
            return cell
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if ((self.data?.loans.count ?? 0) > 0) {
            return 2 + (self.data?.loans.count ?? 0)
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return 1
        case 1:
            return self.data?.loans.count ?? 0
        default:
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
            return 0
        }
        return 16
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNormalMagnitude
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if (indexPath.section == 1) {
            return 64
        }
        return UITableView.automaticDimension
    }
    
}
