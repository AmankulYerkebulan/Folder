
import UIKit
import ValueStepper
import SnapKit
import Alamofire
import SVProgressHUD

class FastExtensionDetailViewController: UIViewController {
    
    var data: ExpressProlongation?
    var isExpress = true
    var index: Int?
    var loadDelegate: LoanDelegate?
    
    private var calendar:[String] = []
    private var allDay:[String] = []
    private var currentIndexCalendar = 0
    private var initialDate = ""
    private var amount = "0"
    private var count  = "0"
    private var termDate = Date()
    private var calculationModel:[CalculationModel] = []
    private var isRequestes = false
    private var orderId: Int?
    private var selectedOperation = 1
    private let statusAlert = StatusAlert()
    
    private lazy var pickerView: UIPickerView = {
        let pickerView = UIPickerView()
        pickerView.delegate = self
        pickerView.dataSource = self
        return pickerView
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView()
        tableView.register(cellWithClass: UITableViewCell.self)
        tableView.register(cellWithClass: UITableViewCell.self)
        tableView.register(ChastichnyViewCell.self, forCellReuseIdentifier: ChastichnyViewCell.id)
        tableView.separatorStyle = .none
        tableView.delegate      = self
        tableView.dataSource    = self
        tableView.backgroundColor = Global.grey()
        return tableView
    }()
    
    private lazy var button : UIButton = {
        let button = UIButton()
        button.isHidden = true
        button.cornerRadius = 4
        button.yellowBtnProperty()
        button.setTitleColor(Global.black(), for: UIControl.State.normal)
        button.addTarget(self, action: #selector(openView), for: .touchUpInside)
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViews()
        setupConstraints()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    
        self.tabBarController?.tabBar.isHidden = true
        self.setUpStatus()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name("Selecteday"), object: nil)
    }
    
}

extension FastExtensionDetailViewController {
    
    private func setUpStatus() {
        
        if isRequestes == true {
            guard let orderId = orderId else {return}
            let request = ApiRequests.expresPayStatus(id: "\(orderId)")
            
            SVProgressHUD.show()
            NetworkManager.shared.makeRequest(apiRequest: request) { (result: Result<Status>) in
                
                switch result {
                
                case .success(let data):
                    self.statusAlert.setUpStatus(title: data.status)
                    SVProgressHUD.dismiss()
                    UIView.animate(withDuration: 0.3, animations: {
                        self.statusAlert.alpha = 1
                    }) { (success) in
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                            self.statusAlert.alpha = 0
                            self.isRequestes = false
                        })
                    }
                case .failure(let error):
                    if let customError = error as? CustomError {
                        SVProgressHUD.showError(withStatus: customError.errorDescription)
                    } else {
                        SVProgressHUD.showError(withStatus: error.localizedDescription)
                    }
                }
            }
        }
    }
    
    private func setupViews() {
        
        statusAlert.alpha = 0
        if let _data = data {
            self.count = "\(_data.maxRenewal)"
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd.MM.yyyy"
            dateFormatter.locale = Locale(identifier: "kk_KZ")
            var initiualdate = Date()
            if let _initiualdate = dateFormatter.date(from: _data.loanTerm) {
                initiualdate = _initiualdate
            } else {
                dateFormatter.dateFormat = "yyy-MM-dd"
                if let _initiualdate = dateFormatter.date(from: _data.loanTerm) {
                    initiualdate = _initiualdate
                } else {
                    self.navigationController?.popViewController()
                    return
                }
            }
            
            for (index,i) in (_data.minRenewal..._data.maxRenewal).enumerated() {
                let date = (Calendar.current as NSCalendar).date(byAdding: .day, value: -(_data.maxRenewal - i), to: initiualdate, options: [])!
                let format = DateFormatter()
                format.dateFormat = "EEE dd MMM"
                let formattedDate = format.string(from: date)
                self.calendar.append(formattedDate)
                self.allDay.append((index == 0 ? ("минимально".localized() + " ") : "")  + String(i) + " " + String(i).setUpDay())
            }
            currentIndexCalendar = _data.maxRenewal - 1
            
            self.initialRequest(value: _data.maxRenewal)
        }
        
        self.view.addSubviews([tableView, button])
        self.view.insertSubview(statusAlert, aboveSubview: button)
        self.view.backgroundColor = Global.grey()
        navigationItem.title = "Экспресс продление".localized().uppercased()
        
        if self.isExpress == false {
            button.setTitle("Применить".localized(), for: .normal)
            navigationItem.title = "Параметры операции".localized()
        }
    }
    
    private func setupConstraints() {
        
        tableView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.bottom.equalTo(button.snp.top).offset(-StaticSize.s16)
        }
        
        button.snp.makeConstraints{ make in
            make.left.equalToSuperview().offset(StaticSize.s16)
            make.right.equalToSuperview().offset(-StaticSize.s16)
            make.bottom.equalToSuperview().offset(-(StaticSize.s16 + 10))
            make.bottom.height.equalTo(StaticSize.s44)
        }
        statusAlert.snp.makeConstraints { (make) in
            make.size.equalTo(self.view.snp.size)
        }
    }
    
    @objc private  func openView() {
        
        if self.isExpress == true {
        
            if let _data = data {
                setupInformation(data: _data)
            }
        } else {
            if let _index = index {
                loadDelegate?.loans[_index].count = Int(self.count) ?? 0
                loadDelegate?.loans[_index].defaultPay = Double(self.amount) ?? 0.0
                loadDelegate?.loans[_index].operationType = selectedOperation
            }
            self.navigationController?.popViewController()
        }
    }
    
    private func setupInformation(data: ExpressProlongation) {
    
        let request = ApiRequests.generateOrder(loanId: "\(data.loanId)", countDays: self.count)
        
        SVProgressHUD.show()
        
        NetworkManager.shared.makeRequest(apiRequest: request) { (result: Result<OrderModelWithURL>) in
            
            switch result {
            case .failure(let error):
                SVProgressHUD.showError(withStatus: error.localizedDescription)
            case .success(let data):
                SVProgressHUD.dismiss()
                let vc = WebViewController()
                vc.webUrl = URL(string: data.url)
                self.orderId = data.order
                self.isRequestes = true
                self.navigationController?.pushViewController(vc, animated: true)
                self.tableView.reloadData()
            }
            
        }
        
    }
    
}


extension FastExtensionDetailViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let _data = data {
            switch indexPath.section {
            case 0:
                let cell = UITableViewCell(style: .value1, reuseIdentifier: String(describing: UITableViewCell.self))
                cell.textLabel?.font = Global.sfMedium(size: StaticSize.s15)
                cell.textLabel?.textColor = Global.dark()
                cell.selectionStyle = .none
                if isExpress == false {
                    cell.textLabel?.text = "Продление займа".localized()
                    cell.detailTextLabel?.text = "Изменить".localized()
                    cell.accessoryType = .disclosureIndicator
                } else {
                    cell.accessoryType = .none
                    cell.textLabel?.halfTextColorChange(fullText: "Залоговый билет".localized() + " №\(_data.loanId)", changeText: String(String(_data.loanId).characters.suffix(8)))

                }
                return cell
//            case 2:
//                let cell = tableView.dequeueReusableCell(withIdentifier: ChastichnyViewCell.id, for: indexPath) as! ChastichnyViewCell
//                return cell
            default:
                let cell = UITableViewCell(style: .value1, reuseIdentifier: String(describing: UITableViewCell.self))
                cell.textLabel?.font = Global.sfMedium(size: StaticSize.s15)
                cell.textLabel?.textColor = Global.dark()
                cell.detailTextLabel?.font = Global.sfMedium(size: StaticSize.s15)
                cell.detailTextLabel?.textColor = Global.dark()
                cell.selectionStyle = .none
                cell.tintColor = Global.dark()
                cell.setUpCellShadow()
                cell.accessoryView = UIImageView(image: #imageLiteral(resourceName: "Icon"))
                if indexPath.row == 2 {
                    cell.accessoryView = nil
                    cell.textLabel?.font = Global.sfBold(size: StaticSize.s15)
                    cell.detailTextLabel?.font = Global.sfBold(size: StaticSize.s15)
                    cell.textLabel?.text = "Сумма продления".localized()
                    cell.detailTextLabel?.text = "\(amount.formatToNorm()) ₸"
                    cell.accessoryType = .none
                } else if indexPath.row == 1 {
                    cell.textLabel?.text = "Новый срок".localized()
                    
                    let dateString = _data.loanTerm.replacingOccurrences(of: "-", with: ".")
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "yyyy.MM.dd"
                    dateFormatter.locale = Locale.init(identifier: "en_GB")
                    
                    let dateObj = dateFormatter.date(from: dateString)
                    
                    dateFormatter.dateFormat = "dd.MM.yyyy"
                    if let _date = dateObj {
                        cell.detailTextLabel?.text = dateFormatter.string(from: _date)
                    } else {
                        cell.detailTextLabel?.text = dateString
                    }
                    cell.accessoryType = .disclosureIndicator
                } else {
                    cell.textLabel?.text = "Срок продления".localized()
                    cell.detailTextLabel?.text = self.allDay[self.currentIndexCalendar ]
                    cell.accessoryType = .disclosureIndicator
                }
                return cell
            }
        }
        return UITableViewCell()
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        }
        return 3
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.section == 0 && isExpress == false {
            
            let request = ApiRequests.operationTypes
            SVProgressHUD.show()
            NetworkManager.shared.makeRequest(apiRequest: request) { (result: Result<[OpertaionTypes]>) in
                switch result {
                
                case .success(let data):
                    SVProgressHUD.dismiss()
                    self.selectedOperation = (data.first?.id)!
                    let alert = UIAlertController(title: "", message: "Тип операции".localized(), preferredStyle: .actionSheet)
                    
                    for i in data {
                    
                        alert.addAction(UIAlertAction(title: "\(i.name)", style: .default , handler:{ (UIAlertAction) in
                            self.selectedOperation = i.id
                        }))
                    }
                    
                    alert.addAction(UIAlertAction(title: "Отмена".localized(), style: .cancel, handler:{ (UIAlertAction)in
                        
                    }))
                    
                    self.present(alert, animated: true, completion: {
                        print("completion block")
                    })
                case .failure(let error):
                    if let customError = error as? CustomError {
                        SVProgressHUD.showError(withStatus: customError.errorDescription)
                    } else {
                        SVProgressHUD.showError(withStatus: error.localizedDescription)
                    }
                }
            }
            
        } else if indexPath.section == 1 {
            if indexPath.row == 1 {
                self.showPickerView(index: 1)
            } else if indexPath.row == 0 {
                self.showPickerView(index: 0)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 1 {
            return StaticSize.s16
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 1 {
            let view = UIView(frame: CGRect(x: 0, y: 0, width: 30, height: StaticSize.s16))
            return view
        }
        return nil
    }
    
    @objc private func stepperChanged(value: Int) {
        
        let date = (Calendar.current as NSCalendar).date(byAdding: .day, value: value + 1, to: termDate, options: [])!
        let format = DateFormatter()
        format.dateFormat = "dd.MM.yyyy"
        let formattedDate = format.string(from: date)
        self.initialDate = formattedDate
        
        if calculationModel.count - 1 < value {
            self.navigationController?.popViewController()
            return
        }
        
        self.count = String(value + 1)
        self.amount = "\(calculationModel[value].amount)"
        self.data?.loanTerm = calculationModel[value].new_term
        self.button.setTitle("Далее".localized(), for: .normal)
        self.tableView.reloadData()
    }
    
    private func showPickerView(index: Int) {
        
        let toolBar = UIToolbar()
        
        toolBar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Выбрать".localized(), style: UIBarButtonItem.Style.plain, target: self, action: #selector(donePicker))
        let title = UIBarButtonItem(title: index == 0 ? "Срок продления".localized() : "Новый срок".localized(), style: UIBarButtonItem.Style.plain, target: self, action: nil)
        title.tintColor = Global.dark()
        title.setTitleTextAttributes([
            NSAttributedString.Key.font: Global.sfMedium(size: StaticSize.s15),
            NSAttributedString.Key.foregroundColor: Global.dark()], for: .normal)
        let empty = UIBarButtonItem(title: "Выбрать".localized(), style: UIBarButtonItem.Style.plain, target: self, action: nil)
        empty.tintColor = .clear
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        toolBar.setItems([empty,flexibleSpace,title,flexibleSpace,doneButton], animated: false)
        
        let dummy = UITextField(frame: CGRect.zero)
        self.view.addSubview(dummy)
        self.pickerView.tag = index
        pickerView.reloadAllComponents()
        dummy.inputAccessoryView = toolBar
        dummy.inputView = pickerView
        self.pickerView.selectRow(currentIndexCalendar, inComponent: 0, animated: false)
        dummy.becomeFirstResponder()
    }
    
    @objc func donePicker()
    {
        stepperChanged(value: currentIndexCalendar)
        
        self.view.endEditing(true)
    }
    
    private func initialRequest(value: Int) {
        
        button.isHidden = false
        let date = (Calendar.current as NSCalendar).date(byAdding: .day, value: value, to: termDate, options: [])!
        let format = DateFormatter()
        format.dateFormat = "dd.MM.yyyy"
        let formattedDate = format.string(from: date)
        self.initialDate = formattedDate
        
        guard let _data = data else {return}
        var request = ApiRequests.calculation(loan_id: "\(_data.loanId)", operation_type: "extension")
        
        if isExpress == true {
        request = ApiRequests.calculationByFast(loan_id: "\(_data.loanId)", operation_type: "extension")
        }
        
        SVProgressHUD.show()
        NetworkManager.shared.makeRequest(apiRequest: request) { (result: Result<[CalculationModel]>) in
            switch result {
            
            case .success(let data):
                SVProgressHUD.dismiss()
                self.calculationModel = data
                self.count = String(value)
                self.amount = "\(data.last!.amount)"
                self.data?.loanTerm = data.last!.new_term
                if self.isExpress == true {
                    self.button.setTitle("Далее".localized(), for: .normal)
                }
                self.tableView.reloadData()
            case .failure(let error):
                if let customError = error as? CustomError {
                    
                    SVProgressHUD.showError(withStatus: customError.errorDescription)
                    SVProgressHUD.dismiss(withDelay: 1.5)
                    self.navigationController?.popViewController()
                } else {
                    SVProgressHUD.showError(withStatus: error.localizedDescription)
                }
            }
        }
    }
    
}
extension FastExtensionDetailViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView.tag == 1 {
            return self.calendar.count
        }
        return self.allDay.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView.tag == 1 {
            return self.calendar[row]
        }
        return self.allDay[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        print("row:\(row)")
        self.currentIndexCalendar = row
    }
    
}
