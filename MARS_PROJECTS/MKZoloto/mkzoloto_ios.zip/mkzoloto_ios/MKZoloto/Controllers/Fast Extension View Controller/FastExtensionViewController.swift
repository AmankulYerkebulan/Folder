
import UIKit
import SwifterSwift
import SnapKit
import Alamofire
import SVProgressHUD

class FastExtensionViewController: UIViewController {
    
    private lazy var labelButton: UILabel = {
        let label = UILabel()
        label.font = Global.sfRegular(size: StaticSize.s12)
        label.textColor = Global.dark()
        label.text = "Продолжая операцию, Вы соглашаетесь с\nПравилами проведения онлайн операций".localized()
        label.textAlignment = .center
        label.numberOfLines = 0
        label.isUserInteractionEnabled = true
        return label
    }()
    
    private lazy var clearView : UIView = {
        let view = UIView()
        return view
    }()
    
    private lazy var scrollView : UIScrollView = {
        let view = UIScrollView()
        view.isScrollEnabled = true
        view.showsVerticalScrollIndicator = false
        view.contentSize = CGSize(width: UIScreen.main.bounds.width, height: 1000)
        view.bounces = false
        return view
    }()
    
    private lazy var IIN : UITextField = {
        let tField = UITextField()
        tField.placeholder = "Ваш ИИН".localized()
        tField.keyboardType = .numberPad
        tField.setUpTextFiledUI()
        tField.delegate = self
        tField.addPadding(.left(16))
        return tField
    }()
    
    private lazy var ticketNumber : VSTextField = {
        let tField = VSTextField()
        tField.placeholder = "Номер залогового билета".localized()
        tField.setUpTextFiledUI()
        tField.delegate = self
        tField.keyboardType = .numberPad
        tField.addPadding(.left(16))
        return tField
    }()
    
    private lazy var nextButton : UIButton = {
       let button = UIButton()
       button.yellowBtnProperty()
       button.setTitle("Далее".localized(), for: UIControl.State.normal)
       button.addTarget(self, action: #selector(nextButtonFunc), for: .touchUpInside)
       return button
    }()
    
    private lazy var errorImage : UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "Oval")
        image.contentMode = .scaleAspectFill
        return image
    }()
    
    private lazy var textFieldErrors : UILabel = {
        let label = UILabel()
        label.text = "ИИН не менее 12 символов".localized()
        label.font = Global.sfRegular(size: StaticSize.s12)
        label.adjustsFontSizeToFitWidth = true
        label.numberOfLines = 0
        label.textColor = Global.red()
        return label
    }()
    
    private lazy var frontView : UIView = {
        let view = UIView()
        view.layer.zPosition = -5
        view.backgroundColor = .white
        view.cornerRadius = 5
        view.addShadow(ofColor: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), radius: 3, offset: .zero, opacity: 0.1)
        return view
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViews()
        setupConstraints()
        self.hideKeyboard()
        navigationItem.title = "Экспресс продление".localized().uppercased()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tabBarController?.tabBar.isHidden = true
    }
}

extension FastExtensionViewController {

    private func setupViews() {
        self.view.backgroundColor = Global.grey()
        self.view.addSubview(scrollView)
        self.scrollView.addSubviews([clearView, IIN, ticketNumber, nextButton, frontView,labelButton])
        scrollView.bringSubviewToFront(IIN)
        scrollView.bringSubviewToFront(ticketNumber)
        self.navigationController?.setUpShadow()
        tappableLabel()
    }
    
    private func setupConstraints() {
        scrollView.snp.makeConstraints { make in
            make.edges.equalTo(view).inset(UIEdgeInsets.zero)
        }
        
        clearView.snp.makeConstraints { make in
            make.edges.equalTo(scrollView).inset(UIEdgeInsets.zero)
            make.width.equalTo(scrollView)
        }
        
        frontView.snp.makeConstraints{ make in
            make.top.equalTo(clearView).offset(StaticSize.s16)
            make.left.equalTo(clearView.snp.left).offset(StaticSize.s16)
            make.right.equalTo(clearView.snp.right).offset(-StaticSize.s16)
            make.bottom.equalTo(ticketNumber).offset(StaticSize.s16)
        }
        
        IIN.snp.makeConstraints { make in
            make.top.equalTo(frontView.snp.top).offset(StaticSize.s16)
            make.left.equalTo(frontView.snp.left).offset(StaticSize.s16)
            make.right.equalTo(frontView.snp.right).offset(-StaticSize.s16)
            make.height.equalTo(StaticSize.s44)
        }
        
        ticketNumber.snp.makeConstraints{ (make) in
            make.top.equalTo(IIN.snp.bottom).offset(StaticSize.s8)
            make.left.equalTo(IIN.snp.left)
            make.right.equalTo(IIN.snp.right)
            make.height.equalTo(StaticSize.s44)
        }
        
        labelButton.snp.makeConstraints { (make) in
            make.top.equalTo(frontView.snp.bottom).offset(StaticSize.s10)
            make.left.equalTo(IIN.snp.left)
            make.right.equalTo(IIN.snp.right)
        }
        
        nextButton.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(self.view.safeAreaLayoutGuide).offset(-StaticSize.s16)
            } else {
               make.bottom.equalTo(self.view.snp.bottom).offset(-StaticSize.s16)
            }
            make.left.equalTo(self.view).offset(StaticSize.s16)
            make.right.equalTo(self.view).offset(-StaticSize.s16)
            make.height.equalTo(StaticSize.s44)
        }
    }
}

extension FastExtensionViewController: UIGestureRecognizerDelegate {
    
    private func tappableLabel() {
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(tapLabelToWebPage(gesture:)))
        self.labelButton.addGestureRecognizer(tapGesture)
        
        let text = NSLocalizedString("\((self.labelButton.text)!)", comment: "")
        let underlineAttriString = NSMutableAttributedString(string: text)
        
        let range1 = (text as NSString).range(of: NSLocalizedString("Правилами проведения онлайн операций", comment: ""))
        
        underlineAttriString.addAttribute(kCTUnderlineStyleAttributeName as NSAttributedString.Key, value: NSUnderlineStyle.single.rawValue, range: range1)
        
        self.labelButton.attributedText = underlineAttriString
        let mutableParagraphStyle = NSMutableParagraphStyle()
        mutableParagraphStyle.alignment = .center
        mutableParagraphStyle.lineSpacing = CGFloat(8)
        
        if let stringLength = labelButton.text?.characters.count {
            underlineAttriString.addAttribute(NSAttributedString.Key.paragraphStyle, value: mutableParagraphStyle, range: NSMakeRange(0, stringLength))
        }
        
        labelButton.attributedText = underlineAttriString
    }
    
    @objc func tapLabelToWebPage(gesture: UITapGestureRecognizer) {
        
        let text = NSLocalizedString("\((self.labelButton.text)!)", comment: "")
        let termsRange = (text as NSString).range(of: NSLocalizedString("Правилами проведения онлайн операций", comment: ""))
        
        if gesture.didTapAttributedTextInLabel(label: self.labelButton, inRange: termsRange) {
            let vc = WebViewController()
            vc.navigationItem.title = "Правила проведения ОНЛАЙН операций".localized()
            vc.webUrl = URL(string: "https://mk-backend.mars.studio/api/ru/onlinerules")
            self.navigationController?.pushViewController(vc)
        } else {
            let vc = WebViewController()
            vc.navigationItem.title = "Правила проведения ОНЛАЙН операций".localized()
            vc.webUrl = URL(string: "https://mk-backend.mars.studio/api/ru/onlinerules")
            self.navigationController?.pushViewController(vc)
        }
    }


    @objc private func nextButtonFunc() {
        
        if IIN.text!.count != 12 {
            showErrorMessage("ИИН не менее 12 символов".localized())
        }
        if ticketNumber.text.count != 16 {
            showErrorMessage("Номер залогового билета 16 символов".localized())
        }
        else if IIN.text?.count == 12 && ticketNumber.text.count == 16 {
            
            let request = ApiRequests.expressProlongation(iin: IIN.text!, loadId: ticketNumber.text!)
            
            SVProgressHUD.show()
            NetworkManager.shared.makeRequest(apiRequest: request) { (result: Result<ExpressProlongation>) in
                
                switch result {
                
                case .success(let data):
                    SVProgressHUD.dismiss()
                    let vc = FastExtensionDetailViewController()
                    vc.data = data
                    self.navigationController?.pushViewController(vc, animated: true)
                case .failure(let error):
                    if let _ = error as? CustomError {
                        SVProgressHUD.dismiss()
                        self.showErrorMessage("Неверный ИИН или пароль. Проверьте введенные данные".localized())
                    } else {
                        SVProgressHUD.showError(withStatus: error.localizedDescription)
                    }
                }
            }
        }
    }
    
    private func showErrorMessage(_ message: String) {
        self.view.addSubviews([textFieldErrors, errorImage])
        
        textFieldErrors.text = message
        
        errorImage.snp.makeConstraints{ make in
            make.top.equalTo(ticketNumber.snp.bottom).offset(StaticSize.s22 - 1)
            make.size.equalTo(StaticSize.s26)
            make.left.equalTo(ticketNumber)
        }
        
        textFieldErrors.snp.makeConstraints{ (make) in
            make.centerY.equalTo(errorImage)
            make.left.equalTo(errorImage.snp.right).offset(8)
            make.right.equalTo(ticketNumber.snp.right)
        }
        
        frontView.snp.makeConstraints{ make in
            make.bottom.equalTo(errorImage).offset(19)
        }
    }
}


extension FastExtensionViewController : UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        guard let text = textField.text else { return true }
        let newLength = text.count + string.count - range.length
        if textField == IIN {
            return newLength <= 12
        }
        else {
            return newLength <= 16
        }
    }
}
