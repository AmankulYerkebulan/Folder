

import UIKit

class StatusAlert: UIView {
    
    private lazy var statusImageView: UIImageView = {
        let view = UIImageView()
        view.image = UIImage(named: "success")
        return view
    }()
    
    private lazy var title: UILabel = {
        let label = UILabel()
        label.text = "Операция прошла успешно".localized()
        label.font = Global.sfMedium(size: StaticSize.s15)
        label.textColor = #colorLiteral(red: 0.3607843137, green: 0.3607843137, blue: 0.3607843137, alpha: 1)
        label.numberOfLines = 0
        label.textAlignment = .center
        return label
    }()
    
    private lazy var alertView: UIView = {
        let view = UIView()
        view.cornerRadius = 5
        view.backgroundColor = Global.white()
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        
        self.backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 0.5)
        self.addSubview(alertView)
        self.alertView.addSubviews([statusImageView,title])
        
        statusImageView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(StaticSize.s24)
            make.left.equalToSuperview().offset(StaticSize.s70)
            make.right.equalToSuperview().offset(-StaticSize.s70)
            make.size.equalTo(StaticSize.s105 + 2)
        }
        title.snp.makeConstraints { (make) in
            make.top.equalTo(statusImageView.snp.bottom).offset(StaticSize.s16)
            make.bottom.equalTo(self.alertView.snp.bottom).offset(-StaticSize.s16)
            make.left.equalTo(self.alertView.snp.left).offset(StaticSize.s16)
            make.right.equalTo(self.alertView.snp.right).offset(-StaticSize.s16)
        }
        alertView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(StaticSize.s184 - 4)
            make.left.equalToSuperview().offset(StaticSize.s60 + 4)
            make.right.equalToSuperview().offset(-(StaticSize.s60 + 4))
        }
    }
    
    func setUpStatus(title: String) {
        self.title.text = title
    }
    
}
