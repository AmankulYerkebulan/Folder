
import UIKit
import ValueStepper

class ZaimTableViewCell: UITableViewCell {
    
    let picker = UIDatePicker()
    private var index = 0
    
    //Не трогать
    lazy var myTextFiledValue: UITextField = {
        let view = UITextField(frame: CGRect(x: 0, y: 0, width: 30, height: 30))
        view.keyboardType = .numberPad
        view.textColor = .clear
        view.tintColor = .clear
        view.keyboardToolbar.doneBarButton.setTarget(self, action: #selector(doneButtonClicked))
        view.addTarget(self, action: #selector(textDidChange), for: UIControl.Event.editingChanged)
        return view
    }()
    ////////
    
    private lazy var pickerView: UIPickerView = {
        let pickerView = UIPickerView()
        pickerView.delegate = self
        pickerView.dataSource = self
        return pickerView
    }()
    
    lazy var valueStepper: ValueStepper = {
        let stepper = ValueStepper()
        stepper.tintColor = UIColor(hexString: "#297FCA")
        stepper.enableManualEditing = true
        stepper.autorepeat = true
        stepper.stepValue = 1
        stepper.backgroundButtonColor = .white
        stepper.backgroundLabelColor = .white
        stepper.disabledIconButtonColor = UIColor(hexString: "#297FCA")!
        stepper.disabledBackgroundButtonColor = .white
        stepper.labelTextColor = UIColor(hexString: "#297FCA")!
        stepper.borderColor = UIColor(hexString: "#297FCA")
        stepper.borderWidth = 1
        stepper.enableManualEditing = false
        let gesture = UITapGestureRecognizer(target: self, action: #selector(valueIsTap))
        stepper.valueLabel.addGestureRecognizer(gesture)
        stepper.valueLabel.isUserInteractionEnabled = true
        stepper.valueLabel.addSubview(myTextFiledValue)
        return stepper
    }()
    
    var pickerDataSource:[String] = []

    lazy var minimum: UILabel = {
        let label = UILabel()
        label.text = "Мин: 1"
        return label
    }()
    
    lazy var maximum: UILabel = {
        let label = UILabel()
        label.text = "Макс: 55"
        return label
    }()
    
    lazy var zaimLabel: UILabel = {
        let label = UILabel()
        label.text = "Test"
        return label
    }()
    
    lazy var kalendarBtn : UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "Today"), for: .normal)
        button.addTarget(self, action: #selector(showPickerView), for: .touchUpInside)
        return button
    }()
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
        setupConstraints()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    @objc private func valueIsTap() {
        
    }
    
    @objc private func doneButtonClicked() {
        if let text = valueStepper.valueLabel.text {
            if text.isEmpty == false {
                valueStepper.value = Double(text)!
            } else {
                valueStepper.value = valueStepper.minimumValue
            }
        }
    }
    
    @objc private func textDidChange(textField: UITextField) {
        if textField.text?.isEmpty == false {
            let value = Int(textField.text!)!
            if Int(valueStepper.maximumValue) < value {
                valueStepper.valueLabel.text = "\(Int(valueStepper.maximumValue))"
                self.myTextFiledValue.text = valueStepper.valueLabel.text
            } else if Int(valueStepper.minimumValue) > value {
                valueStepper.valueLabel.text = "\(Int(valueStepper.minimumValue))"
                self.myTextFiledValue.text = valueStepper.valueLabel.text
            } else {
                valueStepper.valueLabel.text = textField.text
            }
        } else {
            valueStepper.valueLabel.text = textField.text
        }
    }
    
    @objc func showPickerView() {
        let toolBar = UIToolbar()

        toolBar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Выбрать".localized(), style: UIBarButtonItem.Style.plain, target: self, action: #selector(donePicker))
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        toolBar.setItems([flexibleSpace, doneButton], animated: false)

        let dummy = UITextField(frame: CGRect.zero)
        self.addSubview(dummy)
        
        dummy.inputAccessoryView = toolBar
        dummy.inputView = pickerView
        self.pickerView.selectRow(Int(valueStepper.value - 1), inComponent: 0, animated: false)
        dummy.becomeFirstResponder()
    }
    
    @objc func donePicker()
    {
        let date = (Calendar.current as NSCalendar).date(byAdding: .day, value: self.index + 1, to: Date(), options: [])!
        let format = DateFormatter()
        format.dateFormat = "dd.MM.yyyy"
        let formattedDate = format.string(from: date)
        zaimLabel.text = "Новый срок".localized() + ": \(formattedDate)"
        self.valueStepper.value = Double(self.index + 1)
        
        NotificationCenter.default.post(name: NSNotification.Name("Selecteday"), object: valueStepper)
        
        self.endEditing(true)
    }
    
    private func setupViews() {
        self.addSubviews([valueStepper, zaimLabel, minimum, maximum, kalendarBtn])
    }
    
    private func setupConstraints() {
        valueStepper.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(8)
            make.centerX.equalToSuperview()
            make.width.equalTo(100)
        }
        
        minimum.snp.makeConstraints { (make) in
            make.centerY.equalTo(valueStepper)
            make.right.equalTo(valueStepper.snp.left).offset(-16)
        }
        
        maximum.snp.makeConstraints { (make) in
            make.centerY.equalTo(valueStepper)
            make.right.equalToSuperview()
            make.left.equalTo(valueStepper.snp.right).offset(16)
        }
        
        
        zaimLabel.snp.makeConstraints { (make) in
            make.top.equalTo(valueStepper.snp.bottom).offset(18)
            make.left.equalToSuperview().offset(16)
            make.bottom.equalToSuperview().offset(-10)
            make.right.equalTo(kalendarBtn.snp.left).offset(16)
        }
        
        kalendarBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(zaimLabel)
            make.right.equalToSuperview().offset(-16)
        }
        
    }
    
    func setUpMinMaxLbl(min: String,max: String) {
        self.minimum.text = "Мин".localized() + ": " + min
        self.maximum.text = "Макс".localized() + ": " + max
    }
    
}


extension ZaimTableViewCell: UIPickerViewDelegate, UIPickerViewDataSource {

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerDataSource.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerDataSource[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.index = row
    }
    
}

