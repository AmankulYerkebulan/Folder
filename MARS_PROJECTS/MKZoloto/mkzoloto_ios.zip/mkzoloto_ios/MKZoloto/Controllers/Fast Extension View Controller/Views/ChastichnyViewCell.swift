
import UIKit
import ValueStepper

class ChastichnyViewCell: UITableViewCell {
    
    static let id = "ChastichnyViewCells"
    
    private lazy var title: UILabel = {
        let label = UILabel()
        label.font = Global.sfMedium(size: StaticSize.s15)
        label.textColor = Global.dark()
        label.text = "Сумма частичного погашения".localized()
        return label
    }()
    
    private lazy var textField: UITextField = {
        let view = UITextField()
        let centeredParagraphStyle = NSMutableParagraphStyle()
        centeredParagraphStyle.alignment = .center
        let attributedPlaceholder = NSAttributedString(string: "Введите сумму".localized(), attributes: [NSAttributedString.Key.paragraphStyle: centeredParagraphStyle])
        view.attributedPlaceholder = attributedPlaceholder
        view.cornerRadius = 4
        view.backgroundColor = Global.grey()
        view.borderColor = Global.textFiledBorderColor()
        view.borderWidth = 1
        return view
    }()
    
    private lazy var maxLbl: UILabel = {
        let label = UILabel()
        label.textColor = #colorLiteral(red: 0.6470588235, green: 0.6470588235, blue: 0.6470588235, alpha: 1)
        label.font = Global.sfRegular(size: StaticSize.s12)
        label.text = "Минимально - ".localized() + "500₸, " + "максимально - ".localized() + "4 256₸"
        return label
    }()
    
    private lazy var mainViewTextview: UIView = {
        let view = UIView()
        view.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        return view
    }()
    
    private lazy var ostatokView: UIView = {
        let view = UIView()
        view.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        return view
    }()
    
    private lazy var ostatokLbl: UILabel = {
        let label = UILabel()
        label.font = Global.sfMedium(size: StaticSize.s15)
        label.textColor = Global.dark()
        label.text = "Остаток суммы займа".localized()
        return label
    }()
    
    private lazy var afterPurchase: UILabel = {
        let label = UILabel()
        label.font = Global.sfRegular(size: StaticSize.s12)
        label.textColor = Global.black().withAlphaComponent(0.5)
        label.text = "После оплаты".localized()
        return label
    }()
    
    private lazy var ostatokresultLbl: UILabel = {
        let label = UILabel()
        label.font = Global.sfBold(size: StaticSize.s15)
        label.textColor = Global.dark()
        label.text = "2 487₸"
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
        setupConstraints()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        self.backgroundColor = .clear
        self.addSubview(mainViewTextview)
        self.addSubview(ostatokView)
        mainViewTextview.addSubviews([title,textField,maxLbl])
        ostatokView.addSubviews([ostatokLbl,ostatokresultLbl,afterPurchase])
    }
    
    private func setupConstraints() {
        mainViewTextview.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(StaticSize.s16)
            make.width.equalToSuperview()
        }
        title.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(StaticSize.s13)
        }
        textField.snp.makeConstraints { (make) in
            make.top.equalTo(title.snp.bottom).offset(StaticSize.s8)
            make.left.equalToSuperview().offset(StaticSize.s16)
            make.right.equalToSuperview().offset(-StaticSize.s16)
            make.height.equalTo(StaticSize.s44)
        }
        maxLbl.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(textField.snp.bottom).offset(StaticSize.s8)
            make.bottom.equalToSuperview().offset(-StaticSize.s8)
        }
        ostatokView.snp.makeConstraints { (make) in
            make.top.equalTo(mainViewTextview.snp.bottom).offset(StaticSize.s16)
            make.bottom.equalToSuperview()
            make.width.equalToSuperview()
        }
        ostatokLbl.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(StaticSize.s16)
            make.top.equalToSuperview().offset(StaticSize.s6)
        }
        afterPurchase.snp.makeConstraints { (make) in
            make.left.equalTo(ostatokLbl)
            make.top.equalTo(ostatokLbl.snp.bottom)
            make.bottom.equalToSuperview().offset(-StaticSize.s6)
        }
        ostatokresultLbl.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-StaticSize.s16)
        }
    }
}
