
import UIKit
import ValueStepper

class OplataZaimViewCell: UITableViewCell {
    
    lazy var zaimLabel: UILabel = {
        let label = UILabel()
        label.font = Global.sfRegular(size: 12)
        return label
    }()
    
    lazy var prodlenieLabel: UILabel = {
        let label = UILabel()
        label.font = Global.sfRegular(size: 12)
        label.textColor = Global.blue()
        return label
    }()
    
    lazy var zaimNumberLabel: UILabel = {
        let label = UILabel()
        label.font = Global.sfRegular(size: 12)
        label.textAlignment = .right
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
        setupConstraints()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    

    private func setupViews() {
        self.addSubviews([zaimLabel, zaimNumberLabel, prodlenieLabel])
    }
    
    private func setupConstraints() {
        zaimLabel.snp.makeConstraints { (make) in
            make.top.left.equalToSuperview().offset(16)
            make.right.equalTo(self.zaimNumberLabel.snp.left).offset(-16)
        }
        
        prodlenieLabel.snp.makeConstraints { (make) in
            make.left.right.equalTo(zaimLabel)
            make.top.equalTo(zaimLabel.snp.bottom).offset(6)
        }
        
        zaimNumberLabel.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-16)
            make.centerY.equalToSuperview()
        }
    }
}
