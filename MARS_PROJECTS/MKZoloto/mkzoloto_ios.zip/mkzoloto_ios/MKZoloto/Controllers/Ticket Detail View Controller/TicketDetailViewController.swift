
import Foundation
import UIKit
import SwifterSwift
import SnapKit
import Alamofire
import SVProgressHUD

class TicketDetailViewController: UIViewController {
    
    private var textLabelArray = ["Филиал".localized(), "Срок займа".localized(), "Гарантированный срок".localized(),"", "Остаток суммы займа".localized(), "Проценты к оплате".localized(), "Итого к оплате".localized()]
    
    private var detailTextLabelArray = ["Орбита", "10.01.2019", "10.02.2019", "10525 тг", "2297 тг", "12297 тг"]
    
    var loanData: LoanModel?
    // структура Cell data находится в OcenkaKapitalaViewController
    private var tableViewData = [CellData]()
    
    private lazy var tableView : UITableView = {
        let tView = UITableView()
        tView.dataSource = self
        tView.delegate = self
        tView.register(cellWithClass: UITableViewCell.self)
        tView.register(cellWithClass: TicketDetailTableCell.self)
        tView.backgroundColor = Global.grey()
        tView.separatorStyle = .none
        return tView
    }()

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.addSubviews([tableView])
        self.view.backgroundColor = Global.grey()
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        tableViewData = [
            CellData(opened: false, title: "Кольцо", sectionData: ["Проба золота".localized(), "Вес изделия, грамм".localized(), "Содержание Au999, грамм".localized()]),
            CellData(opened: false, title: "Бриллиант", sectionData: ["Проба золота", "Вес изделия, грамм", "Содержание Au999, грамм"]),
            CellData(opened: false, title: "Наушники", sectionData: ["Проба золота", "Вес изделия, грамм", "Содержание Au999, грамм"])
        ]
        
        let customLbl = UILabel(frame: .zero)
        customLbl.halfTextColorChange(fullText: self.title ?? "", changeText: String((self.title ?? "").characters.suffix(8)), fontSize: StaticSize.s17)
        customLbl.textColor = Global.dark()
        self.navigationItem.titleView = customLbl
    }
}


extension TicketDetailViewController: UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        guard let data = self.loanData else {return 0}
        return data.products.count + 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        guard let data = self.loanData else {return 0}
        
        if section == 0 {
            return textLabelArray.count
        }
        else {
            if data.products[section - 1].isOpened == true {
                return 4
            } else {
                return 1
            }
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        guard let data = self.loanData else {return UITableViewCell()}
        
        if indexPath.section == 0 {

            let cell = UITableViewCell(style: .value1, reuseIdentifier: String(describing: UITableViewCell.self))
            cell.textLabel?.text = textLabelArray[indexPath.row]
            cell.textLabel?.textColor = Global.dark()
            cell.textLabel?.font = Global.sfMedium(size: StaticSize.s15)
            cell.detailTextLabel?.textColor = Global.dark()
            cell.detailTextLabel?.font = Global.sfMedium(size: StaticSize.s15)
            cell.accessoryView = nil
            cell.selectionStyle = .none
            cell.setUpCellShadow()
            switch indexPath.row {
            case 0:
                cell.detailTextLabel?.attributedText = NSAttributedString(string: "\(data.point)", attributes:
                    [.underlineStyle: NSUnderlineStyle.single.rawValue])
                cell.accessoryView = UIImageView(image: #imageLiteral(resourceName: "Icon"))
            case 1:
                cell.detailTextLabel?.text = data.loanTerm
            case 2:
                cell.detailTextLabel?.text = data.guarantyTime
            case 4:
                cell.detailTextLabel?.text = "\(data.loanBalance)".formatToNorm() + " ₸"
            case 6:
                cell.detailTextLabel?.text = "\(Int(data.returnTotal))".formatToNorm() + " ₸"
                cell.detailTextLabel?.font = Global.sfBold(size: StaticSize.s15)
            default:
                print("")
            }
            
            if indexPath.row == 3 {
                let cell = UITableViewCell(style: .value1, reuseIdentifier: String(describing: UITableViewCell.self))
                cell.backgroundColor = Global.grey()
                return cell
            }
            
            if indexPath.row == 5 {

                let cell = TicketDetailTableCell(style: .default, reuseIdentifier: String(describing: TicketDetailTableCell.self))
                cell.selectionStyle = .none
                cell.setUpCellShadow()
                cell.leftTitle.textColor = Global.dark()
                cell.leftTitle.font = Global.sfMedium(size: StaticSize.s15)
                cell.rightTitle.textColor = Global.dark()
                cell.rightTitle.font = Global.sfMedium(size: StaticSize.s15)
                cell.leftTitle.text = textLabelArray[indexPath.row]
                cell.rightTitle.text = "\(Int(data.defaultPay))".formatToNorm() + " ₸"
                cell.leftSubtitle.text = "Проценты по займу".localized()
                cell.rightSubtitle.text = "\(data.percentPay)".formatToNorm() + " ₸"
                cell.leftSubtitle.textColor = Global.dark()
                cell.leftSubtitle.font = Global.sfMedium(size: StaticSize.s12)
                cell.rightSubtitle.textColor = Global.dark()
                cell.rightSubtitle.font = Global.sfMedium(size: StaticSize.s12)
                cell.leftSubTitle2.text = "Проценты за просрочку".localized()
                cell.rightSubTitle2.text = "\(data.percentDelayLoan)".formatToNorm() + " ₸"
                cell.leftSubTitle2.textColor = Global.dark()
                cell.leftSubTitle2.font = Global.sfMedium(size: StaticSize.s12)
                cell.rightSubTitle2.textColor = Global.dark()
                cell.rightSubTitle2.font = Global.sfMedium(size: StaticSize.s12)
                return cell
            }
            return cell
        } else {
            if indexPath.row == 0 {
                
                let cell = UITableViewCell(style: .subtitle, reuseIdentifier: String(describing: UITableViewCell.self))
                cell.selectionStyle = .none
                cell.accessoryView = UIImageView(image: #imageLiteral(resourceName: "Icon"))
                cell.textLabel?.text = data.products[indexPath.section - 1].name
                cell.setUpCellShadow()
                return cell
            } else {
                let cell = UITableViewCell(style: .value1, reuseIdentifier: String(describing: UITableViewCell.self))
                cell.selectionStyle = .none
                if indexPath.row == 1 {
                    cell.textLabel?.text = "Проба золота".localized()
                    cell.detailTextLabel?.text = data.products[indexPath.section - 1].probe
                } else if indexPath.row == 2 {
                    cell.textLabel?.text = "Вес изделия, грамм".localized()
                    cell.detailTextLabel?.text = data.products[indexPath.section - 1].weight
                } else {
                    cell.textLabel?.text = "Содержание Au999, грамм".localized()
                    cell.detailTextLabel?.text = data.products[indexPath.section - 1].au999content
                }
                return cell
            }
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.section == 0 && indexPath.row == 0 {
            
            if let data = loanData,
                let pointId = data.point_id {
                
                SVProgressHUD.show()
                NetworkManager.shared.makeRequest(apiRequest: ApiRequests.getPointById(id: pointId)) { (result: Result<BranchModel>) in
                    
                    if let navigation = self.tabBarController?.viewControllers![1] as? UINavigationController,
                        let controller = navigation.viewControllers.first as? BranchesViewController
                        {
                            switch result {
                            case .failure(let error):
                                if let customError = error as? CustomError {
                                    SVProgressHUD.showError(withStatus: customError.errorDescription)
                                } else {
                                    SVProgressHUD.showError(withStatus: error.localizedDescription)
                                }
                            case .success(let data):
                               controller.branchViewModel.currentCity?.onNext(CityModel(name: data.city,cityEnglish:""))
                               controller.branchModel = data
                               self.tabBarController?.selectedIndex = 1
                               SVProgressHUD.dismiss()
                            }
                    }
                }
            }
        } else if indexPath.section == 1 {
            let vc = DetailitemViewController()
            let product = loanData?.products[indexPath.row]
            vc.data = PurchasedItem(name: product?.name ?? "", prob: product?.probe ?? "0", weight: product?.weight ?? "0",au: product?.au999content ?? "")
            vc.title = product?.name ?? ""
            vc.data?.au999 = product?.au999content
            vc.data?.description = product?.description
            vc.data?.image = product?.image
            self.navigationController?.pushViewController(vc)
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 1 {
            let view = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 52))
            let labeel = UILabel(frame: CGRect(x: 18, y: 15, width: UIScreen.main.bounds.width, height: 44))
            labeel.text = "МОИ ИЗДЕЛИЯ".localized()
            labeel.textColor = #colorLiteral(red: 0.2, green: 0.2, blue: 0.2, alpha: 0.5)
            labeel.font = Global.sfRegular(size: StaticSize.s12 + 1)
            view.addSubview(labeel)
            view.backgroundColor = .clear
            return view
        } else {
            let view = UIView(frame: CGRect(x: 0, y: 0, width: 0, height: 0))
            return view
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 1 {
            return 52
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 3 && indexPath.section == 0 {
            return StaticSize.s8
        }
        return UITableView.automaticDimension
    }
    
}
