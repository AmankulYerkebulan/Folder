
import UIKit
import SwifterSwift
import SnapKit

class TicketDetailTableCell: UITableViewCell {
    
    lazy var leftTitle : UILabel = {
        let label = UILabel()
        label.font = UIFont(name: "AvenirNext-Medium", size: 17)
        label.textColor = .black
        return label
    }()
    
    lazy var rightTitle : UILabel = {
        let label = UILabel()
        label.font = UIFont(name: "AvenirNext-Medium", size: 17)
        label.textColor = .black
        return label
    }()
    
    lazy var leftSubtitle : UILabel = {
        let label = UILabel()
        label.font = UIFont(name: "AvenirNext-Medium", size: 12)
        label.textColor = .black
        return label
    }()
    
    lazy var rightSubtitle : UILabel = {
        let label = UILabel()
        label.font = UIFont(name: "AvenirNext-Medium", size: 12)
        label.textColor = .black
        return label
    }()
    
    lazy var leftSubTitle2 : UILabel = {
        let label = UILabel()
        label.font = UIFont(name: "AvenirNext-Medium", size: 12)
        label.textColor = .black
        return label
    }()
    
    lazy var rightSubTitle2 : UILabel = {
        let label = UILabel()
        label.font = UIFont(name: "AvenirNext-Medium", size: 12)
        label.textColor = .black
        return label
    }()
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("Some error")
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)

        self.setupViews()
        self.setupConstraints()
    }
}

extension TicketDetailTableCell {

    private func setupViews() {

        self.addSubviews([leftTitle, rightTitle, leftSubtitle, rightSubtitle, leftSubTitle2, rightSubTitle2])
    }
    
    private func setupConstraints() {
        
        leftTitle.snp.makeConstraints{ make in
            make.top.equalToSuperview().offset(10)
            make.left.equalToSuperview().offset(16)
        }
        
        rightTitle.snp.makeConstraints{ make in
            make.top.equalToSuperview().offset(10)
            make.right.equalToSuperview().offset(-16)
        }
        
        leftSubtitle.snp.makeConstraints { (make) in
            make.top.equalTo(leftTitle.snp.bottom).offset(5)
            make.left.right.equalTo(leftTitle)
        }
        
        rightSubtitle.snp.makeConstraints{ make in
            make.centerY.equalTo(leftSubtitle)
            make.right.equalToSuperview().offset(-16)
        }
        
        leftSubTitle2.snp.makeConstraints { (make) in
            make.top.equalTo(leftSubtitle.snp.bottom).offset(5)
            make.left.right.equalTo(leftTitle)
            make.bottom.equalToSuperview().offset(-10)
        }
        
        rightSubTitle2.snp.makeConstraints{ make in
            make.centerY.equalTo(leftSubTitle2)
            make.right.equalToSuperview().offset(-16)
        }
    }
}
