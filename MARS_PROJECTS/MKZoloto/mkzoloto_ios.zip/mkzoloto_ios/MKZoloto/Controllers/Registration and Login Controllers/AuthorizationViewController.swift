
import UIKit
import SnapKit
import LocalAuthentication
import Alamofire
import SVProgressHUD
import IQKeyboardManagerSwift

class AuthorizationViewController: UIViewController {
    
    var isTouchIdUsable = false
    
    private lazy var profileController: UINavigationController = {
        var cabinet: UIViewController = CabinetViewController()
        cabinet.tabBarItem = UITabBarItem(title: "Мой Ломбард".localized(), image: UIImage(named: "Profile")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal), selectedImage: UIImage(named: "ProfileS")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal))
        let nvController = NavigationController(rootViewController: cabinet)
        return nvController
    }()
    
    private lazy var labelButton: UILabel = {
        let label = UILabel()
        label.font = Global.sfRegular(size: StaticSize.s12)
        label.textColor = Global.dark()
        label.text = "Продолжая операцию, Вы соглашаетесь с\nПравилами проведения онлайн операций".localized()
        label.textAlignment = .center
        label.numberOfLines = 0
        label.isUserInteractionEnabled = true
        return label
    }()
    
    private lazy var logoImageView: UIImageView = {
        let view = UIImageView()
        view.image = UIImage(named: "newLogo")
        view.contentMode = .scaleAspectFill
        return view
    }()
    
    private lazy var IIN : VSTextField = {
        let textField = VSTextField()
        textField.addPadding(.left(16))
        textField.placeholder = "Введите ИИН".localized()
        textField.setUptextFiled()
        textField.delegate = self
        textField.keyboardType = .numberPad
        textField.setFormatting("############", replacementChar: "#")
        return textField
    }()
    
    private lazy var password : UITextField = {
        let textField = UITextField()
        textField.addPadding(.left(16))
        textField.placeholder = "Введите пароль".localized()
        textField.setUptextFiled()
        textField.layer.zPosition = 1
        textField.isSecureTextEntry = true
        if let myImage = UIImage(named: "Eye") {
            textField.withImage(direction: .Right, image: myImage, colorSeparator: .clear, colorBorder: .clear)
        }
        return textField
    }()
    
    private lazy var mainView : UIView = {
        let view = UIView()
        view.backgroundColor = Global.white()
        view.cornerRadius = 5
        view.addShadow(ofColor: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), radius: 3, offset: .zero, opacity: 0.1)
        return view
    }()
    
    private lazy var hiddenButton : UIButton = {
        let button = UIButton()
        button.layer.zPosition = 5
        button.addTarget(self, action: #selector(showHiddenPassword), for: .touchUpInside)
        return button
    }()
    
    private lazy var phoneNumber : VSTextField = {
        let textField = VSTextField()
        textField.addPadding(.left(16))
        textField.placeholder = "Введите номер телефона".localized()
        textField.setUptextFiled()
        textField.delegate = self
        textField.keyboardType = .numberPad
        textField.isHidden = true
        textField.setFormatting("+#(###)-###-##-##", replacementChar: "#")
        return textField
    }()
    
    private lazy var nextButton : UIButton = {
        let button = UIButton()
        button.yellowBtnProperty()
        button.setTitle("Войти".localized(), for: UIControl.State.normal)
        button.addTarget(self, action: #selector(buttonCheck(_:)), for: .touchUpInside)
        return button
    }()
    
    private lazy var forgotPassword : UILabel = {
        let label = UILabel()
        label.font = Global.sfRegular(size: StaticSize.s12)
        label.textColor = Global.textFiledPlaceholderColor()
        label.text = "Забыли пароль?".localized()
        label.isUserInteractionEnabled = true
        return label
    }()
    
    private lazy var touchIDbtn : UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "TouchID"), for: .normal)
        button.addTarget(self, action: #selector(touchIDauth(_button:)), for: .touchUpInside)
        return button
    }()
    
    private lazy var segmentControl: UISegmentedControl = {
        let items               = ["АВТОРИЗАЦИЯ".localized(), "РЕГИСТРАЦИЯ".localized()]
        let segmentedController = UISegmentedControl(items: items)
        let frame = UIScreen.main.bounds
        segmentedController.frame                = CGRect(x: 0, y: 0, width: view.bounds.width, height: 44 )
        segmentedController.layer.cornerRadius   = 5.0
        segmentedController.tintColor            = Global.dark()
        segmentedController.setTitleTextAttributes([NSAttributedString.Key.font : Global.sfSemiBold(size: StaticSize.s12),NSAttributedString.Key.foregroundColor:Global.dark()], for: .normal)
        segmentedController.selectedSegmentIndex = 0
        segmentedController.addTarget(self, action: #selector(changeViews(sender:)), for: .valueChanged)
        return segmentedController
    }()
    
    private func showAlertController(_ message: String) {
        let alertController = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupButtons()
        setupConstraints()
        self.hideKeyboard()
        setUpPrivacy()
        if isTouchIdUsable == true {
            self.touchIDauth(_button: touchIDbtn)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.tabBarController?.tabBar.isHidden = false
        
        IQKeyboardManager.shared.enableAutoToolbar = false
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        IQKeyboardManager.shared.enableAutoToolbar = true
    }
    
}


extension AuthorizationViewController {
    
    private func setupButtons() {
        
        self.mainView.addSubviews([IIN,
                                   password,
                                   hiddenButton,
                                   phoneNumber,logoImageView])
        self.view.addSubviews([segmentControl,
                                     mainView,
                                     nextButton,
                                     forgotPassword,
                                     touchIDbtn,labelButton])
        
        segmentControl.addUnderlineForSelectedSegment()
        self.view.backgroundColor = Global.grey()
        navigationItem.title = "МОЙ ЛОМБАРД".localized().uppercased()
        self.navigationController?.setUpShadow()
        self.navigationController?.navigationBar.barTintColor = Global.white()
        self.tappableLabel()
    }
    
    private func setupConstraints() {
        
        segmentControl.snp.makeConstraints { make in
            make.top.equalTo(self.view.snp.top).offset(self.navigationController!.navigationBar.frame.height + UIApplication.shared.statusBarFrame.height)
            make.left.equalTo(self.view.snp.left)
            make.right.equalTo(self.view.snp.right)
            make.height.equalTo(44)
        }
        
        mainView.snp.makeConstraints { (make) in
            make.top.equalTo(segmentControl.snp.bottom).offset(StaticSize.s16)
            make.left.equalTo(self.view.snp.left).offset(StaticSize.s16)
            make.right.equalTo(self.view.snp.right).offset(-StaticSize.s16)
        }
        
        labelButton.snp.makeConstraints { (make) in
            make.top.equalTo(mainView.snp.bottom).offset(StaticSize.s10)
            make.left.equalTo(IIN.snp.left)
            make.right.equalTo(IIN.snp.right)
        }
        
        logoImageView.snp.makeConstraints { (make) in
            make.top.equalTo(mainView.snp.top).offset(StaticSize.s23)
            make.left.equalTo(self.mainView).offset(StaticSize.s46)
            make.right.equalTo(self.mainView).offset(-StaticSize.s46)
            make.height.equalTo(StaticSize.s28)
        }
        
        IIN.snp.makeConstraints { make in
            make.top.equalTo(logoImageView.snp.bottom).offset(StaticSize.s23)
            make.left.equalTo(self.mainView).offset(StaticSize.s16)
            make.right.equalTo(self.mainView).offset(-StaticSize.s16)
            make.height.equalTo(StaticSize.s44)
        }
        
        password.snp.makeConstraints { make in
            make.top.equalTo(IIN.snp.bottom).offset(StaticSize.s8)
            make.left.equalTo(self.mainView).offset(StaticSize.s16)
            make.right.equalTo(self.mainView).offset(-StaticSize.s16)
            make.height.equalTo(StaticSize.s44)
            make.bottom.equalTo(mainView.snp.bottom).offset(-StaticSize.s16)
        }
        
        hiddenButton.snp.makeConstraints { make in
            make.top.right.bottom.equalTo(password)
            make.height.equalTo(StaticSize.s44)
        }
        
        phoneNumber.snp.makeConstraints { make in
            make.top.equalTo(IIN.snp.bottom).offset(StaticSize.s8)
            make.left.equalTo(self.mainView).offset(StaticSize.s16)
            make.right.equalTo(self.mainView).offset(-StaticSize.s16)
            make.height.equalTo(StaticSize.s44)
            make.bottom.equalTo(mainView.snp.bottom).offset(-StaticSize.s16)
        }
        
        nextButton.snp.makeConstraints { make in
            make.top.equalTo(labelButton.snp.bottom).offset(StaticSize.s10)
            make.left.equalTo(self.mainView).offset(StaticSize.s16)
            make.right.equalTo(self.mainView).offset(-StaticSize.s16)
            make.height.equalTo(StaticSize.s44)
        }
        
        forgotPassword.snp.makeConstraints { make in
            make.top.equalTo(nextButton.snp.bottom).offset(StaticSize.s16)
            make.centerX.equalTo(nextButton)
            make.height.equalTo(StaticSize.s14)
        }
        
        touchIDbtn.snp.makeConstraints{ make in
            make.top.equalTo(forgotPassword.snp.bottom).offset(StaticSize.s30 + 2)
            make.centerX.equalTo(forgotPassword)
            make.height.equalTo(StaticSize.s44)
            make.width.equalTo(StaticSize.s44)
        }
    }
}

extension AuthorizationViewController {
    
    private func tappableLabel() {
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(tapLabelToWebPage(gesture:)))
        self.labelButton.addGestureRecognizer(tapGesture)
        
        let text = NSLocalizedString("\((self.labelButton.text)!)", comment: "")
        let underlineAttriString = NSMutableAttributedString(string: text)
        
        let range1 = (text as NSString).range(of: NSLocalizedString("Правилами проведения онлайн операций".localized(), comment: ""))
        
        underlineAttriString.addAttribute(kCTUnderlineStyleAttributeName as NSAttributedString.Key, value: NSUnderlineStyle.single.rawValue, range: range1)
        
        self.labelButton.attributedText = underlineAttriString
        let mutableParagraphStyle = NSMutableParagraphStyle()
        mutableParagraphStyle.alignment = .center
        mutableParagraphStyle.lineSpacing = CGFloat(8)
        
        if let stringLength = labelButton.text?.characters.count {
            underlineAttriString.addAttribute(NSAttributedString.Key.paragraphStyle, value: mutableParagraphStyle, range: NSMakeRange(0, stringLength))
        }
        
        labelButton.attributedText = underlineAttriString
    }
    
    @objc func tapLabelToWebPage(gesture: UITapGestureRecognizer) {
        
        let text = NSLocalizedString("\((self.labelButton.text)!)", comment: "")
        let termsRange = (text as NSString).range(of: NSLocalizedString("Правилами проведения онлайн операций", comment: ""))
        
        if gesture.didTapAttributedTextInLabel(label: self.labelButton, inRange: termsRange) {
            let vc = WebViewController()
            vc.webUrl = URL(string: "https://mk-backend.mars.studio/api/ru/onlinerules")
            vc.navigationItem.title = "Правила проведения ОНЛАЙН операций".localized()
            self.navigationController?.pushViewController(vc)
        } else {
            let vc = WebViewController()
            vc.webUrl = URL(string: "https://mk-backend.mars.studio/api/ru/onlinerules")
            vc.navigationItem.title = "Правила проведения ОНЛАЙН операций".localized()
            self.navigationController?.pushViewController(vc)
        }
    }
    
    @objc private func changeViews(sender: UISegmentedControl) {
        switch segmentControl.selectedSegmentIndex {
        case 0:
            UIView.animate(withDuration: 0.2) {
                self.segmentControl.changeUnderlinePosition()
                self.password.isHidden = false
                self.forgotPassword.isHidden = false
                self.phoneNumber.isHidden = true
                self.touchIDbtn.isHidden = false
                self.nextButton.setTitle("Войти", for: .normal)
                self.logoImageView.image = UIImage(named: "newLogo")
            }
        case 1:
            UIView.animate(withDuration: 0.2) {
                self.segmentControl.changeUnderlinePosition()
                self.password.isHidden = true
                self.phoneNumber.isHidden = false
                self.forgotPassword.isHidden = true
                self.touchIDbtn.isHidden = true
                self.nextButton.setTitle("Регистрация".localized(), for: .normal)
                self.logoImageView.image = UIImage(named: "newLogo")
            }
        default:
            break
        }
    }

    // Авторизация и регистрация (в зависимости от Title)
    @objc private func buttonCheck(_ button: UIButton) {

        if button.titleLabel?.text == "Войти".localized() {

            if (IIN.isEmpty == true) || (password.isEmpty == true) {

                let alert = UIAlertController(title: "Alert", message: "IIN or Password is wrong", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
                    switch action.style{
                    case .default:
                        print("default")
                    case .cancel:
                        print("cancel")
                    case .destructive:
                        print("destructive")
                    }}))
                self.present(alert, animated: true, completion: nil)
            }
            else {
                self.login(iin: IIN.text,password: password.text)
            }
        }

        if button.titleLabel?.text == "Регистрация".localized() {

            registrateUser()
            
        }
    }
    
    //Кнопка TouchID которая вызывает авторизацию через TouchID
    @objc private func touchIDauth(_button: UIButton) {
        
        let context = LAContext()
        
        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: nil) {
            let reason = "Touch ID"
            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason, reply:
                {(success, error) in
                    if success {
                        if let userAcceess = StoreManager.shared().getUserAccessTouchId(),
                            let iin = userAcceess["iin"],
                            let password = userAcceess["password"] {
                            self.login(iin: iin, password: password)
                        } else {
                            self.showAlertController("At first login by iin and password")
                        }
                    } else {
                        self.showAlertController("Touch ID Authentication Failed")
                    }
            })
        }
        else {
            showAlertController("Touch ID not available")
        }
    }
}

extension AuthorizationViewController {
    private func setUpPrivacy() {
        let gesture = UITapGestureRecognizer(target: self, action: #selector(showForgotPass))
        self.forgotPassword.addGestureRecognizer(gesture)
    }
    
    @objc private func showForgotPass() {
        let vc = ForgotPasswordViewController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    // Скрыть/Показать пароль по нажатию на кнопку
    @objc private func showHiddenPassword() {
        self.password.isSecureTextEntry = !self.password.isSecureTextEntry
        
        if self.password.isSecureTextEntry == true {
            password.withImage(direction: .Right, image: UIImage(named: "Eye")!, colorSeparator: .clear, colorBorder: .clear)
        } else {
            password.withImage(direction: .Right, image: UIImage(named: "hide")!, colorSeparator: .clear, colorBorder: .clear)
        }
    }

    // При авторизации меняет вьюшку другую
    private func login(iin: String?,password: String?) {
        
        guard let iin = iin, let password = password else {
            return
        }
        
        let request = ApiRequests.login(iin: iin, password: password)
        SVProgressHUD.show()

        NetworkManager.shared.makeRequest(apiRequest: request) { (result: Result<LoginModel>) in

            switch result {
            case .failure(let error):
                if let customError = error as? CustomError {
                    SVProgressHUD.showError(withStatus: customError.errorDescription)
                } else {
                    SVProgressHUD.showError(withStatus: error.localizedDescription)
                }
            case .success(let data):
                StoreManager.shared().saveUser(user: data)
                StoreManager.shared().setIsAuth(bool: true)
                StoreManager.shared().userAccessTouchID(iin: iin, password: password)
                DispatchQueue.main.async {
                    guard let tabBarVC = self.tabBarController as? TabBarViewController else {
                        return
                    }
                    tabBarVC.viewControllers?[2] = self.profileController
                }
                SVProgressHUD.dismiss()
            }

        }

    }
    
    private func registrateUser() {
        
        guard let iin = IIN.text, let phone = phoneNumber.text  else {
            return
        }
        
        if iin.count != 12 {
            showAlertController("Не правильно ввели иин".localized())
            return
        }
        if phone.count != 17 {
            showAlertController("Не правильно ввели номер телефона")
            return
        }
        
        UserDefaults.standard.set(iin, forKey: "iin")
        UserDefaults.standard.set(phone, forKey: "phone")
        
        let registrationRequest = ApiRequests.registration(iin: iin, phone: phone)
        
        SVProgressHUD.show()
        NetworkManager.shared.makeRequest(apiRequest: registrationRequest) { (result: Result<RegistrationModel>) in
            
            switch result {
            case .success(let data):
                let vc = SMSCodeVerificationViewController()
                vc.isRegistration = true
                vc.iin = self.IIN.text
                vc.phone = self.phoneNumber.text
                vc.navTitle = "Регистрация".localized()
                self.navigationController?.pushViewController(vc, animated: true)
                SVProgressHUD.dismiss()
            case .failure(let error):
                if let customError = error as? CustomError {
                    
                    /// Remove
                    if customError.errorDescription == "Смс не отправлена".localized() {
                        SVProgressHUD.dismiss()
                        let vc = SMSCodeVerificationViewController()
                        vc.isRegistration = true
                        vc.iin = self.IIN.text
                        vc.phone = self.phoneNumber.text
                        vc.navTitle = "Регистрация".localized()
                        self.navigationController?.pushViewController(vc, animated: true)
                    } else {
                        SVProgressHUD.showError(withStatus: customError.errorDescription)
                    }
                    
                } else {
                    SVProgressHUD.showError(withStatus: error.localizedDescription)
                }
            }
            
        }
        
    }
    
}



extension AuthorizationViewController : UITextFieldDelegate {
    private func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        guard let text = textField.text else { return true }
        let newLength = text.count + string.count - range.length
        switch textField {
        case IIN:
            return newLength <= 12
        default:
            return newLength <= 16
        }
    }
    
    private func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == phoneNumber {
            phoneNumber.setFormatting("+# (###) ### ## ##", replacementChar: "#")
            phoneNumber.text = ""
            phoneNumber.text.append("7")
        }
    }
}
