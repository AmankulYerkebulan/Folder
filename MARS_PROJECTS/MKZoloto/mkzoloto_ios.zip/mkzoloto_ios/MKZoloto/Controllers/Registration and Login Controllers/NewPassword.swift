
import UIKit
import SVProgressHUD
import Alamofire
import IQKeyboardManagerSwift

class NewPasswordVC: UIViewController, UITextFieldDelegate {
    
    var phone : String?
    var iin   : String?
    
    var isFromRegistration  = false
    
    private lazy var mainView : UIView = {
        let view = UIView()
        view.backgroundColor = Global.white()
        view.cornerRadius = 5
        view.addShadow(ofColor: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), radius: 3, offset: .zero, opacity: 0.1)
        return view
    }()
    
    private lazy var whiteView : UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 4
        return view
    }()
    
    private lazy var newPassword : UITextField = {
        let textField = UITextField()
        textField.addPadding(.left(16))
        textField.placeholder = "Новый пароль".localized()
        textField.setUptextFiled()
        return textField
    }()
    
    private lazy var againPassword    : UITextField = {
        let textField = UITextField()
        textField.addPadding(.left(16))
        textField.placeholder = "Повторите новый пароль".localized()
        textField.setUptextFiled()
        return textField
    }()
    
    private lazy var nextButton : UIButton = {
        let button = UIButton()
        button.yellowBtnProperty()
        button.setTitle("Далее".localized(), for: UIControl.State.normal)
        button.addTarget(self, action: #selector(buttonCheck(_:)), for: .touchUpInside)
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupButtons()
        setupConstraints()
        
        navigationItem.title = "Новый пароль".localized()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        IQKeyboardManager.shared.enableAutoToolbar = false
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        IQKeyboardManager.shared.enableAutoToolbar = true
    }
    
}

extension NewPasswordVC {
    private func setupButtons() {

        self.view.backgroundColor = Global.grey()
        self.view.addSubview(mainView)
        self.view.addSubview(nextButton)
        self.mainView.addSubviews([whiteView, newPassword, againPassword])
        if isFromRegistration == true {
            self.newPassword.placeholder = "Пароль".localized()
            self.againPassword.placeholder = "Повторите пароль".localized()
            self.navigationItem.title = "Укажите пароль".localized()
        }
    }
    
    private func setupConstraints() {

        mainView.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.top.equalTo(self.view.safeAreaLayoutGuide).offset(StaticSize.s16)
            } else {
                make.top.equalTo(self.view).offset(StaticSize.s16)
            }
            make.left.equalToSuperview().offset(StaticSize.s16)
            make.right.equalToSuperview().offset(-StaticSize.s16)
        }
        
        newPassword.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.top.equalTo(self.mainView.safeAreaLayoutGuide).offset(StaticSize.s16)
            } else {
                make.top.equalTo(self.mainView).offset(StaticSize.s16)
            }
            make.left.equalToSuperview().offset(StaticSize.s16)
            make.right.equalToSuperview().offset(-StaticSize.s16)
            make.height.equalTo(StaticSize.s44)
        }
        
        againPassword.snp.makeConstraints { (make) in
            make.top.equalTo(newPassword.snp.bottom).offset(StaticSize.s8)
            make.left.right.equalTo(newPassword)
            make.height.equalTo(StaticSize.s44)
            make.bottom.equalTo(mainView.snp.bottom).offset(-StaticSize.s16)
        }
        
        nextButton.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(self.view.safeAreaLayoutGuide).offset(-StaticSize.s16)
            } else {
                make.bottom.equalTo(self.view).offset(-StaticSize.s16)
            }
            make.left.equalTo(self.view).offset(StaticSize.s16)
            make.right.equalTo(self.view).offset(-StaticSize.s16)
            make.height.equalTo(StaticSize.s44)

        }
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(hideKey))
        view.addGestureRecognizer(tap)
        
    }
}

extension NewPasswordVC {
    
    @objc func hideKey() {
        view.endEditing(true)
    }
    
    @objc private func buttonCheck(_ button: UIButton) {
        
        if let phone = phone,
            let newPassword = self.newPassword.text,
            let repeatPassword = self.againPassword.text {
            
            if newPassword == repeatPassword {
                SVProgressHUD.show()
                let repuest = ApiRequests.setPassword(password: newPassword, phone: phone)
                
                NetworkManager.shared.makeRequest(apiRequest: repuest) { (result: Result<EmptyModel>) in
                    switch result {
                        
                    case .success(_):
                        SVProgressHUD.showSuccess(withStatus: "Пароль сохранен".localized())
                        SVProgressHUD.dismiss()
                        StoreManager.shared().userAccessTouchID(iin: self.iin!, password: newPassword)
                        self.navigationController?.popToRootViewController(animated: true)
                    case .failure(let error):
                        if let customError = error as? CustomError {
                            SVProgressHUD.showError(withStatus: customError.errorDescription)
                        } else {
                            SVProgressHUD.showError(withStatus: error.localizedDescription)
                        }
                    }
                }
            }

        }
        
    }
}

