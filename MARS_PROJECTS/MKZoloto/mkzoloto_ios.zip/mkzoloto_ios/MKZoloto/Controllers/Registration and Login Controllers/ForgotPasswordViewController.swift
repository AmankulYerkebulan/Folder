
import UIKit
import SnapKit
import Alamofire
import SVProgressHUD
import IQKeyboardManagerSwift

class ForgotPasswordViewController: UIViewController, UITextFieldDelegate {

    private lazy var mainView : UIView = {
        let view = UIView()
        view.backgroundColor = Global.white()
        view.cornerRadius = 5
        view.addShadow(ofColor: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), radius: 3, offset: .zero, opacity: 0.1)
        return view
    }()
    
    private lazy var IIN : VSTextField = {
        let textField = VSTextField()
        textField.addPadding(.left(16))
        textField.placeholder = "Ваш ИИН".localized()
        textField.setUptextFiled()
        textField.keyboardType = .numberPad
        textField.setFormatting("############", replacementChar: "#")
        return textField
    }()
    
    private lazy var ticket : VSTextField = {
        let textField = VSTextField()
        textField.addPadding(.left(16))
        textField.placeholder = "+7(___) ___ __ __"
        textField.setUptextFiled()
        textField.keyboardType = .numberPad
        textField.setFormatting("+#-(###)-###-##-##", replacementChar: "#")
        return textField
    }()
    
    private lazy var note : UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.font = Global.sfRegular(size: StaticSize.s12)
        label.textColor = Global.textFiledPlaceholderColor()
        label.adjustsFontSizeToFitWidth = true
        label.text = "На данный номер будет отправлен код для подтверждения".localized()
        return label
    }()
    
    private lazy var codeButton : UIButton = {
        let button = UIButton()
        button.yellowBtnProperty()
        button.setTitle("Получить код".localized(), for: UIControl.State.normal)
        button.addTarget(self, action: #selector(buttonCheck(_:)), for: .touchUpInside)
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupButtons()
        setupConstraints()
        self.hideKeyboard()
        
        navigationItem.title = "Забыли пароль?".localized()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.tabBarController?.tabBar.isHidden = true
        IQKeyboardManager.shared.enableAutoToolbar = false
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        IQKeyboardManager.shared.enableAutoToolbar = true
    }
    
    private func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        guard let text = textField.text else { return true }
        let newLength = text.count + string.count - range.length
        return newLength <= 16 // Bool
    }
    
    private func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == ticket {
            ticket.setFormatting("+#(###) ### ## ##", replacementChar: "#")
            ticket.text = ""
            ticket.text.append("7")
        }
    }
    
}

extension ForgotPasswordViewController {

    private func setupButtons() {

        self.view.backgroundColor = Global.grey()
        self.view.addSubview(mainView)
        self.view.addSubview(codeButton)
        self.mainView.addSubviews([IIN, ticket, note])
        
    }
    
    private func setupConstraints() {
        
        mainView.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.top.left.equalTo(self.view.safeAreaLayoutGuide).offset(StaticSize.s16)
            } else {
                make.top.left.equalTo(self.view).offset(StaticSize.s16)
            }
            if #available(iOS 11.0, *) {
                make.right.equalTo(self.view.safeAreaLayoutGuide).offset(-StaticSize.s16)
            } else {
                 make.right.equalTo(self.view).offset(-StaticSize.s16)
            }
        }
        
        IIN.snp.makeConstraints{ (make) in
            if #available(iOS 11.0, *) {
                make.top.left.equalTo(self.mainView.safeAreaLayoutGuide).offset(StaticSize.s16)
            } else {
                make.top.left.equalTo(self.mainView).offset(StaticSize.s16)
            }
            if #available(iOS 11.0, *) {
                make.right.equalTo(self.mainView.safeAreaLayoutGuide).offset(-StaticSize.s16)
            } else {
                make.right.equalTo(self.mainView).offset(-StaticSize.s16)
            }
            make.height.equalTo(StaticSize.s44)
        }
        
        ticket.snp.makeConstraints{ (make) in
            make.top.equalTo(IIN.snp.bottom).offset(StaticSize.s8)
            make.left.equalTo(IIN.snp.left)
            make.right.equalTo(IIN.snp.right)
            make.height.equalTo(StaticSize.s44)
        }
        
        note.snp.makeConstraints { (make) in
            make.top.equalTo(ticket.snp.bottom).offset(StaticSize.s8)
            make.left.equalTo(IIN.snp.left)
            make.right.equalTo(IIN.snp.right)
            make.bottom.equalTo(mainView.snp.bottom).offset(-StaticSize.s16)
        }
        
        codeButton.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(self.view.safeAreaLayoutGuide).offset(-StaticSize.s16)
            } else {
                make.bottom.equalTo(self.view).offset(-StaticSize.s16)
            }
            make.left.equalTo(self.view).offset(StaticSize.s16)
            make.right.equalTo(self.view).offset(-StaticSize.s16)
            make.height.equalTo(StaticSize.s44)
        }
    }
}

extension ForgotPasswordViewController {
    
    @objc private func buttonCheck(_ button: UIButton) {
        
        if let iin = self.IIN.text,
            var phone = self.ticket.text {
            
            if let index = phone.index(phone.startIndex, offsetBy: 2, limitedBy: phone.endIndex) {
                phone.remove(at: index)
            }
            
            let request = ApiRequests.resetPassword(iin: iin, password: phone)
            
            SVProgressHUD.show()
            NetworkManager.shared.makeRequest(apiRequest: request) { (result: Result<EmptyModel>) in
                
                switch result {
                
                case .success(_):
                    print("success")
                    let vc = SMSCodeVerificationViewController()
                    vc.iin = iin
                    vc.phone = phone
                    self.navigationController?.pushViewController(vc, animated: true)
                    SVProgressHUD.dismiss()
                case .failure(let error):
                    if let customError = error as? CustomError {
                        
                        if "Смс не отправлена".localized() == customError.errorDescription {
                            SVProgressHUD.dismiss()
                            let vc = SMSCodeVerificationViewController()
                            vc.phone = phone
                            vc.iin   = iin
                            self.navigationController?.pushViewController(vc, animated: true)
                        } else {
                            SVProgressHUD.showError(withStatus: customError.errorDescription)
                        }
                    } else {
                        SVProgressHUD.showError(withStatus: error.localizedDescription)
                    }
                }
                
            }
            
        }
    }
}
extension String {
    
    func deletingPrefix(_ prefix: String) -> String {
        guard self.hasPrefix(prefix) else { return self }
        return String(self.dropFirst(prefix.count))
    }
}
