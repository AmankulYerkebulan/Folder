import UIKit
import SnapKit
import Alamofire
import SVProgressHUD
import IQKeyboardManagerSwift

class SMSCodeVerificationViewController: UIViewController, UITextFieldDelegate {
    
    var phone : String?
    var iin   : String?
    
    var isRegistration = false
    
    private lazy var mainView : UIView = {
        let view = UIView()
        view.backgroundColor = Global.white()
        view.cornerRadius = 5
        view.addShadow(ofColor: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), radius: 3, offset: .zero, opacity: 0.1)
        return view
    }()
    
    private lazy var whiteView : UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 4
        return view
    }()
    
    private lazy var ticket  : VSTextField = {
        let textField = VSTextField()
        textField.addPadding(.left(16))
        textField.placeholder = "СМС код".localized()
        textField.setUptextFiled()
        textField.keyboardType = .numberPad
        textField.setFormatting("######", replacementChar: "#")
        if #available(iOS 12.0, *) {
            textField.textContentType = .oneTimeCode
        } else {
        }

        return textField
    }()
    
    private lazy var note : UILabel = {
        let label = UILabel()
        label.font = Global.sfRegular(size: StaticSize.s12)
        label.textColor = Global.textFiledPlaceholderColor()
        let main_string = "Отправить код снова можно будет через".localized() + " \(seconds) " + "секунд".localized()
        let string_to_color = "\(seconds)"
        let range = (main_string as NSString).range(of: string_to_color)
        let attributedString = NSMutableAttributedString(string:main_string)
        attributedString.addAttribute(NSAttributedString.Key.foregroundColor, value: Global.dark() , range: range)
        label.attributedText = attributedString
        label.tag = 1
        label.adjustsFontSizeToFitWidth = true
        label.isUserInteractionEnabled = true
        return label
    }()
    
    private lazy var nextButton : UIButton = {
        let button = UIButton()
        button.yellowBtnProperty()
        button.setTitle("Далее".localized(), for: UIControl.State.normal)
        button.addTarget(self, action: #selector(buttonCheck(_:)), for: .touchUpInside)
        return button
    }()
    
    var navTitle = "Забыли пароль?".localized()
    
    var seconds = 60
    var timer = Timer()
    var isTimerRunning = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupButtons()
        setupConstraints()
        self.hideKeyboard()
        
        navigationItem.title = navTitle
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.tabBarController?.tabBar.isHidden = true
        IQKeyboardManager.shared.enableAutoToolbar = false
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        IQKeyboardManager.shared.enableAutoToolbar = true
    }
    
}

extension SMSCodeVerificationViewController {

    private func setupButtons() {

        self.view.addSubview(mainView)
        self.view.addSubview(nextButton)
        self.mainView.addSubviews([whiteView, ticket, note])
        self.view.backgroundColor = Global.grey()
        
        sendCodeAgain()
        runTimer()
    }
    
    private func runTimer() {
        timer = Timer.scheduledTimer(timeInterval: 1, target: self,   selector: #selector(updateTimer), userInfo: nil, repeats: true)
    }
    
    @objc private  func updateTimer() {
        
        if (seconds < 1) {
            timer.invalidate()
            note.attributedText = NSAttributedString(string: "Отправить код снова".localized(), attributes:
                [.underlineStyle: NSUnderlineStyle.single.rawValue])
            note.textColor = Global.dark()
            note.tag = 2
        } else {
            seconds -= 1
            note.textColor = Global.textFiledPlaceholderColor()
            let main_string = "Отправить код снова можно будет через".localized() + " \(seconds) " + "секунд".localized()
            let string_to_color = "\(seconds)"
            let range = (main_string as NSString).range(of: string_to_color)
            let attributedString = NSMutableAttributedString(string:main_string)
            attributedString.addAttribute(NSAttributedString.Key.foregroundColor, value: Global.dark() , range: range)
            note.attributedText = attributedString
            note.tag = 1
        }
    }
    
    
    private func setupConstraints() {
        
        mainView.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.top.equalTo(self.view.safeAreaLayoutGuide).offset(StaticSize.s16)
            } else {
                make.top.equalTo(self.view).offset(StaticSize.s16)
            }
            make.left.equalToSuperview().offset(StaticSize.s16)
            make.right.equalToSuperview().offset(-StaticSize.s16)
        }

        ticket.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.top.equalTo(self.mainView.safeAreaLayoutGuide).offset(StaticSize.s16)
            } else {
                make.top.equalTo(self.mainView).offset(StaticSize.s16)
            }
            make.left.equalToSuperview().offset(StaticSize.s16)
            make.right.equalToSuperview().offset(-StaticSize.s16)
            make.height.equalTo(StaticSize.s44)
        }
        
        note.snp.makeConstraints { (make) in
            make.top.equalTo(ticket.snp.bottom).offset(StaticSize.s8)
            make.left.right.equalTo(ticket)
            make.bottom.equalTo(self.mainView.snp.bottom).offset(-StaticSize.s16)
        }
        
        nextButton.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(self.view.safeAreaLayoutGuide).offset(-StaticSize.s16)
            } else {
                 make.bottom.equalTo(self.view).offset(-StaticSize.s16)
            }
            make.left.equalTo(self.view).offset(StaticSize.s16)
            make.right.equalTo(self.view).offset(-StaticSize.s16)
            make.height.equalTo(StaticSize.s44)
        }
    }
}

extension SMSCodeVerificationViewController {

    @objc private  func buttonCheck(_ button: UIButton) {
        
        if let code = self.ticket.text,
            let iin = self.iin {
            let request = ApiRequests.smsVerify(code: code, iin: iin)
           
            SVProgressHUD.show()
            NetworkManager.shared.makeRequest(apiRequest: request) { (result: Result<EmptyModel>) in
                switch result {
                
                case .success(_):
                    print("success")
                    SVProgressHUD.dismiss()
                    let vc = NewPasswordVC()
                    vc.phone = self.phone
                    vc.iin = self.iin
                    vc.isFromRegistration = self.isRegistration
                    self.navigationController?.pushViewController(vc, animated: true)
                case .failure(let error):
                    if let customError = error as? CustomError {
                        SVProgressHUD.showError(withStatus: customError.errorDescription)
                    } else {
                        SVProgressHUD.showError(withStatus: error.localizedDescription)
                    }
                }
            }
        } else {
            let code = self.ticket.text ?? ""
            
            SVProgressHUD.show()
            
            if isRegistration == true {
                if let iin = iin {
                    let request = ApiRequests.smsVerify(code: code, iin: iin)
                    
                    SVProgressHUD.show()
                    NetworkManager.shared.makeRequest(apiRequest: request) { (result: Result<EmptyModel>) in
                        switch result {
                            
                        case .success(_):
                            print("success")
                            SVProgressHUD.dismiss()
                            let vc = NewPasswordVC()
                            vc.phone = self.phone
                            vc.iin = self.iin
                            self.navigationController?.pushViewController(vc, animated: true)
                        case .failure(let error):
                            if let customError = error as? CustomError {
                                SVProgressHUD.showError(withStatus: customError.errorDescription)
                            } else {
                                SVProgressHUD.showError(withStatus: error.localizedDescription)
                            }
                        }
                    }
                }
            } else {
                NetworkManager.shared.makeRequest(apiRequest: .smsVerifyWhenPhoneChanged(code: code)) { (result: Result<String>) in
                    switch result {
                        
                    case .success(let data):
                        print("success")
                        SVProgressHUD.showSuccess(withStatus: data)
                        SVProgressHUD.dismiss(withDelay: 1, completion: {
                            self.navigationController?.popToRootViewController(animated: true)
                        })
                        
                    case .failure(let error):
                        if let customError = error as? CustomError {
                            SVProgressHUD.showError(withStatus: customError.errorDescription)
                        } else {
                            SVProgressHUD.showError(withStatus: error.localizedDescription)
                        }
                    }
                }
            }
            
        }
        
    }
    
    private func sendCodeAgain() {
        let gesture = UITapGestureRecognizer(target: self, action: #selector(sendCodeAgainOBJC))
        self.note.addGestureRecognizer(gesture)
    }
    
    @objc private  func sendCodeAgainOBJC() {
        if (note.tag == 2) {
            print(note.tag)
            timer.invalidate()
            seconds = 61
            runTimer()
            self.sendSMS()
            
        }
        if (note.tag == 1) {
            print(note.tag)
        }
    }
    
    private func sendSMS() {
       
        if let iin = iin,
            let phone = phone {
         
            let request = ApiRequests.resetPassword(iin: iin, password: phone)
            
            SVProgressHUD.show()
            NetworkManager.shared.makeRequest(apiRequest: request) { (result: Result<EmptyModel>) in
                
                switch result {
                    
                case .success(_):
                    print("success")
                    SVProgressHUD.dismiss()
                case .failure(let error):
                    if let customError = error as? CustomError {
                        
                        if "Смс не отправлена".localized() == customError.errorDescription {
                            SVProgressHUD.dismiss()
                        } else {
                            SVProgressHUD.showError(withStatus: customError.errorDescription)
                            SVProgressHUD.dismiss(withDelay: 1.5)
                        }
                    } else {
                        SVProgressHUD.showError(withStatus: error.localizedDescription)
                    }
                }
                
            }
            
        } else {
            
            if let _phone = self.phone {
                
                SVProgressHUD.show()
                
                let request = ApiRequests.changePhoneNumber(phone: _phone)
                
                NetworkManager.shared.makeRequest(apiRequest: request) { (result: Result<String>) in
                    
                    switch result {
                    case .failure(let error):
                        SVProgressHUD.showError(withStatus: error.localizedDescription)
                        /// Remove
                        if let customError = error as? CustomError {
                            SVProgressHUD.showError(withStatus: customError.errorDescription)
                            SVProgressHUD.dismiss(withDelay: 1.5)
                        } else {
                            SVProgressHUD.showError(withStatus: error.localizedDescription)
                            SVProgressHUD.dismiss(withDelay: 1.5)
                        }
                    case .success(let data):
                        SVProgressHUD.showSuccess(withStatus: data)
                    }
                    
                }
                
            }
            
        }
    }
    
}

