

import Foundation
import UIKit

extension BranchesViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withClass: UITableViewCell.self, for: indexPath)
        
        cell.selectionStyle = .none
        
        
        
        cell.textLabel?.textColor = .black
        cell.imageView?.image = #imageLiteral(resourceName: "Like")
    
        cell.accessoryType = .disclosureIndicator
        
        return cell
        
    }
    
}

extension BranchesViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vc = CityChooseViewController()
        
        vc.branchViewModel = self.branchViewModel
        
        self.navigationController?.pushViewController(vc)
        
    }
}
