
import UIKit
import MapKit
import SnapKit
import RxSwift

class BranchesViewController: UIViewController {
    
//    MARK: Properties
    
    var isFromFB = false
    
    var disposeBag = DisposeBag()
    
    lazy var branchViewModel: BranchViewModel = {
        let model = BranchViewModel(mapView: self.mapView)
        return model
    }()
    
    var branchModel : BranchModel?
    
    lazy var pickerView: UIPickerView = {
        let picker = UIPickerView()
        picker.dataSource = self
        picker.delegate = self
        return picker
    }()
    
    lazy var textField: UITextField = {
        let textField = UITextField()
        textField.inputView = pickerView
        textField.addPaddingLeftIcon(#imageLiteral(resourceName: "citypin"), padding: 16)
        textField.rightView = UIImageView(image: #imageLiteral(resourceName: "right_arrow"))
        textField.rightViewRect(forBounds: CGRect(x: 0, y: 0, width: 20, height: 25))
        textField.rightViewMode = .always
        textField.text = "Алматы"
        textField.placeholder = "Город"
        textField.cornerRadius = 5
        textField.backgroundColor = .white
        textField.addTarget(self, action: #selector(selectCity), for: .editingDidEnd)
        textField.adjustsFontSizeToFitWidth = true
        textField.tintColor = .clear
        textField.setUpCellShadow()
        return textField
    }()
    
    lazy var mapView: MapView = {
        let mapView = MapView()
        mapView.delegate = self
        return mapView
    }()
    
    lazy var bottomInfoView: BranchQuickInfoView = {
        let view = BranchQuickInfoView()
        view.hideButton.addTarget(self, action: #selector(hideBranchInfoView), for: .touchUpInside)
        return view
    }()
    
//    MARK: Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
    
        NotificationCenter.default.addObserver(self, selector: #selector(selected), name: NSNotification.Name("SELECTED"), object: nil)
        setupViews()
        setupConstraints()
        
        /// Animate to bottom to hide view
        bottomInfoView.transform = CGAffineTransform(translationX: 0, y: 500)
        
        navigationItem.title = "Карта".localized()
        
        setupRx()
        
        self.branchViewModel.fetchCities {
            self.pickerView.reloadAllComponents()
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationController?.navigationBar.isHidden = !isFromFB        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        
    }
    
    private func setupViews() {
        
        self.view.addSubviews([mapView, textField, bottomInfoView])
        
    }
    
//    MARK: Constraints
    private func setupConstraints() {
     
        textField.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.top.equalTo(self.view.safeAreaLayoutGuide).offset(StaticSize.s10)
            } else {
                make.top.equalTo(self.view).offset(StaticSize.s10)
            }
            make.right.equalToSuperview().offset(-StaticSize.s8)
            make.height.equalTo(44)
        }
        
        mapView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        bottomInfoView.snp.makeConstraints { (make) in
            make.height.equalTo(StaticSize.s184)
            make.left.equalToSuperview().offset(StaticSize.s8)
            make.right.equalToSuperview().offset(-StaticSize.s8)
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(self.view.safeAreaLayoutGuide.snp.bottom).offset(-StaticSize.s8)
            } else {
                make.bottom.equalTo(self.view.snp.bottom).offset(-StaticSize.s8)
            }
        }
        
    }
    
//    MARK: Functions
    
    private func setupRx() {
        
        self.branchViewModel.getCityByCoordinates {
            
            self.branchViewModel.currentCity?.bind { (cityModel)  in
                
                self.branchViewModel.fetchBranches(city: cityModel.name)
                
                _ = self.branchViewModel.currentCity?.bind { (cityModel) in
                    self.textField.text = cityModel.name
                }
                
            }.disposed(by: self.disposeBag)
            
            if self.branchViewModel.currentCity == nil {
                
                if let city = StoreManager.shared().getCurrentCity() {
                    
                    self.branchViewModel.currentCity = BehaviorSubject(value: city)
                    
                    self.branchViewModel.currentCity?.bind { (cityModel)  in
                        
                        self.branchViewModel.fetchBranches(city: cityModel.name)
                        
                        _ = self.branchViewModel.currentCity?.bind { (cityModel) in
                            self.textField.text = cityModel.name
                        }
                        
                    }.disposed(by: self.disposeBag)
                    
                } else {
                    
                    let city = CityModel(name: "Алматы", cityEnglish: "almaty")
                    
                    self.branchViewModel.currentCity = BehaviorSubject(value: city)
                    
                    self.branchViewModel.currentCity?.bind { (cityModel)  in
                        
                        self.branchViewModel.fetchBranches(city: cityModel.name)
                        
                        _ = self.branchViewModel.currentCity?.bind { (cityModel) in
                            self.textField.text = cityModel.name
                        }
                    
                    }.disposed(by: self.disposeBag)
                }
                
            }
            
        }
        
    }
    
    @objc private func selectCity() {
        
        let index = pickerView.selectedRow(inComponent: 0)
        
        if (self.branchViewModel.cities.count > 0) {
            let model = self.branchViewModel.cities[index]
            
            self.branchViewModel.currentCity?.onNext(model)
            self.textField.text = model.name
        }
    }
    
    @objc private func hideBranchInfoView() {
        
        UIView.animate(withDuration: 0.3) {
            self.bottomInfoView.transform = CGAffineTransform(translationX: 0, y: 500)
            self.mapView.userLocationButton.transform = CGAffineTransform.identity
//            view.transform = .identity
            
        }
        
    }
    
}

//MARK: Map View delegate functions
extension BranchesViewController: MKMapViewDelegate {
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        
        guard let annotation = view.annotation as? MKPointAnnotation else {
            return
        }
        
        if annotation.title == "myLoc" {
            return
        }
        
        let index = self.branchViewModel.annotations.index(of: annotation)
        
        bottomInfoView.branchModel = self.branchViewModel.branches[index ?? 0]
        
        /// Animating view to top with filling information
        UIView.animate(withDuration: 0.3) {
            self.bottomInfoView.transform = CGAffineTransform.identity
            self.mapView.userLocationButton.transform = CGAffineTransform(translationX: 0, y: -self.bottomInfoView.height)
//            view.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
        }
        
    }
    
    func selectedAnnotation(model: BranchModel) {
        bottomInfoView.branchModel = model
        UIView.animate(withDuration: 0.3) {
            self.bottomInfoView.transform = CGAffineTransform.identity
            self.mapView.userLocationButton.transform = CGAffineTransform(translationX: 0, y: -self.bottomInfoView.height)
        }
    }
    
    @objc private func selected() {
        guard let model = self.branchModel else {return}
        self.selectedAnnotation(model: model)
        branchModel = nil
    }
    
    func mapView(_ mapView: MKMapView, didDeselect view: MKAnnotationView) {
        
        /// Animating view to bottom to hide view
        
        UIView.animate(withDuration: 0.3) {
            self.bottomInfoView.transform = CGAffineTransform(translationX: 0, y: 500)
            self.mapView.userLocationButton.transform = CGAffineTransform.identity
//            view.transform = .identity
        }
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        let annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "pin")
        
        guard let annotation = annotation as? MKPointAnnotation else {
            return nil
        }
        
        if annotation.title == "myLoc" {
            return nil
        }
        
        let index = self.branchViewModel.annotations.index(of: annotation)
        
        if self.branchViewModel.branches.indices.contains(index ?? 1000) {
            
            if (self.branchViewModel.branches[index ?? 0].VIP) {
                annotationView.image = #imageLiteral(resourceName: "vipPin")
            } else {
                annotationView.image = #imageLiteral(resourceName: "pin")
            }
            
        }
        
        if annotation.title == "myLoc" {
            annotationView.image = #imageLiteral(resourceName: "Group 4")
        }
        
        return annotationView
        
    }
    
}

extension BranchesViewController: UIPickerViewDataSource, UIPickerViewDelegate {
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.branchViewModel.cities.count
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return self.branchViewModel.cities[row].name
    }
    
}
