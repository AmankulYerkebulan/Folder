//
//  BranchQuickInfoView.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 3/25/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import UIKit
import MapKit
import Kingfisher
import SimpleImageViewer

/**
 InfoActionTypes
 */
enum InfoActionTypes: Int {
    /// - call: Call to branch of Lombard
    case call = 1
    /// - whatsapp: Starting chat with branch of Lombard
    case whatsapp
    /// - share: Openning location in other maps
    case share
}

class BranchQuickInfoView: UIView {
    
//    MARK: Properties

    lazy var imageViewerController: ImageViewerController = {
        let config = ImageViewerConfiguration(configurationClosure: { (configure) in
            configure.imageView = imageView
        })
        
        let controller = ImageViewerController(configuration: config)
        return controller
    }()
    
    var branchModel: BranchModel? {
        didSet {
            
            var labels = [UILabel]()
            for i in 1...4 {
                let label = UILabel()
                label.sizeToFit()
                
                label.tag = i
                
                /// Remove this lines
                if i == 1 {
                    label.text = branchModel!.alias
                    label.font = Global.sfBold(size: 17)
                } else if i == 2 {
                    label.text = "\(branchModel?.address ?? "")"
                    label.font = Global.sfRegular(size: 15)
                } else if i == 3 {
                    label.text = "\(String(describing: branchModel!.operationMode))"
                    label.font = Global.sfRegular(size: 15)
                } else {
                    label.text = "\(String(describing: branchModel!.weekends))"
                    label.font = Global.sfRegular(size: 15)
                }
                
                label.numberOfLines = 0
                
                label.adjustsFontSizeToFitWidth = true
                
                labels.append(label)
            }
            
            infoStackView.removeSubviews()
            infoStackView.addArrangedSubviews(labels)
            
//            for label in infoStackView.arrangedSubviews {
//                if let _label = label as? UILabel {
//                    if _label.tag == 1 {
//                        _label.text = branchModel!.address
//                    } else if _label.tag == 2 {
//                        _label.text = "\(String(describing: branchModel!.operationMode))"
//                    } else {
//                        _label.text = "\(String(describing: branchModel!.weekends))"
//                    }
//                    _label.sizeToFit()
//                }
//            }
            
            self.setImage()
            
        }
    }
    
    lazy var imageView: UIImageView = {
        let imageView = UIImageView()
        
        imageView.cornerRadius = 4
        imageView.contentMode = .scaleAspectFill
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(openFully))
        imageView.isUserInteractionEnabled = true
        imageView.addGestureRecognizer(tapGesture)
        
        return imageView
    }()
    
    lazy var infoStackView: UIStackView = {
        var labels = [UILabel]()
        for i in 1...3 {
            let label = UILabel()
            label.sizeToFit()
            
            label.tag = i

            /// Remove this lines
            if i == 1 {
                label.text = "011 (Выставка)"
                label.font = Global.sfBold(size: 17)
            } else if i == 2 {
                label.text = "8:30-19:30"
                label.font = Global.sfRegular(size: 15)
            } else {
                label.text = "Без выходных"
                label.font = Global.sfRegular(size: 15)
            }
            
            label.numberOfLines = 0
            
            label.adjustsFontSizeToFitWidth = true
            
            labels.append(label)
        }
        
        let stackView = UIStackView(arrangedSubviews: labels)
        
        stackView.axis = .vertical
        stackView.backgroundColor = .red
        
        stackView.distribution = .fillProportionally
        
        
        return stackView
    }()
    
    lazy var line: UIView = {
        let view = UIView()
        view.backgroundColor = Global.grey()
        return view
    }()
    
    lazy var hideButton: UIButton = {
        let button = UIButton()
        button.setImage(#imageLiteral(resourceName: "cross"), for: .normal)
        return button
    }()
    
    lazy var infoButtons: [UIButton] = {
        var buttons = [UIButton]()
        
        for i in 1...InfoActionTypes.share.rawValue {
            let button = UIButton()
            button.tag = i
            button.addTarget(self, action: #selector(infoButtonTapped(sender:)), for: .touchUpInside)
            
            button.backgroundColor = Global.grey()
            button.cornerRadius = 5
            
            guard let buttonTypes = InfoActionTypes(rawValue: i) else { return [UIButton]() }
            
            switch buttonTypes {
            case .share:
                button.setImage(#imageLiteral(resourceName: "open"), for: .normal)
                button.setTitle("Открыть в".localized(), for: .normal)
            case .whatsapp:
                button.setImage(#imageLiteral(resourceName: "whatsapp-1"), for: .normal)
                button.setTitle("Написать".localized(), for: .normal)
            case .call:
                button.setImage(#imageLiteral(resourceName: "tel"), for: .normal)
                button.setTitle("Позвонить".localized(), for: .normal)
            }
            
            button.setTitleColor(.black, for: .normal)
            button.titleLabel?.font = Global.sfRegular(size: 12)
            button.alignTextBelow(spacing: 0)
            
            buttons.append(button)
        }
        
        return buttons
    }()
    
    lazy var buttonsStackView: UIStackView = {
        
        let stackView = UIStackView(arrangedSubviews: infoButtons)
        
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        stackView.spacing = 8
        stackView.backgroundColor = .green
        return stackView
    }()
    
//    MARK: Init
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupViews()
        setupConstraints()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        
        self.addSubviews([imageView, infoStackView, line, hideButton, buttonsStackView])
        
        self.backgroundColor = .white
        self.cornerRadius = 5
        
    }
    
//    MARK: Constraints
    
    private func setupConstraints() {
        
        imageView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(StaticSize.s16)
            make.top.equalToSuperview().offset(StaticSize.s16)
            make.height.equalTo(68)
            make.width.equalTo(imageView.snp.height)
        }
        
        buttonsStackView.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-StaticSize.s16)
            make.left.equalToSuperview().offset(StaticSize.s16)
            make.top.equalTo(self.imageView.snp.bottom).offset(StaticSize.s16 * 2)
            make.bottom.equalToSuperview().offset(-StaticSize.s16)
        }
        
        infoStackView.snp.makeConstraints { (make) in
            make.left.equalTo(imageView.snp.right).offset(StaticSize.s16)
            make.right.equalTo(hideButton.snp.left).offset(-4)
            make.top.equalTo(imageView).offset(-StaticSize.s8)
            make.bottom.equalTo(imageView).offset(StaticSize.s8)
        }
        
        line.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(8)
            make.right.equalToSuperview().offset(-8)
            make.height.equalTo(1)
            make.top.equalTo(self.imageView.snp.bottom).offset(StaticSize.s16)
        }
        
        hideButton.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-StaticSize.s16)
            make.top.equalToSuperview().offset(StaticSize.s16)
            make.width.height.equalTo(StaticSize.s24)
        }
        
    }
    
//    MARK: Functions
    

    private func setImage() {
        
        guard let url = URL(string: branchModel?.image ?? "") else {
            self.imageView.image = #imageLiteral(resourceName: "Rectangle Copy")
            return
        }
        
        imageView.kf.indicatorType = .activity
        self.imageView.kf.setImage(with: url)
        
    }
    
    /**
     Call to phone number
     - Parameter phoneNumber: phone number to call
     */
    func callToPhoneNumber(phoneNumber: String) {
        
        if let url = URL(string: "tel://\(phoneNumber)"), UIApplication.shared.canOpenURL(url) {
            if #available(iOS 10, *) {
                UIApplication.shared.open(url)
            } else {
                UIApplication.shared.openURL(url)
            }
        }
        
    }
    
    /**
     Opening coordinates with apple and google maps
     
     - Parameter coordinate: coordinate to opening map
     - Parameter title: title of coordinate
     */
    func openOutWithMaps(coordinate: CLLocationCoordinate2D, title: String) {
        
        let alertController = UIAlertController(title: "", message: "Открыть с помощью".localized(), preferredStyle: .actionSheet)
        
        alertController.addAction(title: "Apple Maps", style: .default, isEnabled: true) { (_) in
            LocationManager.sharedInstance.openLocationToAppleMaps(coordinate: coordinate, name: title)
        }
        
        alertController.addAction(title: "Google Maps", style: .default, isEnabled: true) { (_) in
            LocationManager.sharedInstance.openLocationToGoogleMaps(coordinate: coordinate, name: title)
        }
        
        alertController.addAction(title: "Отмена".localized(), style: .cancel, isEnabled: true) { (_) in
            alertController.dismiss(animated: true, completion: nil)
        }
        
        self.parentViewController?.present(alertController, animated: true, completion: nil)
        
    }
    
    /**
     Openning chat with branch of Lombard
     
     - Parameter phoneNumber: phone number of Branch
     */
    func sendMessageToWhatsapp(phoneNumber: String) {
        if let url = "whatsapp://send?phone=\(phoneNumber)".addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlQueryAllowed) {
            if let whatsappURL = URL(string: url) {
                if UIApplication.shared.canOpenURL(whatsappURL) {
                    if #available(iOS 10, *) {
                        UIApplication.shared.open(whatsappURL)
                    } else {
                        UIApplication.shared.openURL(whatsappURL)
                    }
                } else {
                    self.parentViewController?.showAlert(title: "Whoops", message: "This phone number dont have a whatsapp application")
                }
            }
        }
        
    }
    
//    MARK: Targets
    @objc private func openFully() {
        let config = ImageViewerConfiguration(configurationClosure: { (configure) in
            configure.imageView = imageView
        })
        
        let controller = ImageViewerController(configuration: config)
        self.parentViewController?.present(controller, animated: true, completion: nil)
        
    }
    
    @objc private func infoButtonTapped(sender: UIButton) {
        
        guard let actionType = InfoActionTypes(rawValue: sender.tag) else { return }
        
        switch actionType {
        case .call:
            callToPhoneNumber(phoneNumber: "+\(branchModel?.phone ?? "")")
        case .share:
            openOutWithMaps(coordinate: CLLocationCoordinate2D(latitude: CLLocationDegrees(Double(branchModel?.lat ?? "") ?? 2), longitude: CLLocationDegrees(Double(branchModel?.lng ?? "") ?? 2)), title: "Branch")
        case .whatsapp:
            sendMessageToWhatsapp(phoneNumber: branchModel?.phone ?? "")
        }
        
    }
    
}


extension UIButton {
    
    func alignTextBelow(spacing: CGFloat = 6.0)
    {
        if let image = self.imageView?.image
        {
            let imageSize: CGSize = image.size
            self.titleEdgeInsets = UIEdgeInsets(top: spacing, left: -imageSize.width, bottom: -(imageSize.height) - 1, right: 0.0)
            let labelString = NSString(string: self.titleLabel!.text!)
            let titleSize = labelString.size(withAttributes: [NSAttributedString.Key.font: self.titleLabel!.font])
            self.imageEdgeInsets = UIEdgeInsets(top: -(titleSize.height + spacing) + 1, left: 0.0, bottom: 0.0, right: -titleSize.width)
        }
    }
    
}
