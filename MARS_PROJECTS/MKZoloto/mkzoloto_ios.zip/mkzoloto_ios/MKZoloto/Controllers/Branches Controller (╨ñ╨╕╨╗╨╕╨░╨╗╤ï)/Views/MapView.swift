//
//  MapView.swift
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import UIKit
import MapKit

class MapView: MKMapView {
    
//    MARK: Properties
    
    lazy var zoomInButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = .white
        button.setTitle("+", for: .normal)
        button.tag = 0
        button.addTarget(self, action: #selector(zoomMapView(sender: )), for: .touchUpInside)
        button.setTitleColor(UIColor(hexString: "#297FCA"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 25)
        button.isHidden = true
        return button
    }()
    
    lazy var zoomOutButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = .white
        button.setTitle("-", for: .normal)
        button.tag = 1
        button.setTitleColor(UIColor(hexString: "#297FCA"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 25)
        button.addTarget(self, action: #selector(zoomMapView(sender: )), for: .touchUpInside)
        button.isHidden = true
        return button
    }()
    
    lazy var userLocationButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = .white
        button.addTarget(self, action: #selector(getCurrentLocation), for: .touchUpInside)
        button.setImage(#imageLiteral(resourceName: "userLoc"), for: .normal)
        button.borderWidth = 1
        button.borderColor = UIColor(hexString: "#F5F5F5")
        return button
    }()
    
//    MARK: Init
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupViews()
        setupConstraints()
        
        setCurrentLocation()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        
        self.addSubviews([zoomInButton, zoomOutButton, userLocationButton])
        
    }
    
    /// Fetching and setting user location
    private func setCurrentLocation() {
    
        let annotation = MKPointAnnotation()
        
        LocationManager.sharedInstance.getLocation { (location, error) in
            guard let _location = location else { return }
            
            annotation.coordinate = _location.coordinate
            
            annotation.title = "myLoc"
        
            self.addAnnotation(annotation)
            
            let region = MKCoordinateRegion(center: _location.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))
            
            self.setRegion(region, animated: true)
            
        }
        
    
    }
    
    /// Button actions
    @objc private func zoomMapView(sender: UIButton) {
        
        var region = self.region
        
        switch sender.tag {
        case 0:
            region.span.latitudeDelta /= 2.0
            region.span.longitudeDelta /= 2.0
        case 1:
            region.span.longitudeDelta = min(region.span.longitudeDelta * 2.0, 180)
            region.span.latitudeDelta = min(region.span.latitudeDelta * 2.0, 180)
        default:
            break
        }
        
        self.setRegion(region, animated: true)
        
    }
    
    @objc private func getCurrentLocation() {
        
        LocationManager.sharedInstance.getLocation { (location, error) in
            
            guard let _location = location else {
                self.requestLocationAgain()
                return
            }
            
            let region = MKCoordinateRegion(center: _location.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05))
            
            let annotation = MKPointAnnotation()
            annotation.coordinate = CLLocationCoordinate2D(latitude: CLLocationDegrees(Double(_location.coordinate.latitude) ), longitude: CLLocationDegrees(Double(_location.coordinate.longitude)))
            
            let index = self.annotations.lastIndex(where: { $0.title == "myLoc" })
            
            if let _index = index {
                self.removeAnnotation(self.annotations[_index])
            }
            
            annotation.title = "myLoc"
            
            self.addAnnotation(annotation)
            
            self.setRegion(region, animated: true)
            
        }
        
    }
    
    private func requestLocationAgain() {
        
        let alertController = UIAlertController(title: "", message: "Для получение филиалов в вашем городе, пожалуйста включите геолокацию".localized(), preferredStyle: .alert)
        
        let cancelAction = UIAlertAction(title: "Отмена".localized(), style: .cancel) { (_) in
            alertController.dismiss(animated: true, completion: nil)
            
        }
        
        let goToSetting = UIAlertAction(title: "Открыть настройки".localized(), style: .default) { (_) in
            if let url = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(url, options: [:], completionHandler: { _ in
                })
            }
        }
        
        alertController.addAction(cancelAction)
        alertController.addAction(goToSetting)
        
        self.parentViewController?.present(alertController, animated: true, completion: nil)
        
    }
    
//    MARK: Constraints
    private func setupConstraints() {
        
        zoomOutButton.snp.makeConstraints { (make) in
            make.width.height.equalTo(40)
            make.left.equalToSuperview().offset(16)
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(self.safeAreaLayoutGuide).offset(-12)
            } else {
                make.bottom.equalTo(self).offset(-12)
            }
        }
        
        zoomInButton.snp.makeConstraints { (make) in
            make.width.height.left.equalTo(zoomOutButton)
            make.bottom.equalTo(zoomOutButton.snp.top).offset(-8)
        }
        
        userLocationButton.snp.makeConstraints { (make) in
            make.width.height.bottom.equalTo(zoomOutButton)
            make.right.equalToSuperview().offset(-16)
        }
        
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        userLocationButton.cornerRadius = userLocationButton.height * 0.5
        
    }
    
}
