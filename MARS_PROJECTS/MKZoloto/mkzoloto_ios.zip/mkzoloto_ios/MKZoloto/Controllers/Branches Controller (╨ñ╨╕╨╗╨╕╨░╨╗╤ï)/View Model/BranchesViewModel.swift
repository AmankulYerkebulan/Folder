
import Foundation
import Alamofire
import MapKit
import RxSwift
import SVProgressHUD

class BranchViewModel {
    
    var dispatchGroup   = DispatchGroup()
    
    var branches        : [BranchModel] = [BranchModel]()
    
    var cities          : [CityModel] = [CityModel]()
    
    var currentCity     : BehaviorSubject<CityModel>?
    
    var cuttentLocation : CLLocation?
    
    var annotations     : [MKPointAnnotation] = [MKPointAnnotation]()
    
    var mapView         : MapView
    
    var requestCompleted    = { () -> () in }
    
    init(mapView: MapView) {
        
        self.mapView = mapView
        
    }
    
    func fetchCities(completion: @escaping () -> ()) {
        
        SVProgressHUD.show()
        NetworkManager.shared.makeRequest(apiRequest: .getCities) { (result: Result<[CityModel]>) in
            
            switch result {
            case .failure(let error):
                debugPrint(error)
            case .success(let data):
                self.cities = data
                SVProgressHUD.dismiss()
                completion()
            }
            
            
        }
        
    }
    
    func fetchBranches(city: String) {
        
        self.mapView.removeAnnotations(annotations)
        annotations.removeAll()
        
        let request = ApiRequests.getBranchesByCity(city: city)
        
        SVProgressHUD.show()
        NetworkManager.shared.makeRequest(apiRequest: request) { (result: Result<[BranchModel]>) in
            
            switch result {
            case .failure(let error):
                debugPrint(error)
                SVProgressHUD.dismiss()
            case .success(let data):
                self.branches = data
                SVProgressHUD.dismiss()
                self.setBranchesAnnotation()
            }
            
        }
        
    }
    
    func setBranchesAnnotation() {
        
        for branch in branches {
            
            let annotation = MKPointAnnotation()
            annotation.coordinate = CLLocationCoordinate2D(latitude: CLLocationDegrees(Double(branch.lat) ?? 2), longitude: CLLocationDegrees(Double(branch.lng) ?? 2))
            
            self.annotations.append(annotation)
            self.mapView.addAnnotation(annotation)
            
        }
        
        if let branch = self.branches.first {
            
            let coordinate = CLLocationCoordinate2D(latitude: Double(branch.lat) ?? 0, longitude: Double(branch.lng) ?? 0)
            let region = MKCoordinateRegion(center: coordinate, latitudinalMeters: 50000, longitudinalMeters: 50000)
            self.mapView.setRegion(region, animated: true)
        }
        
        NotificationCenter.default.post(name: NSNotification.Name("SELECTED"), object: nil)
        
    }
    
    func getCityByCoordinates(completion: @escaping () -> ()) {
        
        LocationManager.sharedInstance.getLocation { (location, error) in
            
            if let errorLocation = error {
                debugPrint(errorLocation)
                completion()
                return
            }
        
            let request = ApiRequests.getCityByCoordinate(latitude: location?.coordinate.latitude ?? 0, longitude: location?.coordinate.longitude ?? 0)
            
            SVProgressHUD.show()
            NetworkManager.shared.makeRequest(apiRequest: request, completion: { (result: Result<CityModel>) in
                
                switch result {
                case .failure(let error):
                    debugPrint(error)
                    SVProgressHUD.dismiss()
                case .success(let data):
                    self.currentCity = BehaviorSubject<CityModel>(value: data)
                    SVProgressHUD.dismiss()
                    completion()
                }
                
            })
        
        }
        
    }
    
}
