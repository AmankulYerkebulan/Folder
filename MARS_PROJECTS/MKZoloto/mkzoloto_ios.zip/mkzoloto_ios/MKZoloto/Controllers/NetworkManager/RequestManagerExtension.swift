//
//  NetworkManagerExtension.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 4/15/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import Alamofire

/// Immutable types
/// Change properties if needed
extension ApiRequests {
    
    var baseUrl: URL {
        return URL(string: "https://mk-prod.mars.studio/api") ?? URL(fileURLWithPath: "")
    }
    
    var completedUrl: URL {
        
        var url = baseUrl.appendingPathComponent(path)
        
        url = url.appendingQueryParameters(urlParameters ?? [:])
        
        return url
        
    }
    
    var imageDatas: [String : [Data]]? {
        switch self {
        default:
            return nil
        }
    }
    
    var headers: HTTPHeaders? {
        switch self {
        default:
            return nil
        }
    }
    
    var description: String {
        
        return """
        Completed URL:      \(self.completedUrl)
        HTTP Method:        \(self.httpMethod)
        Body Parameters:    \(String(describing: self.bodyParameters))
        Headers:            \(String(describing: self.headers))
        """
    }
    
}
