//
//  NetworkManager.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 4/8/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import Foundation
import Alamofire

/**
 Enum cases that contains all requests with necessary parameters and header
 For Example this request gets all commenst from specific post (postId)
 
 
 # USING EXAMPLE
 ````
 ADDING TO REQUEST CASES
 case getComments(postId: Int)
 
 SETTING INSIDE EXTENSION BEGIN
 var path: String {
     switch self {
     case .getComments(_):
        return "/comments"
     }
 }
 
 var httpMethod: HTTPMethod {
     switch self {
     case .getComments(_):
        return .get
     }
 }
 
 var urlParameters: [String : String]? {
     switch self {
     case .getComments(let postId):
        return ["postId" : "\(postId)"]
     default:
        return nil
     }
 }
 SETTING INSIDE EXTENSION BEGIN
 
 USING INSIDE CONTROLLERS
 let endPoint = ApiRequests.getComments(postId: 1)
 
 NetworkManager.shared.makeRequest(apiRequest: endPoint) { result: Result<[Test]> in
     switch result {
         case .success(let data):
            break
         case .failure(let error):
            print(error)
         }
     }
 }
 ````
 -important: **If you add a case, you should set all information about this request (path, method, parameters**)
 */
enum ApiRequests {
    
    /// case getComments(postId: Int)
    
    case getGoldSamples
    
    case getDefaultGoldSample
    
    case getCalculatorParameters
    
    case getBranches
    
    case getClosestBranches(latitude: Double, longitude: Double, limit: Int)
    
    case getBranchesByCity(city: String)
    
    case getRates
    
    case getCities
    
    case getCityByCoordinate(latitude: Double, longitude: Double)
    
}

/**
 Extension for the description of requests
 */
extension ApiRequests: Request {
    
    var path: String {
        switch self {
        case .getGoldSamples:
            return "/probes"
        case .getDefaultGoldSample:
            return "/default_probe"
        case .getCalculatorParameters:
            return "/calculator"
        case .getBranches:
            return "/points"
        case .getRates:
            return "/rates"
        case .getClosestBranches(_, _, _):
            return "/closestPoints"
        case .getCities:
            return "/cities"
        case .getCityByCoordinate(_):
            return "/getCityByCoordinates"
        case .getBranchesByCity(_):
            return "/getPointsByCity"
        }
    }
    
    var httpMethod: HTTPMethod {
        switch self {
        case .getGoldSamples,
             .getDefaultGoldSample,
             .getCalculatorParameters,
             .getBranches,
             .getRates,
             .getCities:
            return .get
        case .getClosestBranches(_, _, _), .getCityByCoordinate(_, _), .getBranchesByCity(_):
            return .post
        }
    }
    
    
    var bodyParameters: Parameters? {
        switch self {
        case .getClosestBranches(let latitude, let longitude, let limit):
            return [
                "lat" : latitude,
                "lng" : longitude,
                "limit" : limit
            ]
        case .getCityByCoordinate(let latitude, let longitude):
            return [
                "lat" : latitude,
                "lng" : longitude
            ]
        case .getBranchesByCity(let city):
            return [
                "city" : city
            ]
        default:
            return nil
        }
    }
    
    var urlParameters: [String : String]? {
        switch self {
        default:
            return nil
        }
    }
    
}
