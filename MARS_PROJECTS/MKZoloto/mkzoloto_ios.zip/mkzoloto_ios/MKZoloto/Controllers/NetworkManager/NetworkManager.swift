//
//  NetworkManager.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 4/15/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import UIKit
import Alamofire
import SVProgressHUD

/**
 Class which do a requests
 */

enum CustomError: Error {
    case errorWithDecoding
    case internalError(string: String)
}

class NetworkManager {
    
    static let shared = NetworkManager()
    
    private init() {}
    
    /// Request method with Alamofire
    public func makeRequest<T: Codable>(apiRequest: ApiRequests, completion: @escaping (Result<T>) -> Void) {
        
        /// Showing activity indicator to top controller
//        let controller = UIApplication.topViewController()
        SVProgressHUD.show()
//        hud.show(in: controller.view, animated: true)
        
        upload(multipartFormData: { (multipartFormData) in
            
            /// Appending body parameters to server
            for (key, value) in apiRequest.bodyParameters ?? [:] {
                multipartFormData.append("\(value)".data(using: .utf8) ?? Data(), withName: key)
            }
            
            /// Uploading images to server
            for (key, value) in apiRequest.imageDatas ?? [:] {
                
                for (index, image) in value.enumerated() {
                    
                    multipartFormData.append(image, withName: "\(key)[\(index)]", mimeType: "image/jpg")
                    
                }
                
            }
            
            
        }, usingThreshold: UInt64(), to: apiRequest.completedUrl, method: apiRequest.httpMethod, headers: apiRequest.headers) { (response) in
            
            switch response {
            case .failure(let error):
                completion(Result.failure(error))
            case .success(let result, _, _):
                
                result.responseData(completionHandler: { (responseResult) in
                    switch responseResult.result {
                    case .failure(let error):
                        completion(Result.failure(error))
                        
                        /// Hiding activity indicator
                        SVProgressHUD.dismiss()
                    case .success(let data):
                        
                        do {
                            /// Getting result and decoding to T generic model
//                            print(String.init(data: data, encoding: .utf8))
                            print(apiRequest.description)
                            let model = try JSONDecoder().decode(MainResult<T>.self, from: data)
                            
                            if let error = model.error {
                                completion(Result.failure(CustomError.internalError(string: error)))
                            } else {
                                if let decodedData = model.data {
                                    completion(Result.success(decodedData))
                                } else {
                                    completion(Result.failure(CustomError.errorWithDecoding))
                                }
                            }
                            
                            /// Hiding activity indicator
                            SVProgressHUD.dismiss()
                        } catch let error {
                            completion(Result.failure(error))
                            
                            /// Hiding activity indicator
                            SVProgressHUD.dismiss()
                        }
                        
                    }
                })
                
            }
            
        }
        
    }
    
}

extension UIApplication {
    class func topViewController(controller: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController {
        if let navigationController = controller as? UINavigationController {
            return topViewController(controller: navigationController.visibleViewController)
        }
        if let tabController = controller as? UITabBarController {
            if let selected = tabController.selectedViewController {
                return topViewController(controller: selected)
            }
        }
        if let presented = controller?.presentedViewController {
            return topViewController(controller: presented)
        }
        return controller ?? UIViewController()
    }
}

