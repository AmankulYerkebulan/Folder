
import UIKit
import Alamofire
import SVProgressHUD

class OrderViewController: UIViewController {
    
    //    MARK: Properties
    var data: [LastOperationModel] = []
    
    var orderId: String?
    
    private let statusAlert = StatusAlert()
    
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.register(cellWithClass: UITableViewCell.self)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = Global.grey()
        tableView.separatorStyle = .none
        return tableView
    }()
    
    lazy var orderButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = Global.yellow()
        button.setTitle("Подтвердить и оплатить".localized(), for: .normal)
        button.setTitleColor(Global.dark(), for: .normal)
        button.titleLabel?.font = Global.sfSemiBold(size: 17)
        button.addTarget(self, action: #selector(orderLoans), for: .touchUpInside)
        button.cornerRadius = 4
        return button
    }()
    
    //    MARK: Life cycle
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let orderId = self.orderId {
            
            SVProgressHUD.show()
            NetworkManager.shared.makeRequest(apiRequest: .orderLoanStatus(orderId: orderId)) { (result: Result<Status>) in
                
                switch result {
                    
                case .success(let data):
                    self.statusAlert.setUpStatus(title: data.status)
                    UIView.animate(withDuration: 0.3, animations: {
                        self.statusAlert.alpha = 1
                    }) { (success) in
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
                            self.statusAlert.alpha = 0
                        })
                    }
                    SVProgressHUD.dismiss()
                case .failure(let error):
                    if let customError = error as? CustomError {
                        SVProgressHUD.show(withStatus: customError.errorDescription)
                    } else {
                        SVProgressHUD.show(withStatus: error.localizedDescription)
                    }
                }
            }
            
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViews()
        setupConstraints()
        statusAlert.alpha = 0
        
        self.navigationItem.title = "Заказ".localized()
        
    }
    
    private func setupViews() {
        
        self.view.addSubviews([tableView, orderButton, statusAlert])
        self.view.backgroundColor = .white
    }
    
    //    MARK: Constraints
    private func setupConstraints() {
        
        orderButton.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(16)
            make.right.equalToSuperview().offset(-16)
            make.height.equalTo(44)
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(self.view.safeAreaLayoutGuide).offset(-16)
            } else {
                make.bottom.equalTo(self.view).offset(-16)
            }
        }
        
        tableView.snp.makeConstraints { (make) in
            make.left.right.top.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        statusAlert.snp.makeConstraints { (make) in
            make.size.equalTo(self.view.snp.size)
        }

    }
    
    //    MARK: Functions
    @objc private func orderLoans() {
        
        if self.data.count > 0 {
            self.orderId = "\(self.data[0].order)"
        }
        
        if let orderId = self.orderId {
            SVProgressHUD.show()
            NetworkManager.shared.makeRequest(apiRequest: ApiRequests.orderLoans(orderId: orderId)) { (result: Result<PaymentModel>) in
                
                switch result {
                case .failure(let error):
                    SVProgressHUD.showError(withStatus: error.localizedDescription)
                case .success(let data):
                    let webVC = WebViewController()
                    webVC.webUrl = URL(string: data.url)
                    self.navigationController?.pushViewController(webVC)
                    SVProgressHUD.dismiss()
                }
                
            }
        }
        
    }
    
}

//MARK: UITableViewDelegate and UITableViewDataSource functions
extension OrderViewController: UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 1:
            return self.data.first?.loans.count ?? 0
        default:
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: String(describing: UITableViewCell.self))
        
        switch indexPath.section {
        case 0:
            cell.textLabel?.text = "Заказ".localized() + " №\(self.data.first?.order ?? 0)"
            cell.textLabel?.font = Global.sfRegular(size: 15)
        case 1:
            cell.textLabel?.numberOfLines = 2
            cell.detailTextLabel?.text = "\(self.data.first?.loans[indexPath.row].amount ?? 0) ₸"
            
            let main_string = "Залоговый билет".localized() + " №\(self.data.first?.loans[indexPath.row].loanId ?? "0")\n\(self.data.first?.loans[indexPath.row].operationType ?? "")"
            let string_to_color = "\(self.data.first?.loans[indexPath.row].operationType ?? "")"
            
            let range = (main_string as NSString).range(of: string_to_color)
            let strNumber: NSString = main_string as NSString
            let range2 = (strNumber).range(of: String(" №\(self.data.first?.loans[indexPath.row].loanId ?? "0")".suffix(8)))
//            let attribute = NSMutableAttributedString.init(string: fullText)
            let attribute = NSMutableAttributedString.init(string: main_string)
            attribute.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor(hexString: "#0088FF") ?? .blue , range: range)
            
            attribute.addAttribute(NSAttributedString.Key.font, value: Global.sfBold(size: StaticSize.s13) , range: range2)
            
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.lineSpacing = 1.71
            attribute.addAttribute(.paragraphStyle, value: paragraphStyle, range: NSMakeRange(0, attribute.length))

            cell.textLabel?.attributedText = attribute
            
            cell.textLabel?.font = Global.sfRegular(size: 12)
            cell.detailTextLabel?.font = Global.sfMedium(size: 15)
        default:
            cell.textLabel?.text = "Итого к оплате".localized()
            cell.detailTextLabel?.text = "\(self.data.first?.totalSum ?? 0)".formatToNorm() + " ₸"
            cell.textLabel?.font = Global.sfMedium(size: 15)
            cell.detailTextLabel?.font = Global.sfSemiBold(size: 17)
        }
        cell.detailTextLabel?.textColor = Global.dark()
        cell.setUpCellShadow()
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
            return 0
        } else if section == 1 {
            return 16
        } else {
            return 8
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        if section == 2 {
            return 70
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 1 {
            return 52
        }
        return UITableView.automaticDimension
    }
    
}
