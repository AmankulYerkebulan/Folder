
import UIKit

class QuestionHeaderView: UITableViewHeaderFooterView {
    
//    MARK: Properties
    lazy var backGroundView: UIView = {
        let view = UIView()
        view.backgroundColor = Global.white()
        view.cornerRadius = 5
        return view
    }()
    
    lazy var questionLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.font = Global.sfMedium(size: StaticSize.s15)
        label.textColor = Global.dark()
        label.backgroundColor = Global.white()
        label.text = "Списывается ли комиссия за годовое обслуживание кредитной карты?".localized()
        return label
    }()
    
    lazy var collapseButton: UIButton = {
        let button = UIButton()
        return button
    }()
    
    lazy var hiddenButton: UIButton = {
        let button = UIButton()
        return button
    }()
    
//    MARK: Init
    override init(reuseIdentifier: String?) {
        super.init(reuseIdentifier: reuseIdentifier)
        
        setupViews()
        setupConstraints()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        
        self.addSubviews([backGroundView])
        backGroundView.addSubviews([questionLabel, collapseButton, hiddenButton])
    }
    
    override func layoutSubviews() {
        
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
    }
    
//    MARK: Constraints
    private func setupConstraints() {
        
        self.backGroundView.snp.makeConstraints { make in
            make.left.top.equalToSuperview().offset(16)
            make.right.equalToSuperview().offset(-16)
            make.bottom.equalToSuperview()
        }
        
        questionLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(16)
            make.top.equalToSuperview().offset(13)
            make.width.equalToSuperview().multipliedBy(0.8)
            make.bottom.equalToSuperview().offset(-13)
        }
        
        collapseButton.snp.makeConstraints { (make) in
            make.width.height.equalTo(self.snp.width).multipliedBy(0.1)
            make.right.equalToSuperview()
            make.centerY.equalToSuperview()
        }
        
        hiddenButton.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    func reConstrainsTop(index: Int) {
        if index != 0 {
            self.backGroundView.snp.remakeConstraints { make in
                make.top.equalToSuperview().offset(8)
                make.left.equalToSuperview().offset(16)
                make.right.equalToSuperview().offset(-16)
                make.bottom.equalToSuperview()
            }
        } else {
            self.backGroundView.snp.remakeConstraints { make in
                make.left.top.equalToSuperview().offset(16)
                make.right.equalToSuperview().offset(-16)
                make.bottom.equalToSuperview()
            }
        }
    }
    
}
