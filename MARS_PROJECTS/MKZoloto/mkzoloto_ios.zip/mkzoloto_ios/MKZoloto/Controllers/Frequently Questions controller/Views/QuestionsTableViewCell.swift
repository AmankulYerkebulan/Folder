
//
//  QuestionsTableViewCell.swift
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import UIKit

class QuestionsTableViewCell: UITableViewCell {
    
//    MARK: Properties
    lazy var answerLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.font = Global.sfRegular(size: StaticSize.s12)
        label.textColor = Global.dark()
        label.text = "Да, списание комиссии происходит автоматически, после активации кредитного лимита".localized()
        return label
    }()
    
//    MARK: Life cycle
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        setupViews()
        setupConstraints()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        
        contentView.roundCorners([.bottomRight,.bottomLeft], radius: 5)
        if ScreenSize.SCREEN_WIDTH - 16 < contentView.frame.size.width {
            contentView.frame = contentView.frame.inset(by: UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 16))
        }
    }
    
    private func setupViews() {
        
        contentView.backgroundColor = .white
        self.addSubviews([answerLabel])
        self.backgroundColor = .clear
        self.separatorInset = .zero
        self.selectionStyle = .none
    }
    
//    MARK: Constraints
    private func setupConstraints() {
        
        answerLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(34)
            make.width.equalToSuperview().multipliedBy(0.8)
            make.top.equalToSuperview()
            make.bottom.equalToSuperview().offset(-StaticSize.s12)
        }
    }
}
