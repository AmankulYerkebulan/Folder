
import Foundation
import Alamofire
import SVProgressHUD

class FaqViewModel {
    
    var data: [QuestionModel] = [QuestionModel]()
    
    init() {
        
    }
    
    func fetchQuestionAnswers(completion: @escaping () -> ()) {
        
        SVProgressHUD.show()
        
        NetworkManager.shared.makeRequest(apiRequest: .getFaq) { (result: Result<[QuestionModel]>) in
            
            switch result {
            case .failure(let error):
                debugPrint(error)
                SVProgressHUD.dismiss()
            case .success(let data):
                self.data = data
                SVProgressHUD.dismiss()
                completion()
            }
            
        }
        
    }

}
