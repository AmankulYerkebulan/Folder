
import UIKit
import RxGesture

extension FrequentlyQuestionsViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.faqViewModel.data.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        MARK: TODO
        let isCollapsed = self.faqViewModel.data[section].isExpanded
        
        if (isCollapsed == true) {
            return 1
        } else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withClass: QuestionsTableViewCell.self, for: indexPath)
        
        cell.answerLabel.text = self.faqViewModel.data[indexPath.section].answer
        return cell
    }
    
}

extension FrequentlyQuestionsViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return self.cellHeightDictionary[indexPath.row] ?? 60
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView = tableView.dequeueReusableHeaderFooterView(withClass: QuestionHeaderView.self)
        headerView.hiddenButton.tag = section
        
        headerView.reConstrainsTop(index: section)
        headerView.layoutSubviews()
        
        headerView.hiddenButton.addTarget(self, action: #selector(collapseSection(button: )), for: .touchUpInside)
        
        let model = self.faqViewModel.data[section]
        
        headerView.questionLabel.text = model.question
        
        headerView.collapseButton.setImage(model.isExpanded ? #imageLiteral(resourceName: "Arrow Small 53%"): #imageLiteral(resourceName: "Arrow Small 50%"), for: .normal)
        if model.isExpanded == true {
            headerView.backGroundView.cornerRadius = 0
            headerView.backGroundView.frame = CGRect(x: 0, y: 0, width: ScreenSize.SCREEN_WIDTH, height: 100)
            headerView.backGroundView.roundCorners([.topLeft,.topRight], radius: 5)
        } else {
            headerView.backGroundView.cornerRadius = 5
        }
        return headerView
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        self.cellHeightDictionary[indexPath.row] = cell.frame.size.height
    }
    
}
