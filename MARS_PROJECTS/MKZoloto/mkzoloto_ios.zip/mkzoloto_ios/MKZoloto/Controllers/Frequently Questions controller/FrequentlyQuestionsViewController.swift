
import UIKit

class FrequentlyQuestionsViewController: UIViewController {
    
//    MARK: Properties
    var faqViewModel = FaqViewModel()
    
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        
        tableView.register(cellWithClass: QuestionsTableViewCell.self)
        tableView.register(headerFooterViewClassWith: QuestionHeaderView.self)
        
        tableView.estimatedRowHeight = 60
        tableView.estimatedSectionHeaderHeight = 60
        tableView.sectionFooterHeight = 0
        
        tableView.estimatedRowHeight = UITableView.automaticDimension
        tableView.sectionHeaderHeight = UITableView.automaticDimension
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorColor = .white
        tableView.backgroundColor = Global.grey()
        
        return tableView
    }()
    
    var cellHeightDictionary: [Int : CGFloat] = [:]
    
//    MARK: Life cycle
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.tabBarController?.tabBar.isHidden = true
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViews()
        setupConstraints()
        
        navigationItem.title = "Часто задаваемые вопросы".localized().uppercased()
        
        faqViewModel.fetchQuestionAnswers {
            self.tableView.reloadData()
        }
        
    }
    
    private func setupViews() {
    
        self.view.addSubviews([tableView])
        self.view.backgroundColor = Global.grey()
    }
    
    @objc func collapseSection(button: UIButton) {
        
        let section = button.tag
        
        self.faqViewModel.data[section].isExpanded = !self.faqViewModel.data[section].isExpanded
        UIView.setAnimationsEnabled(false)
        tableView.reloadData()
        UIView.setAnimationsEnabled(true)
        
    }
    
    
//    MARK: Consrtaints
    private func setupConstraints() {
        
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
    }
    
}
