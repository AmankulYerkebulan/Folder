
import UIKit

class PushHistoryCell: UITableViewCell {
    
    //    MARK: Properties
    
    /// Function for expanding view
    var expandLabel = { () -> () in }
    
    lazy var pushLabel: UILabel = {
        let label = UILabel()
        label.font = Global.sfMedium(size: 15)
        label.textColor = Global.dark()
        return label
    }()
    
    lazy var dateLabel: UILabel = {
        let label = UILabel()
        label.font = Global.sfMedium(size: 12)
        label.textColor = Global.dark().withAlphaComponent(0.5)
        return label
    }()
    
    lazy var collapseButton: UIButton = {
        let button = UIButton()
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        button.setImage(#imageLiteral(resourceName: "Arrow Small 50%"), for: UIControl.State.normal)
        return button
    }()
    
    //    MARK: Life cycle
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        setupViews()
        setupConstraints()
        
        self.layoutIfNeeded()
        self.selectionStyle = .none
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(expandPushLabel))
        self.addGestureRecognizer(tapGesture)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
    
        self.addSubviews([pushLabel, dateLabel])
        self.insertSubview(collapseButton, belowSubview: contentView)
        textLabel?.lineBreakMode = .byTruncatingTail
        
        configureCell()
        self.setUpCellShadow()
        
    }
    
    //    MARK: Constraints
    private func setupConstraints() {
        
        pushLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(StaticSize.s16)
            make.left.equalToSuperview().offset(StaticSize.s16)
            make.bottom.equalTo(dateLabel.snp.top).offset(-StaticSize.s8)
            make.width.equalTo(StaticSize.s227)
        }
        
        dateLabel.snp.makeConstraints { (make) in
            make.bottom.equalTo(self.snp.bottom).offset(-StaticSize.s8)
            make.left.equalTo(pushLabel)
            make.width.equalTo(StaticSize.s100)
        }
        
        collapseButton.snp.makeConstraints { (make) in
            make.width.height.equalTo(self.snp.width).multipliedBy(0.1)
            make.right.equalTo(-16)
            make.top.equalToSuperview().offset(StaticSize.s16)
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        if pushLabel.numberOfLines == 1 {
            pushLabel.snp.remakeConstraints { (make) in
                make.width.equalTo(StaticSize.s227)
                make.top.equalToSuperview().offset(StaticSize.s13)
                make.left.equalToSuperview().offset(StaticSize.s16)
                make.bottom.equalTo(dateLabel.snp.top).offset(-StaticSize.s8)
            }
        } else {
            pushLabel.snp.makeConstraints { (make) in
                make.width.equalToSuperview().multipliedBy(0.9)
                make.top.equalToSuperview().offset(StaticSize.s13)
                make.left.equalToSuperview().offset(StaticSize.s16)
                make.bottom.equalTo(dateLabel.snp.top).offset(-StaticSize.s8)
            }
        }
        
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
    }
    
    
    //    MARK: Functions
    public func configureCell() {
        
        pushLabel.text = "Уважаемый клиент. Кредит просрочен. Гарантийный срок истекает через 27 дней"
        dateLabel.text = "01 Марта 2019"
        self.backgroundColor = Global.white()
        self.contentView.backgroundColor = .clear
    }
    
    //    MARK: Targets
    @objc private func expandPushLabel() {
        
        expandLabel()
    }
    
}
