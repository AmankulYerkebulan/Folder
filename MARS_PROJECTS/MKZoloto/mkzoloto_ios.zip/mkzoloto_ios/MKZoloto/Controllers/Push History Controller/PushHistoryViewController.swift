
import UIKit

class PushHistoryViewController: UIViewController {
    
    //    MARK: Properties
    lazy var tableView: UITableView = {
        let tableView = UITableView()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        tableView.register(cellWithClass: PushHistoryCell.self)
        
        tableView.backgroundColor = Global.grey()
        tableView.separatorStyle = .none
        
        return tableView
    }()
    
    //    MARK: Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViews()
        setupConstraints()
        
    }
    
    private func setupViews() {
        
        self.view.addSubview(tableView)
        self.navigationItem.title = "История уведомлений".localized()
    }
    
    //    MARK: Constraints
    private func setupConstraints() {
        
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
    }
    
    //    MARK: Functions
    
    
}

//MARK: UITableViewDelegate and UITableViewDataSource functions
extension PushHistoryViewController: UITableViewDelegate, UITableViewDataSource {

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withClass: PushHistoryCell.self, for: indexPath)
        
        cell.expandLabel = { [unowned self] in
            
            cell.pushLabel.numberOfLines = (cell.pushLabel.numberOfLines == 0) ? 1 : 0
            cell.collapseButton.setImage(cell.pushLabel.numberOfLines == 0 ? #imageLiteral(resourceName: "Arrow Small 53%") : #imageLiteral(resourceName: "Arrow Small 50%"), for: UIControl.State.normal)
            cell.layoutIfNeeded()
            self.tableView.reloadData()
            
        }
        
        return cell
    }
    
}
