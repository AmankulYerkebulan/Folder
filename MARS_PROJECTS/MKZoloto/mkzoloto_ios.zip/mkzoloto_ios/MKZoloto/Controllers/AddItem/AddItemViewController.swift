
import UIKit
import Alamofire
import SVProgressHUD

class AddItemViewController: UIViewController {
    
    var data:[GoldSample]?
    
    private lazy var tableView : UITableView = {
        let tView = UITableView()
        tView.register(CalculatorCell.self, forCellReuseIdentifier: "CalculatorCell")
        tView.delegate = self
        tView.dataSource = self
        tView.separatorStyle = .none
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 40, height: 8))
        let view1 = UIView(frame: CGRect(x: 0, y: 0, width: 40, height: 8))
        view.backgroundColor = Global.white()
        view1.backgroundColor = Global.white()
        tView.tableHeaderView = view
        tView.tableFooterView = view1
        tView.cornerRadius = 5
        tView.isScrollEnabled = false
        tView.addShadow(ofColor: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), radius: 3, offset: .zero, opacity: 0.1)
        return tView
    }()
    
    private lazy var button: UIButton = {
        let button = UIButton()
        button.setTitle("Добавить".localized(), for: UIControl.State.normal)
        button.yellowBtnProperty()
        button.layer.cornerRadius = 4
        button.addTarget(self, action: #selector(addAction), for: UIControl.Event.touchUpInside)
        return button
    }()
    
    private lazy var hiteLabel: UILabel = {
        let label = UILabel()
        label.font = Global.sfRegular(size: StaticSize.s12)
        label.textColor = Global.dark()
        label.text = "* - вес золота в изделии без камней и недрагоценных элементов".localized()
        label.numberOfLines = 0
        label.contentMode = .left
        return label
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.addSubviews([tableView, hiteLabel, button])
        self.view.backgroundColor = .white
        
        tableView.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.top.equalTo(self.view.safeAreaLayoutGuide).offset(StaticSize.s16)
            } else {
                make.top.equalTo(self.view).offset(StaticSize.s16)
            }
            make.left.equalTo(self.view.snp.left).offset(StaticSize.s8)
            make.right.equalTo(self.view.snp.right).offset(-StaticSize.s8)
            make.height.equalTo(3 * (StaticSize.s50 + (StaticSize.s6 / 3)) + StaticSize.s16 + 16 + self.hiteLabel.bounds.size.height + StaticSize.s25)
        }
        
        button.snp.makeConstraints { (make) in
            make.bottom.equalTo(self.view.snp.bottom).offset(-StaticSize.s30)
            make.left.equalTo(self.view.snp.left).offset(StaticSize.s16)
            make.right.equalTo(self.view.snp.right).offset(-StaticSize.s16)
            make.height.equalTo(StaticSize.s44)
        }
        
        hiteLabel.snp.makeConstraints { (make) in
            make.bottom.equalTo(self.tableView.snp.bottom).offset(-StaticSize.s12)
            make.left.equalTo(self.tableView.snp.left).offset(StaticSize.s16)
            make.right.equalTo(self.tableView.snp.right).offset(-StaticSize.s16)
        }
        
        SVProgressHUD.show()
        
        NetworkManager.shared.makeRequest(apiRequest: ApiRequests.getGoldSamples) { (result : Result<[GoldSample]>) in
            switch result {
            case .success(let data):
                self.data = data
                self.tableView.reloadData()
                SVProgressHUD.dismiss()
            case .failure(let error):
                if let customError = error as? CustomError {
                    SVProgressHUD.showError(withStatus: customError.errorDescription)
                } else {
                    SVProgressHUD.showError(withStatus: error.localizedDescription)
                }
            }
        }
        
    }

    @objc private func addAction() {
        if let cell1 = tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as? CalculatorCell,
            let cell2 = tableView.cellForRow(at: IndexPath(row: 2, section: 0)) as? CalculatorCell,
            let cell3 = tableView.cellForRow(at: IndexPath(row: 1, section: 0)) as? CalculatorCell {
            //TODO PROB
            let weight = cell2.textField.text?.isEmpty
            if let gold = NetworkManager.shared.golfStorage {
                gold.name = cell1.textField.text
                gold.weight = weight == true ? nil : Double(cell2.textField.text!)
                gold.au = cell3.textField.text
            } else {
                NetworkManager.shared.golfStorage = GoldSampleForStorage(id: nil, key: nil, value: nil, name: cell1.textField.text, weight: weight == true ? nil : Double(cell2.textField.text!),au: cell3.textField.text)
            }
        }
        if let gold = NetworkManager.shared.golfStorage {
            StoreManager.shared().setGoldSampleForStorage(value: gold)
            NetworkManager.shared.golfStorage = nil
            self.navigationController?.popViewController()
        }
    }
    
}
extension AddItemViewController: UITableViewDelegate,UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CalculatorCell", for: indexPath) as! CalculatorCell
        cell.isDropDownTextField = indexPath.row == 1 ? true : false
        if indexPath.row == 0 {
            cell.textField.placeholder = "Наименование изделия".localized()
            cell.textField.keyboardType = .default
        } else if indexPath.row == 1 {
            cell.textField.placeholder = "Проба золота".localized()
            cell.goldSample = self.data ?? []
        } else {
            cell.textField.keyboardType = .numbersAndPunctuation
            cell.textField.placeholder = "Вес изделия, грамм".localized()
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        let newCell = cell as! CalculatorCell
        newCell.reSetUpConstreins()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return StaticSize.s50 + (StaticSize.s6 / 3)
    }
    
}
