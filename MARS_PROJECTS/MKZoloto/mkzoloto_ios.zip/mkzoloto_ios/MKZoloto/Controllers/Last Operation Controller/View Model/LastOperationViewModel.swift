
import Alamofire
import SVProgressHUD

class LastOperationViewModel {
    
    var data: [LastOperationModel] = []
    
    init () { }
    
    func fetchOperations(completion: @escaping () -> ()) {
        
        SVProgressHUD.show()
        NetworkManager.shared.makeRequest(apiRequest: .getOperations) { (result: Result<[LastOperationModel]>) in
            
            switch result {
                
            case .failure(let error):
                SVProgressHUD.showError(withStatus: error.localizedDescription)
            case .success(let data):
                self.data = data
                SVProgressHUD.dismiss()
                completion()
            }
            
        }
        
    }
    
}
