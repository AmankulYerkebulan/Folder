
import UIKit

/**
 Fully information of receipt
 */
enum ReceiptFullyInfoLabelTypes: Int {
    /// Id of this payd receipt
    case idOfOrder
    /// Date of receipt when its payed
    case date
    /// Location where this payd
    case locationOfOperation
    /// Status of receipt
    case status
}

class ReceiptViewController: UIViewController {
    
//    MARK: Properties
    var operation: LastOperationModel?
    
    var cellData = ["Номер квитанций".localized(), "Дата и время".localized(), "Место операций".localized(), "Оплачено".localized(), "Статус".localized()]
    
    lazy var rightButton = UIBarButtonItem(image: #imageLiteral(resourceName: "pdf").withRenderingMode(.alwaysOriginal), style: .done, target: self, action: nil)
    
    
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        
        tableView.delegate = self
        tableView.dataSource = self
        
        tableView.register(cellWithClass: UITableViewCell.self)
        
        tableView.separatorStyle = .none
        
        return tableView
    }()
    
//    MARK: Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViews()
        setupConstraints()
        
        self.navigationItem.rightBarButtonItem = rightButton
        
    }
    
    private func setupViews() {
        
        self.view.addSubview(tableView)
        self.navigationItem.title = "Квитанция".localized()
        
    }
    
//    MARK: Constraints
    private func setupConstraints() {
        
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
    }
    
//    MARK: Functions
    
}

//MARK: UITableViewDelegate and UITableViewDataSource functions
extension ReceiptViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return ReceiptFullyInfoLabelTypes.status.rawValue + 1
        case 1:
            
            guard let _operation = self.operation else { return 0 }
            
            return _operation.loans.count
        default:
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: .value1, reuseIdentifier: String(describing: UITableViewCell.self))
        
        cell.selectionStyle = .none
        
        guard let _operation = self.operation else {
            return UITableViewCell()
        }
        cell.addShadow(ofColor: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), radius: 3, offset: .zero, opacity: 0.1)
        // REMOVE this TODO configuring cell
        switch indexPath.section {
        case 0:
            
            cell.detailTextLabel?.font = Global.sfMedium(size: StaticSize.s15)
            cell.detailTextLabel?.adjustsFontSizeToFitWidth = true
            cell.detailTextLabel?.textColor = Global.dark()
            cell.textLabel?.textColor = Global.dark()
            cell.textLabel?.font = Global.sfMedium(size: StaticSize.s15)
            cell.textLabel?.adjustsFontSizeToFitWidth = true
            
            guard let receiptCellTypes = ReceiptFullyInfoLabelTypes(rawValue: indexPath.row) else { return UITableViewCell() }
            
            switch receiptCellTypes {
                
            case .idOfOrder:
                cell.detailTextLabel?.text = "\(_operation.order)"
            case .date:
                cell.detailTextLabel?.text = _operation.date.formattedDate()
            case .locationOfOperation:
                cell.detailTextLabel?.text = _operation.place
            case .status:
                cell.detailTextLabel?.text = _operation.status
                cell.detailTextLabel?.textColor = UIColor(hexString: "#6AC259")
            }
            
            cell.textLabel?.text = self.cellData[receiptCellTypes.rawValue]
        
        case 1:
            
                cell.textLabel?.numberOfLines = 2
                cell.detailTextLabel?.text = "\("\(_operation.loans[indexPath.row].amount)".formatToNorm()) ₸"
                
                let main_string = "Залоговый билет".localized() + " №\(_operation.loans[indexPath.row].loanId )\n\(_operation.loans[indexPath.row].operationType )"
                
                let string_to_color = "\(_operation.loans[indexPath.row].operationType )"
                
                let range = (main_string as NSString).range(of: string_to_color)
                
                let attribute = NSMutableAttributedString.init(string: main_string)
                attribute.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor(hexString: "#0088FF") ?? .blue , range: range)
                
                let string_to_bold = "\(_operation.loans[indexPath.row].loanId )"
                let boldRange = (main_string as NSString).range(of: String(string_to_bold.characters.suffix(8)))
                attribute.addAttribute(NSAttributedString.Key.font, value: Global.sfBold(size: StaticSize.s13) , range: boldRange)
                
                let paragraphStyle = NSMutableParagraphStyle()
                paragraphStyle.lineSpacing = 3
                attribute.addAttribute(.paragraphStyle, value: paragraphStyle, range: NSMakeRange(0, attribute.length))
                
                cell.textLabel?.attributedText = attribute
                
                cell.textLabel?.font = Global.sfRegular(size: 12)
                cell.detailTextLabel?.font = Global.sfMedium(size: 15)
                cell.detailTextLabel?.textColor = Global.dark()
            
                cell.detailTextLabel?.snp.remakeConstraints { make in
                    make.centerY.equalToSuperview()
                    make.right.equalToSuperview().offset(-StaticSize.s16)
                }
            
        default:
            cell.detailTextLabel?.font = UIFont.systemFont(ofSize: 16, weight: .bold)
            cell.textLabel?.text = "Итоговая сумма".localized()
            cell.detailTextLabel?.text = "\("\(_operation.totalSum)".formatToNorm()) ₸"
            cell.detailTextLabel?.font = Global.sfMedium(size: 15)
            cell.detailTextLabel?.textColor = Global.dark()
        }
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 1 {
            return 24
        } else if section == 2 {
            return 8
        } else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 1 {
            return 60
        }
        
        return UITableView.automaticDimension
    }
    
}
