
import UIKit

class LastOperationViewController: UIViewController {
    
//    MARK: Properties
    var lastOperationViewModel = LastOperationViewModel()
    
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        
//        tableView.register(cellWithClass: LastOperationTableViewCell.self)
        tableView.register(cellWithClass: UITableViewCell.self)
        
        tableView.delegate = self
        tableView.dataSource = self
        
        tableView.separatorStyle = .none
        tableView.backgroundColor = Global.grey()
        
        return tableView
    }()
    
//    MARK: Life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViews()
        setupConstraints()
        
        self.lastOperationViewModel.fetchOperations {
            
            self.tableView.reloadData()
            
        }

        
    }
    
    private func setupViews() {
        
        self.view.addSubviews([tableView])
        self.navigationItem.title = "Мои последние операции".localized()
        
    }
    
//    MARK: Constraints
    private func setupConstraints() {
        
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
    }
    
//    MARK: Functions
    
    
}

//MARK: UITableViewDataSource and UITableViewDelegate functions
extension LastOperationViewController: UITableViewDelegate, UITableViewDataSource {
   
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.lastOperationViewModel.data.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.lastOperationViewModel.data[section].loans.count > 0 {
            return self.lastOperationViewModel.data[section].loans.count + 1
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let model = self.lastOperationViewModel.data[indexPath.section]
        
        switch indexPath.row {
        case 0:
            let cell = UITableViewCell(style: .value1, reuseIdentifier: String(describing: UITableViewCell.self))
            cell.selectionStyle = .none
            cell.textLabel?.text = "Заказ".localized() + " №\(model.order)"
            cell.textLabel?.font = Global.sfRegular(size: 15)
            
            cell.imageView?.image = nil
            cell.accessoryView = UIImageView(image: #imageLiteral(resourceName: "Icon"))
            
            cell.detailTextLabel?.text = "\("\(lastOperationViewModel.data[indexPath.section].totalSum)".formatToNorm()) ₸"
            cell.detailTextLabel?.font = Global.sfMedium(size: 15)
            cell.detailTextLabel?.textColor = Global.dark()
            
            cell.setUpCellShadow()
            
            return cell
        default:
            let cell = UITableViewCell(style: .subtitle, reuseIdentifier: String(describing: UITableViewCell.self))
            cell.selectionStyle = .none
            cell.textLabel?.text = "\(model.loans[indexPath.row - 1].operationType)\n"
            cell.textLabel?.font = Global.sfRegular(size: 12)
            cell.textLabel?.textColor = UIColor(hexString: "#0088FF") ?? .blue

            cell.imageView?.image = lastOperationViewModel.data[indexPath.section].status == "в обработке" ? #imageLiteral(resourceName: "icon-3") : #imageLiteral(resourceName: "checked-1")
            
            cell.detailTextLabel?.halfTextColorChange(fullText: "Залоговый билет".localized() + " №\(model.loans[indexPath.row - 1].loanId ?? "")", changeText: String("\(model.loans[indexPath.row - 1].loanId)".characters.suffix(8)), fontSize: StaticSize.s13)
            cell.detailTextLabel?.textColor = Global.dark()
            cell.detailTextLabel?.font = Global.sfRegular(size: 12)
            
            cell.accessoryView?.tintColor = .black
            
            cell.setUpCellShadow()
            
            return cell
        }
        
        
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 96
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return self.lastOperationViewModel.data[section].date.formattedDate()
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 16 + 8 + 16
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if (indexPath.row == 0) {
            let vc = ReceiptViewController()
            vc.operation = self.lastOperationViewModel.data[indexPath.section]
            self.navigationController?.pushViewController(vc)
        }
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        cell.layoutIfNeeded()
        cell.layer.addBorder(edge: [.bottom], color: Global.grey(), thickness: 1)
        
    }
    
}
