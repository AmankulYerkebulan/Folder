
import UIKit
import Cartography

class OcenkaKapitalaTableCell: UITableViewCell {

    private lazy var Title: UILabel = {
        let label = UILabel()
        label.font = Global.sfSemiBold(size: StaticSize.s15)
        label.textColor = Global.dark()
        label.numberOfLines = 0
        return label
    }()
    
    private lazy var subTitle: UILabel = {
        let label = UILabel()
        label.font = Global.sfRegular(size: StaticSize.s12)
        label.textColor = Global.dark()
        return label
    }()
    
    private lazy var priceTitle: UILabel = {
        let label = UILabel()
        label.font = Global.sfSemiBold(size: StaticSize.s15)
        label.textColor = Global.dark()
        return label
    }()

    lazy var switcher: UISwitch = {
        let switcher = UISwitch()
        switcher.isOn = true
        return switcher
    }()
    
    lazy var removeButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "removeButtton"), for: UIControl.State.normal)
        return button
    }()
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("Some error")
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
        setupConstraints()
    }
}


extension OcenkaKapitalaTableCell {

    private func setupViews() {

        self.addSubviews([Title, subTitle, priceTitle, switcher,removeButton])
        self.setUpCellShadow()
    }
    
    private func setupConstraints() {

        Title.snp.makeConstraints { (make) in
            make.top.equalTo(switcher.snp.top).offset(-3)
            make.left.equalTo(switcher.snp.right).offset(8)
            make.right.equalTo(self.snp.right).offset(-80)
        }
        
        subTitle.snp.makeConstraints { (make) in
            make.top.equalTo(Title.snp.bottom).offset(8)
            make.left.equalTo(Title)
            make.bottom.equalToSuperview().offset(-12)
        }
        
        switcher.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(18)
            make.left.equalToSuperview().offset(16)
            make.width.equalTo(51)
            make.height.equalTo(30)
        }
        
        priceTitle.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-32)
            make.centerY.equalToSuperview()
        }
        
        removeButton.snp.makeConstraints { (make) in
            make.right.equalTo(self.snp.right).offset(-16)
            make.centerY.equalTo(self.snp.centerY)
            make.width.equalTo(22)
            make.height.equalTo(22)
        }
    }
    
    
    func setUpDetails(Title: String, subTitle: String, switcher: Bool, priceTitle: String) {
        self.Title.text   = Title
        self.subTitle.text    = subTitle
        self.priceTitle.text = priceTitle
    }
}





