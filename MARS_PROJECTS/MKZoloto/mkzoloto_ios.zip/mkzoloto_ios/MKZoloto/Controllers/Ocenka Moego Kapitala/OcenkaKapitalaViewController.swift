
import UIKit
import SwifterSwift
import SnapKit
import Alamofire
import SVProgressHUD

struct CellData {

    var opened = Bool()
    var title = String()
    var sectionData = [String]()
}

class OcenkaKapitalaViewController: UIViewController {
    
    var purchaseItems: [PurchasedItem]?
    var indexOfLocal = 0
    
    var sum:Int = 0
    
    private lazy var button: UIButton = {
        let button = UIButton()
        button.setTitle("Добавить изделие".localized(), for: UIControl.State.normal)
        button.yellowBtnProperty()
        button.layer.cornerRadius = 4
        button.addTarget(self, action: #selector(additem), for: UIControl.Event.touchUpInside)
        return button
    }()
    
    private lazy var topCustomView : UIView = {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        view.backgroundColor = .white
        return view
    }()

    private lazy var topLabel : UILabel = {
        let label = UILabel(frame: CGRect(x: 16, y: 0, width: UIScreen.main.bounds.width - 40, height: 50))
        label.font = UIFont(name: "AvenirNext-Medium", size: 12)
        label.numberOfLines = 0
        label.textColor = .black
        return label
    }()

    private lazy var customView : UIView = {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 90))
        view.backgroundColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 0.2452108305)
        return view
    }()

    private lazy var customBtn: UIButton = {
        let button = UIButton(frame: CGRect(x: 0, y: 40, width: UIScreen.main.bounds.width, height: 50))
        button.setTitle("Добавить изделие".localized(), for: .normal)
        button.setTitleColor(.black, for: .normal)
        button.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        button.backgroundColor = .white
        return button
    }()
    
    private lazy var tableView : UITableView = {
        let tView = UITableView()
        tView.register(cellWithClass: OcenkaKapitalaTableCell.self)
        tView.register(UITableViewCell.self, forCellReuseIdentifier: "cell1")
        tView.register(UITableViewCell.self, forCellReuseIdentifier: "cell2")
        tView.delegate = self
        tView.backgroundColor = Global.grey()
        tView.separatorStyle = .none
        tView.dataSource = self
        return tView
    }()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    
        let request = ApiRequests.purchasedItems
        SVProgressHUD.show()
        
        NetworkManager.shared.makeRequest(apiRequest: request) { (result: Result<[PurchasedItem]>) in
            switch result {
            case .success(let data):
                self.sum = 0
                self.purchaseItems = data
                self.indexOfLocal = (self.purchaseItems?.count)!
                let storageGolds = StoreManager.shared().goldSamplesForStorage()
                for i in storageGolds {
                    if let name = i.name,
                        let value = i.value,
                        let weight = i.weight,
                        let _au  = i.au {
                        self.purchaseItems!.append(PurchasedItem(name: name, prob: String(value), weight: String(weight),au: _au))
                    }
                }
                self.tableView.reloadData()
                SVProgressHUD.dismiss()
            case .failure(let error):
                if let customError = error as? CustomError {
                    SVProgressHUD.showError(withStatus: customError.errorDescription)
                } else {
                    SVProgressHUD.showError(withStatus: error.localizedDescription)
                }
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        setupViews()
        setupConstraints()
    }
}

extension OcenkaKapitalaViewController {


    @objc func buttonAction(_ sender: UIButton!) {
        print("Button tapped")
    }

    // Настройка вьюшки
    private func setupViews() {

        NotificationCenter.default.removeObserver(self, name: NSNotification.Name("ITEMRREMOVED"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(removePresseed(sender:)), name: NSNotification.Name("ITEMRREMOVED"), object: nil)
        
        self.view.addSubviews([topLabel, tableView])
        self.view.insertSubview(button, aboveSubview: tableView)
        customView.addSubview(customBtn)
        topCustomView.addSubview(topLabel)
        self.view.backgroundColor = Global.grey()
        self.title = "Оценка моего капитала".localized()
        self.navigationController?.setUpShadow()
    }
    
    // Настройка констрэинов
    private func setupConstraints() {

        tableView.snp.makeConstraints{ make in
            make.edges.equalToSuperview()
        }
        
        button.snp.makeConstraints { (make) in
            make.bottom.equalTo(self.view.snp.bottom).offset(-StaticSize.s30)
            make.left.equalTo(self.view.snp.left).offset(StaticSize.s16)
            make.right.equalTo(self.view.snp.right).offset(-StaticSize.s16)
            make.height.equalTo(StaticSize.s44)
        }
    }
}


extension OcenkaKapitalaViewController : UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let items = purchaseItems else {return 0}
        if section == 0 {
            return items.count
        } else {
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let items = purchaseItems else {return UITableViewCell()}
        
        if indexPath.section == 0 {
            
            let cell = tableView.dequeueReusableCell(withClass: OcenkaKapitalaTableCell.self, for: indexPath)
            cell.accessoryType = .disclosureIndicator
            if items[indexPath.row].au999 == nil {
                cell.removeButton.tag = indexPath.row
                cell.removeButton.isHidden = true
            } else {
                cell.removeButton.isHidden = true
            }
            
            let title = items[indexPath.row].name
            var price = Int((Double(items[indexPath.row].probe!)! * Double(items[indexPath.row].weight!)!).rounded())
            if items[indexPath.row].isFromServer == true {
                price = items[indexPath.row].maxAmountDateIssuse ?? 0
            }
            cell.setUpDetails(Title: title!, subTitle: "Получаю на руки".localized(), switcher: false, priceTitle: cell.switcher.isOn == true ? "\(price)".formatToNorm() + " ₸" : "———")
            if cell.switcher.isOn {
                sum += price
            }
            cell.switcher.addTarget(self, action: #selector(switchIsChanged), for: .valueChanged)
            return cell
        } else {
            let cell = UITableViewCell(style: .value1, reuseIdentifier: String(describing: UITableViewCell.self))
            
            cell.selectionStyle = .none
            cell.textLabel?.text = "Можно получить за изделия".localized()
            cell.accessoryType = .none
            cell.detailTextLabel?.text = "\(sum)".formatToNorm() + " ₸"
            cell.detailTextLabel?.textColor = Global.dark()
            cell.detailTextLabel?.font = Global.sfSemiBold(size: StaticSize.s15)
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        if indexPath.section == 0 {
            let vc = DetailitemViewController()
            
            if self.purchaseItems?[indexPath.row].isFromServer == false {
                vc.index = indexPath.row
            }
            vc.data = self.purchaseItems?[indexPath.row]
            vc.title = self.purchaseItems?[indexPath.row].name
            self.navigationController?.pushViewController(vc)
        }
    }
    
    @objc private func removePresseed(sender: NSNotification) {
        
        if let index = sender.object as? Int {
            self.sum = 0
            StoreManager.shared().removeGoldSampleForStorage(index: index - indexOfLocal)
            self.purchaseItems?.remove(at: index)
            self.tableView.reloadData()
        }
    }
    
    @objc private func switchIsChanged(sender: UISwitch) {
        sum = 0
        tableView.reloadData()
    }
    
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {

        return 96
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {

        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 1 {
            let date = Date()
            let formatter = DateFormatter()
            formatter.dateFormat = "dd.MM.yyyy"
            let result = formatter.string(from: date)
            return "Цена на".localized() + " \(result)"
        }
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 1 {
            let date = Date()
            let formatter = DateFormatter()
            formatter.dateFormat = "dd.MM.yyyy"
            let result = formatter.string(from: date)
            let view = UIView(frame: CGRect(x: 0, y: 0, width: ScreenSize.SCREEN_WIDTH, height: StaticSize.s36))
            let label = UILabel(frame: CGRect(x: StaticSize.s16, y: StaticSize.s8, width: ScreenSize.SCREEN_WIDTH, height: StaticSize.s36))
            label.font = Global.sfRegular(size: StaticSize.s12)
            label.textColor = Global.textFiledPlaceholderColor()
            view.addSubview(label)
            label.text = "Цена на".localized() + " \(result)"
            view.backgroundColor = .clear
            return view
        }
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 1 {
            return 44
        }
        return 0
    }
    
    @objc private func additem() {
        
        let vc = AddItemViewController()
        vc.title = "Добавление изделия".localized()
        self.navigationController?.pushViewController(vc)
    }
}
