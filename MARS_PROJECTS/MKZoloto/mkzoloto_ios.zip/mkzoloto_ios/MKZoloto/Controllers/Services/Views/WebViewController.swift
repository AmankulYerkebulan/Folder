

import UIKit
import WebKit
import SVProgressHUD

class WebViewController: UIViewController {

    var webView : WKWebView!
    var navTitle = String()
    
    var webUrl: URL?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        webView = WKWebView()
        webView.navigationDelegate = self
        if let _webUrl = webUrl {
            SVProgressHUD.show()
            webView.load(URLRequest(url: _webUrl))
        }
        
        webView.allowsBackForwardNavigationGestures = true
        
        self.view.addSubview(webView)
        self.view.backgroundColor = .red
        setupConstraints()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tabBarController?.tabBar.isHidden = true
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        SVProgressHUD.dismiss()
        
    }
    
}


extension WebViewController {
    
    func setupConstraints() {
        webView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
}

extension WebViewController: WKNavigationDelegate {
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        
        SVProgressHUD.dismiss()
    }
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: (WKNavigationActionPolicy) -> Void) {
        
        if let baseUrl = navigationAction.request.url?.absoluteString {
            if baseUrl == "https://mk-zoloto-lombard.kz/?status=fail" || baseUrl == "https://mk-zoloto-lombard.kz/?status=successful" {
                self.navigationController?.popViewController()
            }
        }
        
        decisionHandler(.allow)
    }
    
}
