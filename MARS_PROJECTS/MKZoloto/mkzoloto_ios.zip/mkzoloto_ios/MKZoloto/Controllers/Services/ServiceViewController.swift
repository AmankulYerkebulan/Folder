
import UIKit
import SnapKit

class ServiceViewController: UIViewController {
    
    var serviceViewModel = ServiceViewModel()
    
    private lazy var menuTableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: UITableView.Style.grouped)
        tableView.delegate   = self
        tableView.dataSource = self
        tableView.isScrollEnabled = true
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupButtons()
        setupConstraints()
        
        navigationItem.title = "Кто мы?".localized().uppercased()
        self.navigationController?.setUpShadow()
        self.serviceViewModel.fetchServices {
            self.menuTableView.reloadData()
        }
        
        self.menuTableView.contentInset = UIEdgeInsets(top: 16, left: 0, bottom: 0, right: 0)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tabBarController?.tabBar.isHidden = false
    }
}

extension ServiceViewController {
    func setupButtons() {
        self.view.addSubviews([menuTableView])
        self.view.backgroundColor = .white
    }
    
    func setupConstraints() {
        menuTableView.snp.makeConstraints { (make) in
//            make.edges.equalToSuperview()
            make.bottom.equalToSuperview()
            make.width.equalToSuperview()
            make.top.equalToSuperview().offset(StaticSize.s16)
        }
    }
}
