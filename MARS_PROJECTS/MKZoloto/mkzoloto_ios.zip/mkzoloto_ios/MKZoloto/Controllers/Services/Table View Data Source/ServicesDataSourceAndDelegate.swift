
import Foundation
import UIKit

extension ServiceViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        
//        if self.serviceViewModel.selectedArray[indexPath.section]?[indexPath.row].show_in_mobile == true {
//            if self.serviceViewModel.selectedArray[indexPath.section]?[indexPath.row].nativeType == "calculator" {
//                let controller = MainViewController()
//                controller.hidesBottomBarWhenPushed = true
//                self.navigationController?.pushViewController(controller)
//            } else if self.serviceViewModel.selectedArray[indexPath.section]?[indexPath.row].nativeType == "map" {
//                let services = BranchesViewController()
//                services.isFromFB = true
//                self.navigationController?.pushViewController(services)
//            } else if self.serviceViewModel.selectedArray[indexPath.section]?[indexPath.row].nativeType == "faq" {
//                let company = FeedbackViewController()
//                company.title = "Связаться".localized()
//                self.navigationController?.pushViewController(company)
//            }
//            return
//        }
        
        let vc = WebViewController()
        
        let data = self.serviceViewModel.tableData[indexPath.section]?[indexPath.row]
        vc.webUrl = data?.1
        vc.navigationItem.title = data?.0 ?? "Services"
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension ServiceViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        Constants.mainViewSectionOffset = 0
        let headerView = TableSectionHeaderView()
        
        headerView.titleLabel.text = self.serviceViewModel.tableSectionData[section].uppercased()
        headerView.titleLabel.font = Global.stroke(size: StaticSize.s17)
        headerView.titleLabel.textColor = Global.dark()
        return headerView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 44
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        cell.textLabel?.text = self.serviceViewModel.tableData[indexPath.section]?[indexPath.row].0
        cell.accessoryType = .disclosureIndicator
        cell.accessoryView = UIImageView(image: #imageLiteral(resourceName: "Icon"))
        cell.textLabel?.font = Global.sfMedium(size: StaticSize.s15)
        cell.textLabel?.textColor = Global.dark()
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.serviceViewModel.tableData[section]?.count ?? 0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.serviceViewModel.tableData.count
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return self.serviceViewModel.tableSectionData[section]
    }
    
}
