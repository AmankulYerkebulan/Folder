
import Alamofire
import SVProgressHUD

class ServiceViewModel {
    
    var data: [ServiceModel] = []
    
    var tableSectionData: [String] = []
    var tableData: [Int : [(String, URL)]] = [:]
    var selectedArray : [Int:[ServiceModel]] = [:]
    init() {
        
    }
    
    func fetchServices(completion: @escaping () -> ()) {
        
        SVProgressHUD.show()
        NetworkManager.shared.makeRequest(apiRequest: .getMenus) { (result: Result<[ServiceModel]>) in
            
            switch result {
                
            case .failure(let error):
                SVProgressHUD.showError(withStatus: error.localizedDescription)
            case .success(let data):
                self.data = data
                SVProgressHUD.dismiss()
                self.generateDataSource {
                    completion()
                }
            }
            
        }
        
    }
    
    func generateDataSource(completion: @escaping () -> ()) {
        
        var lastService: ServiceModel?
        
        var counter = -1
        
        for service in self.data {
            
            if (service.clickable == false) {
                
                lastService = service
                counter += 1
                self.tableSectionData.append(service.title_mobile)
                
            } else {
                
                guard let _lastService = lastService else { continue }
                
                if service.show_in_mobile == true {
                
                    guard let url = URL(string: service.webviewMobile ?? "") else { continue }
                    
                    let serviceAppend = (service.title_mobile, url)
                    
                    if self.tableData.has(key: counter) {
                    
                        self.tableData[counter]?.append(serviceAppend)
                        self.selectedArray[counter]?.append(service)
                    } else {
                        self.tableData[counter] = [serviceAppend]
                        self.selectedArray[counter] = [service]
                }
                }
            }
            
        }
        
        completion()
        
    }
    
}
