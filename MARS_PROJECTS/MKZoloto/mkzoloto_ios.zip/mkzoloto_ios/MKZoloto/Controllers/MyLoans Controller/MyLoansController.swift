//
//  PreviousItemsController.swift
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import UIKit
import RxSwift
import Alamofire
import SVProgressHUD

protocol LoanDelegate {
    var loans: [LoanModel] { get set }
}

class MyLoansViewController: UIViewController {
    
//    MARK: Properties
    var myLoansViewModel = MyLoansViewModel()
    
    var disposeBag = DisposeBag()
    
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .plain)
        tableView.register(cellWithClass: MyLoanTableViewCell.self)
        tableView.register(cellWithClass: UITableViewCell.self)
        tableView.register(cellWithClass: LoanTableViewCell.self)
        
        tableView.delegate = self
        tableView.dataSource = self
        
        tableView.separatorStyle = .none
        
        tableView.backgroundColor = Global.grey()
        
        tableView.estimatedRowHeight = StaticSize.s243
        
        return tableView
    }()
    
    lazy var orderButton: UIButton = {
        let button = UIButton(frame: CGRect(x: 0, y: 0, width: self.view.width * 0.914, height: 44))
        button.backgroundColor = Global.yellow()
        button.setTitle("Оплатить".localized(), for: .normal)
        button.setTitleColor(.black, for: .normal)
        button.titleLabel?.font = Global.sfSemiBold(size: 17)
        button.addTarget(self, action: #selector(orderLeans), for: .touchUpInside)
        button.cornerRadius = 4
        return button
    }()
    
//    MARK: Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViews()
        setupConstraints()
        navigationItem.title = "Мои займы".localized()
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.font: Global.sfMedium(size: StaticSize.s20)]
        myLoansViewModel.fetchLoans {
            self.loans = self.myLoansViewModel.data
            self.tableView.reloadData {
                self.tableView.reloadData()
                if (self.myLoansViewModel.data.count > 0) {
                    
                    let footerView = UIView(frame: CGRect.init(x: 0, y: 0, width: self.tableView.frame.width, height: 88))
                    footerView.addSubview(self.orderButton)
                    self.orderButton.frame.origin.y = 24
                    self.orderButton.frame.origin.x = 16
                    self.tableView.tableFooterView = footerView
                }
            }
            
        }
//        self.tableView.contentSize = CGSize(width: tableView.contentSize.width * 0.9, height: tableView.contentSize.height)
        
        setupRx()
        
        self.view.backgroundColor = Global.grey()
        
        self.tableView.contentInset = UIEdgeInsets(top: StaticSize.s8, left: 0, bottom: 0, right: 0)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tabBarController?.tabBar.isHidden = true
        
        self.tableView.reloadData()
        self.myLoansViewModel.calculateTotalPrice()
    }

    private func setupViews() {
        
        self.view.addSubviews([tableView])
        
    }
    
//    MARK: Constraints
    private func setupConstraints() {
        
        tableView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
    }
    
//    MARK: Targets
    @objc func activateLean(sender: UISwitch) {
        
        // TODO: Update moneys and table view
        self.myLoansViewModel.data[sender.tag].isCollapsed = sender.isOn
        
        if (self.myLoansViewModel.data[sender.tag].isCollapsed == true) {
            let price = try! self.myLoansViewModel.totalLoanPrice.value() + self.myLoansViewModel.data[sender.tag].defaultPay
            self.myLoansViewModel.totalLoanPrice.onNext(price)
        } else {
            let price = try! self.myLoansViewModel.totalLoanPrice.value() - self.myLoansViewModel.data[sender.tag].defaultPay
            self.myLoansViewModel.totalLoanPrice.onNext(price)
        }
        if let cell = self.tableView.cellForRow(at: IndexPath(item: 0, section: sender.tag)) as?  LoanTableViewCell {
            cell.configure(with: self.myLoansViewModel.data[sender.tag])
        }
        self.tableView.reloadSections(IndexSet(integer: sender.tag), with: .automatic)
//        self.tableView.reloadData()
        if self.myLoansViewModel.data.filter({ $0.isCollapsed }).count < 1 {
            self.orderButton.isEnabled = false
            self.orderButton.backgroundColor = Global.darkGray()
            self.orderButton.setTitle("Выберите залоговый билет", for: .normal)
        }
        
    }
    
    @objc func orderLeans() {
        
        let loanOrders = self.myLoansViewModel.data.filter({ $0.isCollapsed }).map({ LoanOrderModel(loanId: "\($0.loanId)", loanCount: "\($0.count == 0 ? $0.maxDaysExtension : $0.count)", operationType: $0.operationType ) })
        
        let loanOrderParameters = loanOrders.map({ ["loan_id" : $0.loanId, "count_days" : $0.loanCount, "operation_type" : $0.operationType] })
        
        let request = ApiRequests.generateLoansOrder(loans: loanOrderParameters)
        
        SVProgressHUD.show()
        NetworkManager.shared.makeRequest(apiRequest: request) { (result: Result<[LastOperationModel]>) in
            
            switch result {
            case .failure(let error):
                SVProgressHUD.showError(withStatus: error.localizedDescription)
            case .success(let data):
                SVProgressHUD.dismiss()
                let vc = OrderViewController()
                vc.data = data
                self.navigationController?.pushViewController(vc)
            }
            
        }
        
        
    }
    
    private func setupRx() {
        
        self.myLoansViewModel.totalLoanPrice.bind { (totalPrice) in            self.orderButton.setTitle("Оплатить".localized() + " \("\(Int(totalPrice) )".formatToNorm()) ₸", for: .normal)
            self.orderButton.backgroundColor = Global.yellow()
            self.orderButton.isEnabled = true
        }.disposed(by: self.disposeBag)
        
    }
    
}

extension MyLoansViewController: LoanDelegate {
    var loans: [LoanModel] {
        get {
            return self.myLoansViewModel.data
        }
        set {
            self.myLoansViewModel.data = newValue
        }
    }
    
    
}
