
import Foundation
import Alamofire
import SVProgressHUD
import RxSwift

class MyLoansViewModel {
    
    var data: [LoanModel] = [LoanModel]()
    
    var totalLoanPrice: BehaviorSubject<Double> = BehaviorSubject(value: 0)
    
    init() {}
    
    func fetchLoans(completion: @escaping () -> ()) {
        
        SVProgressHUD.show()
        NetworkManager.shared.makeRequest(apiRequest: .getMyLoans) { (result: Result<[LoanModel]>) in

            switch result {
            case .failure(let error):
                if let customError = error as? CustomError {
                    SVProgressHUD.showError(withStatus: customError.errorDescription)
                    SVProgressHUD.dismiss(withDelay: 1.5)
                } else {
                    SVProgressHUD.showError(withStatus: error.localizedDescription)
                    SVProgressHUD.dismiss(withDelay: 1.5)
                }
            case .success(let data):
                self.data = data
                self.calculateTotalPrice()
                SVProgressHUD.dismiss()
                completion()
            }

        }
        
    }
    
    public func calculateTotalPrice() {
        
        var totalPrice: Double = 0
        
        for loan in self.data {
            
            if (loan.isCollapsed == true) {
                
                totalPrice = totalPrice + loan.defaultPay
                
            }
            
        }
        
        self.totalLoanPrice.onNext(totalPrice)
        
    }
    
}
