//
//  PreviousItemDataSource.swift
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import UIKit

/**
 CountOfCellsInLoan
 */
enum CountOfCellsInLoan: Int {
    /// - expanded: This cell will display info about loan and payload and fully view
    case notExpanded = 4
    /// - notExpanded: This cell will display info about loan and only fully view
    case expanded = 5
}

//MARK: UITableViewDataSource functions
extension MyLoansViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.loans.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        if self.loans[section].isCollapsed == true {
//            return CountOfCellsInLoan.expanded.rawValue
//        } else {
//            return CountOfCellsInLoan.notExpanded.rawValue
//        }
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withClass: LoanTableViewCell.self, for: indexPath)
        
        cell.configure(with: self.loans[indexPath.section])
        
        let switcher = cell.switchButton
        switcher.tag = indexPath.section

        switcher.addTarget(self, action: #selector(activateLean(sender:)), for: .valueChanged)
        switcher.isOn = false
        if self.myLoansViewModel.data[indexPath.section].isCollapsed == true {
            switcher.isOn = true
        }

        cell.openChange = {
            
            let vc = FastExtensionDetailViewController()
            vc.isExpress = false
            vc.loadDelegate = self
            vc.index = indexPath.section
            let data = self.myLoansViewModel.data[indexPath.section]
            let expresData = ExpressProlongation(loanId: data.loanId, minRenewal: data.minDaysExtension, maxRenewal: data.maxDaysExtension, loanTerm: data.loanTerm)
            vc.data = expresData
            self.navigationController?.pushViewController(vc)
            
        }
        
        return cell
        
    }
    
}

//MARK: UITableViewDelegate functions
extension MyLoansViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if self.myLoansViewModel.data[indexPath.section].isCollapsed == false {
            return StaticSize.s200 + (StaticSize.s8 / 2)
        }
        return StaticSize.s242 + 10
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.row == 4 {
            let vc = FastExtensionDetailViewController()
            vc.isExpress = false
            vc.loadDelegate = self
            vc.index = indexPath.section
            let data = self.myLoansViewModel.data[indexPath.section]
            let expresData = ExpressProlongation(loanId: data.loanId, minRenewal: data.minDaysExtension, maxRenewal: data.maxDaysExtension, loanTerm: data.loanTerm)
            vc.data = expresData
            self.navigationController?.pushViewController(vc)
        } else if indexPath.row == 0 {

            let vc = TicketDetailViewController()
            let data = self.myLoansViewModel.data[indexPath.section]
            vc.loanData = data
            vc.title = "№\(data.loanId)"
            self.navigationController?.pushViewController(vc)
        }
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {

        
        if let cell = cell as? LoanTableViewCell {
            if cell.switchButton.isOn == true {
                
                cell.oplataLabel.isHidden = false
                cell.oplataBackground.isHidden = false
                cell.oplataDisclosure.isHidden = false
                cell.oplataPriceLabel.isHidden = false
                cell.borderView.isHidden = false
                cell.changeLabel.isHidden = false
            } else {
                cell.oplataLabel.isHidden = true
                cell.oplataBackground.isHidden = true
                cell.oplataDisclosure.isHidden = true
                cell.oplataPriceLabel.isHidden = true
                cell.borderView.isHidden = true
                cell.changeLabel.isHidden = true
            }
            
            if let index = cell.images.firstIndex(of: cell.selectedThumbImage) {
                
                if index == 0 {
                    cell.background.borderWidth = 1
                    cell.background.borderColor = UIColor(hexString: "#49D161")!
                } else if index == 3 {
                    cell.background.borderWidth = 1
                    cell.background.borderColor = UIColor(hexString: "#FF3B30") ?? .red
                } else {
                    cell.background.borderWidth = 0
                    cell.background.borderColor = .white
                }
                
            }
            
        }
        
    }
    
}

extension NSMutableAttributedString {
    
    func createAttributedString(word : NSArray, attributeCustomizeFont:UIFont, defaultFont : UIFont, defaultColor : UIColor, allowSpecing : Bool , allowUnderLine : Bool = false) -> NSAttributedString {
        
        self.addAttribute(NSAttributedString.Key.font, value: defaultFont, range: (self.string as NSString).range(of: self.string))
        if allowSpecing {
            self.addAttribute(NSAttributedString.Key.kern, value: NSNumber(value: 5), range: (self.string as NSString).range(of: self.string))
        }else {
            self.addAttribute(NSAttributedString.Key.kern, value: NSNumber(value: 0), range: (self.string as NSString).range(of: self.string))
        }
        
        self.addAttribute(NSAttributedString.Key.foregroundColor, value: defaultColor, range: (self.string as NSString).range(of: self.string))
        
        for i in 0..<word.count {
            self.addAttribute(NSAttributedString.Key.font, value: attributeCustomizeFont, range: (self.string as NSString).range(of: word.object(at: i) as! String))
            
        }
        if allowUnderLine {
            self.addAttribute(NSAttributedString.Key.underlineStyle, value: NSUnderlineStyle.single.rawValue, range: (self.string as NSString).range(of: self.string))
        }
        return self
    }
}
