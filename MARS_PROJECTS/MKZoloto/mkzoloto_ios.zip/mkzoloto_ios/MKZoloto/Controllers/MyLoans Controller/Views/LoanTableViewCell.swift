//
//  LoanTableViewCell.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 6/4/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import UIKit

class LoanTableViewCell: UITableViewCell {
    
    //    MARK: Properties
    var selectedThumbImage = #imageLiteral(resourceName: "Oval-1")
    
    var openChange = { () -> () in }
    
    var images: [UIImage] = [#imageLiteral(resourceName: "Oval-1"), #imageLiteral(resourceName: "Oval5"), #imageLiteral(resourceName: "Oval4"), #imageLiteral(resourceName: "Oval2")]
    
    lazy var background: UIView = {
        let view = UIView()
        view.cornerRadius = 5
        view.backgroundColor = .white
        return view
    }()
    
    var colors: [UIColor] = [UIColor(hexString: "#49D161")!, UIColor(hexString: "#FFEB02")!, UIColor(red: 253/255, green: 116/255, blue: 49/255, alpha: 1)]
    
    lazy var loanIdLabel: UILabel = {
        let label = UILabel()
        label.font = Global.sfRegular(size: StaticSize.s15)
        label.halfTextColorChange(fullText: "Залоговый билет №76543224561243235", changeText: String("76543224561243235".characters.suffix(8)))
        label.textColor = Global.dark()
        return label
    }()
    
    lazy var disclosureButton: UIImageView = {
        let imageView = UIImageView(image: #imageLiteral(resourceName: "Icon"))
        return imageView
    }()
    
    lazy var sliderBackgroundView: UIView = {
        let view = UIView()
        view.backgroundColor = Global.grey()
        view.cornerRadius = 2
        view.borderWidth = 1
        view.borderColor = UIColor.lightGray.withAlphaComponent(0.3)
        return view
    }()
    
    lazy var slider: UISlider = {
        let slider = UISlider()
        slider.isUserInteractionEnabled = false
        return slider
    }()
    
    lazy var sliderBeginImageView = UIImageView(image: #imageLiteral(resourceName: "Oval-1"))
    lazy var sliderEndImageView = UIImageView(image: #imageLiteral(resourceName: "Oval6"))
    
    lazy var srokImageView: UIImageView = {
        let imageView = UIImageView()
        return imageView
    }()
    
    lazy var srokLabel: UILabel = {
        let label = UILabel()
        label.textColor = Global.dark()
        label.text = "Гарантированный срок ожидания истек"
        label.font = Global.sfMedium(size: 12)
        return label
    }()
    
    lazy var srokDateLabel: UILabel = {
        let label = UILabel()
        label.textColor = Global.dark()
        label.text = "01.01.2019"
        label.font = Global.sfMedium(size: 15)
        return label
    }()
    
    lazy var ostatokSumLabel: UILabel = {
        let label = UILabel()
        label.textColor = Global.dark()
        label.text = "Гарантированный срок ожидания истек"
        label.font = Global.sfMedium(size: 12)
        return label
    }()
    
    lazy var ostatokDateLabel: UILabel = {
        let label = UILabel()
        label.textColor = Global.dark()
        label.text = "01.01.2019"
        label.font = Global.sfMedium(size: 15)
        return label
    }()
    
    lazy var percentLabel: UILabel = {
        let label = UILabel()
        label.textColor = Global.dark()
        label.text = "Гарантированный срок ожидания истек"
        label.font = Global.sfMedium(size: 12)
        return label
    }()
    
    lazy var percentDateLabel: UILabel = {
        let label = UILabel()
        label.textColor = Global.dark()
        label.text = "01.01.2019"
        label.font = Global.sfMedium(size: 15)
        return label
    }()
    
    lazy var borderView: UIView = {
        let view = UIView()
        view.backgroundColor = Global.darkGray()
        return view
    }()
    
    lazy var oplataBackground: UIView = {
        let view = UIView()
        view.backgroundColor = Global.gray()
        view.cornerRadius = 5
        if #available(iOS 11.0, *) {
            view.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        } else {
            
        }
        let gesture = UITapGestureRecognizer(target: self, action: #selector(openChangeController))
        view.isUserInteractionEnabled = true
        view.addGestureRecognizer(gesture)
        
        return view
    }()
    
    lazy var oplataLabel: UILabel = {
        let label = UILabel()
        label.textColor = Global.dark()
        label.text = "Гарантированный срок ожидания истек"
        label.font = Global.sfMedium(size: 12)
        return label
    }()
    
    lazy var oplataPriceLabel: UILabel = {
        let label = UILabel()
        label.textColor = Global.dark()
        label.text = "01.01.2019"
        label.font = Global.sfMedium(size: 15)
        return label
    }()
    
    lazy var changeLabel: UILabel = {
        let label = UILabel()
        label.textColor = Global.dark()
        label.text = "изменить".localized()
        label.font = Global.sfMedium(size: 15)
        label.sizeToFit()
        label.textAlignment = .right
        return label
    }()
    
    lazy var switchButton: UISwitch = {
        let switcher = UISwitch()
        return switcher
    }()
    
    lazy var oplataDisclosure: UIImageView = {
        let imageView = UIImageView(image: #imageLiteral(resourceName: "Icon"))
        return imageView
    }()
    
    //    MARK: Init
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        setupViews()
        setupConstraints()
        
        slider.addGradientTrack()
        
        slider.setThumbImage(images[0], for: .normal)
        
        background.setUpCellShadow()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    /// Adding views to super view
    private func setupViews() {
        
        self.addSubviews([background])
        background.addSubviews([loanIdLabel, disclosureButton, sliderBackgroundView, slider, sliderBeginImageView, sliderEndImageView, srokImageView, srokLabel, srokDateLabel, ostatokSumLabel, ostatokDateLabel, percentLabel, percentDateLabel, borderView, oplataBackground, switchButton])
        self.oplataBackground.addSubviews([oplataLabel, oplataPriceLabel, changeLabel, oplataDisclosure])
        self.backgroundColor = Global.grey()
        self.selectionStyle = .none
        
    }
    
    //    MARK: Constraints
    /// Setting constraints to views
    private func setupConstraints() {
        
        background.snp.makeConstraints { (make) in
            make.left.top.equalToSuperview().offset(StaticSize.s8)
            make.right.equalToSuperview().offset(-StaticSize.s8)
            make.bottom.equalToSuperview()
//            make.bottom.equalTo(oplataBackground)
            
        }
        
        loanIdLabel.snp.makeConstraints { (make) in
            make.left.top.equalToSuperview().offset(StaticSize.s16)
            make.right.equalToSuperview().offset(-StaticSize.s30)
            make.height.equalTo(StaticSize.s15)
        }
        
        disclosureButton.snp.makeConstraints { (make) in
            make.top.equalTo(loanIdLabel)
            make.size.equalTo(CGSize(width: StaticSize.s8, height: StaticSize.s12))
            make.right.equalToSuperview().offset(-StaticSize.s16)
        }
        
        sliderBackgroundView.snp.makeConstraints { (make) in
            make.left.equalTo(loanIdLabel)
            make.size.equalTo(CGSize(width: StaticSize.s200 + StaticSize.s8, height: StaticSize.s20))
            make.top.equalTo(loanIdLabel.snp.bottom).offset(StaticSize.s5)
        }
        
        sliderBeginImageView.snp.makeConstraints { (make) in
            make.left.equalTo(sliderBackgroundView).offset(StaticSize.s8 - 2)
            make.size.equalTo(CGSize(width: StaticSize.s10, height: StaticSize.s10))
            make.centerY.equalTo(sliderBackgroundView)
        }
        
        sliderEndImageView.snp.makeConstraints { (make) in
            make.right.equalTo(sliderBackgroundView).offset(-StaticSize.s8 + 2)
            make.size.equalTo(CGSize(width: StaticSize.s10, height: StaticSize.s10))
            make.centerY.equalTo(sliderBackgroundView)
        }
        
        slider.snp.makeConstraints { (make) in
            make.left.equalTo(sliderBackgroundView).offset(StaticSize.s8)
            make.top.equalTo(sliderBackgroundView).offset(StaticSize.s6 - 0.5)
            make.bottom.equalTo(sliderBackgroundView).offset(-StaticSize.s6 - 0.5)
            make.right.equalTo(sliderBackgroundView).offset(-StaticSize.s8)
        }
        
        srokImageView.snp.makeConstraints { (make) in
            make.left.equalTo(loanIdLabel)
            make.centerY.equalTo(srokLabel)
            make.size.equalTo(CGSize(width: StaticSize.s11, height: StaticSize.s11))
        }
        
        srokLabel.snp.makeConstraints { (make) in
            make.left.equalTo(srokImageView.snp.right).offset(StaticSize.s8)
            make.top.equalTo(sliderBackgroundView.snp.bottom).offset(StaticSize.s8)
            make.height.equalTo(StaticSize.s12)
            make.right.equalToSuperview().offset(-StaticSize.s30)
        }
        
        srokDateLabel.snp.makeConstraints { (make) in
            make.left.equalTo(loanIdLabel)
            make.top.equalTo(srokLabel.snp.bottom).offset(StaticSize.s6)
            make.height.equalTo(StaticSize.s15)
        }
        
        ostatokSumLabel.snp.makeConstraints { (make) in
            make.left.equalTo(loanIdLabel)
            make.top.equalTo(srokDateLabel.snp.bottom).offset(StaticSize.s11)
            make.height.equalTo(StaticSize.s12)
        }
        
        ostatokDateLabel.snp.makeConstraints { (make) in
            make.left.equalTo(loanIdLabel)
            make.top.equalTo(ostatokSumLabel.snp.bottom).offset(StaticSize.s6)
            make.height.equalTo(StaticSize.s15)
        }
        
        percentLabel.snp.makeConstraints { (make) in
            make.left.equalTo(loanIdLabel)
            make.top.equalTo(ostatokDateLabel.snp.bottom).offset(StaticSize.s11)
            make.height.equalTo(StaticSize.s12)
        }
        
        percentDateLabel.snp.makeConstraints { (make) in
            make.left.equalTo(loanIdLabel)
            make.top.equalTo(percentLabel.snp.bottom).offset(StaticSize.s6)
            make.height.equalTo(StaticSize.s15)
        }
        
        borderView.snp.makeConstraints { (make) in
            make.height.equalTo(1)
            make.left.right.equalToSuperview()
            make.top.equalTo(percentDateLabel.snp.bottom).offset(StaticSize.s11)
        }
    
        oplataBackground.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(borderView.snp.bottom)
            make.height.equalTo(StaticSize.s46)
        }
        
        oplataLabel.snp.makeConstraints { (make) in
            make.top.equalTo(borderView.snp.bottom).offset(StaticSize.s6)
            make.left.equalTo(loanIdLabel)
            make.height.equalTo(StaticSize.s14)
        }
        
        oplataPriceLabel.snp.makeConstraints { (make) in
            make.left.equalTo(loanIdLabel)
            make.top.equalTo(oplataLabel.snp.bottom).offset(StaticSize.s8 / 2)
            make.bottom.equalTo(oplataBackground).offset(-StaticSize.s6)
//            make.height.equalTo(StaticSize.s15)
        }
        
        changeLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(oplataBackground).offset(-2)
            make.right.equalTo(oplataDisclosure.snp.left).offset(-StaticSize.s8)
//            make.width.equalTo(StaticSize.s70)
        }
        
        oplataDisclosure.snp.makeConstraints { (make) in
            make.right.size.equalTo(disclosureButton)
            make.centerY.equalTo(oplataBackground)
        }
        
        switchButton.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-StaticSize.s16)
            make.top.equalToSuperview().offset(StaticSize.s80 + StaticSize.s6 / 3)
        }
        
    }
    
    //    MARK: Targets
    // Targets from buttons, gestures and other targets
    
    @objc private func openChangeController() {
        
        self.openChange()
        
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
    }
    
    //    MARK: Functions
    
//    Uncomment this lines for configuring cell with specific Model
    public func configure(with model: LoanModel) {
        
        self.loanIdLabel.halfTextColorChange(fullText: "Залоговый билет".localized() + " №\(model.loanId)", changeText: String(String(model.loanId).characters.suffix(8)))
        
        self.srokDateLabel.text = model.guarantyTime
        
        self.ostatokSumLabel.text = "Остаток суммы займа".localized()
        self.ostatokDateLabel.text = "\("\(model.loanBalance)".formatToNorm()) ₸"
        
        self.percentLabel.text = "Проценты к оплате".localized()
        self.percentDateLabel.text = "\("\(model.loanPercent)".formatToNorm()) ₸"
        
        self.oplataLabel.text = "Оплата за продление"
        self.oplataPriceLabel.text = "\("\(Int(model.defaultPay) ?? 0)".formatToNorm()) ₸"
        
        self.slider.minimumValue = Float(model.minDaysExtension)
        self.slider.maximumValue = Float(model.maxDaysExtension)
        
        self.switchButton.isOn = model.isCollapsed
        
        
        let overdueDay = (model.overdueDays)
        self.slider.setValue(Float(overdueDay), animated: false)
        
        
        if overdueDay <= Int(model.maxDaysExtension / 2) {
            self.selectedThumbImage = self.images[0]
            self.srokLabel.text = "Срок займа".localized()
            self.sliderEndImageView.isHidden = false
        } else if (overdueDay > Int(model.maxDaysExtension / 2) && overdueDay <= Int(model.maxDaysExtension * 3 / 4)) {
            self.selectedThumbImage = self.images[1]
            self.srokLabel.text = "Гарантированный срок ожидания".localized()
            self.sliderEndImageView.isHidden = false
        } else if (overdueDay != model.maxDaysExtension) {
            self.selectedThumbImage = self.images[2]
            self.srokLabel.text = "Гарантированный срок ожидания истекает".localized()
            self.sliderEndImageView.isHidden = false
        } else {
            self.selectedThumbImage = self.images[3]
            self.srokLabel.text = "Гарантированный срок ожидания истек".localized()
            self.srokLabel.textColor = UIColor(hexString: "#FF3B30") ?? .red
            self.srokDateLabel.textColor = UIColor(hexString: "#FF3B30") ?? .red
            self.sliderEndImageView.isHidden = true
        }
        
        if overdueDay <= Int(model.minDaysExtension) {
            self.sliderBeginImageView.isHidden = true
        } else {
            self.sliderBeginImageView.isHidden = false
        }
        
        if overdueDay <= Int(model.maxDaysExtension) {
            self.sliderEndImageView.isHidden = true
        } else {
            self.sliderEndImageView.isHidden = false
        }
        
        slider.setThumbImage(self.selectedThumbImage, for: .normal)
        srokImageView.image = self.selectedThumbImage
        
    }
    
}
