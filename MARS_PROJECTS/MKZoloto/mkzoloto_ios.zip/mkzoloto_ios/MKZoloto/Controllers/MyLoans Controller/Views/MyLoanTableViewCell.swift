//
//  PreviousItemCell.swift
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import UIKit

/**
 LoanInfoLabelType
 */
enum LoanInfoLabelType: Int {
    /// - loanNumber: Id of loan and state
    case loanNumber = 1
    /// - waitingPeriod: Waiting period of loan
    case waitingPeriod
    /// - loanBalance: Loan balance of loan
    case loanBalance
    /// - interestPayable: InterestPayable of loan
    case interestPayable
}

class MyLoanTableViewCell: UITableViewCell {
    
//    MARK: Properties
    var colors: [UIColor] = [UIColor(hexString: "#49D161")!, UIColor(hexString: "#FFEB02")!, UIColor(red: 253/255, green: 116/255, blue: 49/255, alpha: 1)]
    
    lazy var selectedColor = self.colors[0]
    
    lazy var label: UILabel = {
        let label = UILabel()
        label.font = Global.sfMedium(size: 15)
        return label
    }()
    
    lazy var sliderBeginImageView = UIImageView(image: self.colors[0].image(CGSize(width: 10, height: 10)).withRoundedCorners(radius: 5))
    lazy var sliderEndImageView = UIImageView(image: UIColor.lightGray.image(CGSize(width: 10, height: 10)).withRoundedCorners(radius: 5))
    
    lazy var sliderBackGround: UIView = {
        let view = UIView()
        view.backgroundColor = Global.grey()
        view.cornerRadius = 2
        view.borderWidth = 1
        view.borderColor = UIColor.lightGray.withAlphaComponent(0.3)
        return view
    }()
    
    lazy var slider: UISlider = {
        let slider = UISlider()
        slider.cornerRadius = 5
        slider.isUserInteractionEnabled = false
        return slider
    }()
    
    lazy var switchButton: UIImageView = {
        let switchButton = UIImageView(image: #imageLiteral(resourceName: "Icon"))
        return switchButton
    }()
    
//    MARK: Init
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        setupViews()
        setupConstraints()
        
        
        backgroundColor = Global.white()
        self.selectionStyle = .none
        
        slider.addGradientTrack()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        
        self.accessoryView = switchButton
        self.addSubviews([sliderBackGround, sliderEndImageView, slider, sliderBeginImageView, label])
    
    }
    
    private func getAttributedString(text: String, labelType: LoanInfoLabelType) -> NSAttributedString {
        
        return NSAttributedString(string: text, attributes: [kCTParagraphStyleAttributeName as NSAttributedString.Key: getParagraphStyle(type: labelType)])
        
    }
    
//    MARK: Constraints
    private func setupConstraints() {
        
        label.snp.makeConstraints({ (make) in
            make.top.left.equalToSuperview().offset(StaticSize.s16)
            make.height.equalTo(StaticSize.s16)
            make.right.equalToSuperview()
        })
        
        sliderBackGround.snp.makeConstraints { (make) in
            make.left.equalTo(self.label)
            make.top.equalTo(self.label.snp.bottom).offset(5)
            make.width.equalTo(StaticSize.s200)
            make.height.equalTo(20)
        }
        
        sliderBeginImageView.snp.makeConstraints { (make) in
            make.left.equalTo(sliderBackGround).offset(6)
            make.centerY.equalTo(slider).offset(1)
        }
        
        sliderEndImageView.snp.makeConstraints { (make) in
            make.right.equalTo(sliderBackGround).offset(-6)
            make.centerY.equalTo(slider).offset(1)
        }
        
        slider.snp.makeConstraints { (make) in
            make.left.equalTo(sliderBackGround).offset(8)
            make.right.equalTo(sliderBackGround).offset(-8)
            make.top.equalTo(sliderBackGround).offset(4)
            make.bottom.equalTo(sliderBackGround).offset(-4)
        }
        
    }
    
//    MARK: Cell configuration function
    public func configure(with model: LoanModel) {
        
        self.label.text = "Заем".localized() + " №\(model.loanId)"
        
        self.slider.minimumValue = Float(model.minDaysExtension)
        self.slider.maximumValue = Float(model.maxDaysExtension)
        
        self.slider.setValue(Float(model.overdueDays))
        
        if model.overdueDays <= Int(model.maxDaysExtension / 2) {
            self.selectedColor = self.colors[0]
        } else if (model.overdueDays > Int(model.maxDaysExtension / 2) && model.overdueDays <= Int(model.maxDaysExtension * 3 / 4)) {
            self.selectedColor = self.colors[1]
        } else if (model.overdueDays != model.maxDaysExtension) {
            self.selectedColor = self.colors[2]
        } else {
            self.selectedColor = .red
        }
        
        var image = self.selectedColor.image(CGSize(width: 10, height: 10))
        image = image.withRoundedCorners() ?? UIImage()
        slider.setThumbImage(image, for: .normal)
        
    }
    
//    MARK: Functions
    
    private func getParagraphStyle(type: LoanInfoLabelType) -> NSMutableParagraphStyle {
        
        var indent = 150
        
        switch type {
        case .waitingPeriod:
            indent += 50
        case .loanBalance:
            indent += 60
        case .interestPayable:
            indent += 60
        default:
            break
        }
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.tabStops = [NSTextTab(textAlignment: NSTextAlignment.left, location: CGFloat(indent), options: [:])]
        paragraphStyle.headIndent = CGFloat(indent)
        
        return paragraphStyle
    }
    
    private func getStackView(axis: NSLayoutConstraint.Axis, distribution: UIStackView.Distribution) -> UIStackView {
        
        let stackView = UIStackView()
        stackView.distribution = distribution
        stackView.axis = axis
        
        return stackView
    }
    
    private func getLabels(numberOfLabels: Int, font: UIFont) -> [UILabel] {
        
        var labels = [UILabel]()
        
        for i in 1...numberOfLabels {
            
            let label = UILabel()
            label.tag = i
            label.font = font
            labels.append(label)
        }
        
        return labels
        
    }
    
}

extension UISlider {
    
    func addGradientTrack() {
        superview?.layoutIfNeeded()
        setMaximumTrackImage(imageForColors(colors: [UIColor.white.cgColor, UIColor.white.cgColor], offset: 0), for: .normal)
        setMinimumTrackImage(imageForColors(colors: [
                UIColor(hexString: "#49D161")!.cgColor,
                UIColor(hexString: "#49D161")!.cgColor,
                UIColor(hexString: "#49D161")!.cgColor,
                UIColor(hexString: "#49D161")!.cgColor,
                UIColor(hexString: "#FFF200")!.cgColor,
                UIColor(hexString: "#FFF200")!.cgColor,
                UIColor(hexString: "#FFEB02")!.cgColor,
                UIColor(hexString: "#FF3B30")!.cgColor
            ]), for: .normal)
    }
    
    func imageForColors(colors: [CGColor], offset: CGFloat = 0.0) -> UIImage? {
        let layer = CAGradientLayer()
        layer.frame = CGRect(x: bounds.minX, y: bounds.minY - 2, width: bounds.width - offset, height: 8)
        layer.colors = colors
        layer.endPoint = CGPoint(x: 1.0, y:  1.0)
        layer.startPoint = CGPoint(x: 0.0, y:  1.0)
        
        UIGraphicsBeginImageContextWithOptions(layer.frame.size, false, 0.0)
        layer.render(in: UIGraphicsGetCurrentContext()!)
        let layerImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return layerImage?.resizableImage(withCapInsets: .zero)
    }
    
}

extension UIColor {
    func image(_ size: CGSize = CGSize(width: 1, height: 1)) -> UIImage {
        return UIGraphicsImageRenderer(size: size).image { rendererContext in
            self.setFill()
            rendererContext.fill(CGRect(origin: .zero, size: size))
        }
    }
}


extension CALayer {
    func addGradientBorder(colors:[UIColor],width:CGFloat = 1) {
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame =  CGRect(origin: CGPoint.zero, size: self.bounds.size)
        gradientLayer.startPoint = CGPoint(x:0.0, y:0.0)
        gradientLayer.endPoint = CGPoint(x:1.0,y:1.0)
        gradientLayer.colors = colors.map({$0.cgColor})
        
        let shapeLayer = CAShapeLayer()
        shapeLayer.lineWidth = width
        shapeLayer.path = UIBezierPath(rect: self.bounds).cgPath
        shapeLayer.fillColor = nil
        shapeLayer.strokeColor = UIColor.red.cgColor
        gradientLayer.mask = shapeLayer
        
        self.addSublayer(gradientLayer)
    }
}
