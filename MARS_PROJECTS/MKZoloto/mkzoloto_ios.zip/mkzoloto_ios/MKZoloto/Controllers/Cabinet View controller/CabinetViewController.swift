
import UIKit
import Alamofire
import SVProgressHUD

class CabinetViewController: UIViewController {
    
    private var titleArray = ["Мои займы".localized(), "Экспресс продление".localized(), "Оценка моего капитала".localized(), "Мои последние операции".localized(), "История уведомлений".localized(), "Личные данные".localized()]
    
    private lazy var profileController: UINavigationController = {
        var cabinet: UIViewController = AuthorizationViewController()
        cabinet.tabBarItem = UITabBarItem(title: "Кабинет".localized(), image: UIImage(named: "Profile")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal), selectedImage: UIImage(named: "ProfileS")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal))
        let nvController = NavigationController(rootViewController: cabinet)
        return nvController
    }()
    
    private lazy var menuTableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate   = self
        tableView.dataSource = self
        tableView.isScrollEnabled = false
        
        var frame = CGRect.zero
        frame.size.height = .leastNormalMagnitude
        tableView.tableHeaderView = UIView(frame: frame)
        
        tableView.register(ServicesTableViewCell.self, forCellReuseIdentifier: "cell")
        tableView.backgroundColor = Global.grey()
        tableView.separatorStyle = .none
        return tableView
    }()
    
    private lazy var button: UIButton = {
        let button = UIButton()
        button.setTitle("Выйти".localized(), for: UIControl.State.normal)
        button.layer.cornerRadius = 4
        button.backgroundColor    = Global.red()
        button.setTitleColor(Global.white(), for: UIControl.State.normal)
        button.titleLabel?.font = Global.sfSemiBold(size: StaticSize.s17)
        button.addTarget(self, action: #selector(logout), for: UIControl.Event.touchUpInside)
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addSubview(menuTableView)
        self.view.insertSubview(button, aboveSubview: menuTableView)
        setupConstraints()
        self.navigationController?.setUpShadow()
        navigationItem.title = "Кабинет".localized()
        let button1 = UIButton(frame: CGRect(x: 0, y: 0, width: StaticSize.s20, height: StaticSize.s22 - 1))
        button1.setImage(UIImage(named: "Settings"), for: UIControl.State.normal)
        button1.addTarget(self, action: #selector(openSettings), for: UIControl.Event.touchUpInside)
        let bar = UIBarButtonItem(customView: button1)
        navigationItem.rightBarButtonItem = bar
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tabBarController?.tabBar.isHidden = false
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.font: Global.stroke(size: StaticSize.s17)]
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        self.firstLaunch()
    }
    
}


extension CabinetViewController {
    
    private func firstLaunch() {
        
        if StoreManager.shared().isFirstLaunch() == false {
            
            let alert = UIAlertController(title: "Touch ID", message: "Would you like use Touch/Face ID?", preferredStyle: UIAlertController.Style.alert)
            
            alert.addAction(UIAlertAction(title: "Yes", style: UIAlertAction.Style.default, handler: { aaction in
                StoreManager.shared().setTouchIdUsable(isUsable: true)
                StoreManager.shared().setFirsiLaunch()
            }))
            
            alert.addAction(UIAlertAction(title: "No", style: UIAlertAction.Style.cancel, handler: { action in
                StoreManager.shared().setTouchIdUsable(isUsable: false)
                StoreManager.shared().setFirsiLaunch()
            }))
            
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    @objc private func logout() {
        let request = ApiRequests.logout
        
        SVProgressHUD.show()
        NetworkManager.shared.makeRequest(apiRequest: request) { (result: Result<EmptyModel>) in
            
            switch result {
            case .failure(let error):
                if let customError = error as? CustomError {
                    SVProgressHUD.showError(withStatus: customError.errorDescription)
                } else {
                    SVProgressHUD.showError(withStatus: error.localizedDescription)
                }
            case .success(let data):
                SVProgressHUD.dismiss()
                DispatchQueue.main.async {
                    guard let tabBarVC = self.tabBarController as? TabBarViewController else {
                        return
                    }
                    StoreManager.shared().setIsAuth(bool: false)
                    tabBarVC.viewControllers?[2] = self.profileController
                }
            }
        }
    }
    
    @objc private func openSettings() {
        let vc = SettingsViewController()
        navigationController?.pushViewController(vc, animated: true)
    }
    
    private func setupConstraints() {
        menuTableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        button.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(self.view.safeAreaLayoutGuide).offset(-StaticSize.s16)
            } else {
                make.bottom.equalTo(self.view.snp.bottom).offset(-StaticSize.s16)
            }
            make.left.equalTo(self.view.snp.left).offset(StaticSize.s16)
            make.right.equalTo(self.view.snp.right).offset(-StaticSize.s16)
            make.height.equalTo(StaticSize.s44)
        }
        
    }
    
}

extension CabinetViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        tableView.deselectRow(at: indexPath, animated: true)
        switch indexPath.row {
        case 0:
            let vc = MyLoansViewController()
            self.navigationController?.pushViewController(vc, animated: true)
        case 1:
            let vc = FastExtensionViewController()
            self.navigationController?.pushViewController(vc)
        case 2:
            let vc = OcenkaKapitalaViewController()
            self.navigationController?.pushViewController(vc, animated: true)
        case 3:
            let vc = LastOperationViewController()
            self.navigationController?.pushViewController(vc, animated: true)
        case 4:
            let vc = PushHistoryViewController()
            self.navigationController?.pushViewController(vc, animated: true)
        case 5:
            let vc = PersonalInfoViewController()
            self.navigationController?.pushViewController(vc, animated: true)
        default:
            break
        }
        
    }
    
}

extension CabinetViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ServicesTableViewCell
        cell.setUpDetails(image: "Icon", title: titleArray[indexPath.row])
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titleArray.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
}
