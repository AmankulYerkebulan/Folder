
import UIKit

class CabinetSettingViewController: UIViewController {
    
//    MARK: Properties
    
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(cellWithClass: UITableViewCell.self)
        return tableView
    }()
    
//    MARK: Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
    
        setupViews()
        setupConstraints()
        
        navigationItem.title = "Настройка кабинета".localized()
    }
    
    private func setupViews() {
        
        self.view.addSubviews([tableView])
        
    }
    
//    MARK: Constraints
    private func setupConstraints() {
        
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
    }
    
}

extension CabinetSettingViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 2
        } else {
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withClass: UITableViewCell.self, for: indexPath)
        
        cell.textLabel?.text = "Изменить номер телефона".localized()
        
        if indexPath.section == 1 {
            cell.accessoryView = UISwitch()
        } else {
            cell.accessoryType = .disclosureIndicator
        }
        return cell
    }
    
}
