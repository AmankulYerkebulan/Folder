
import UIKit
import SVProgressHUD
import Alamofire

enum ChangeInfoType {
    case phone
    case email
}

class ChangeInfoViewController: UIViewController {
    
    //    MARK: Properties
    var changeType = ChangeInfoType.email
    
    lazy var tableView: SelfSizedTableView = {
        let tableView = SelfSizedTableView()
        
        tableView.register(cellWithClass: TextFieldCell.self)
        
        tableView.delegate = self
        tableView.dataSource = self
        
        tableView.separatorStyle = .none
        
        tableView.cornerRadius = 5
        tableView.backgroundColor = .white
        
        return tableView
    }()
    
    lazy var saveButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = .yellowColor
        button.setTitleColor(.black, for: .normal)
        button.setTitle("Сохранить".localized(), for: .normal)
        button.cornerRadius = 4
        button.addTarget(self, action: #selector(changeProfileInfo), for: .touchUpInside)
        return button
    }()
    
    //    MARK: Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViews()
        setupConstraints()
        prepareSuperViewStyle()
        
    }
    
    /// Adding views to super view
    private func setupViews() {
        
        view.addSubviews([tableView, saveButton])
        
    }
    
    /// Seting super view style if needed or navigation style
    private func prepareSuperViewStyle() {
        
        view.backgroundColor = .grayBackgroundColor
        
    }
    
    //    MARK: Constraints
    /// Setting constraints to views
    private func setupConstraints() {
        
        tableView.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.left.top.equalTo(self.view.safeAreaLayoutGuide).offset(16)
            } else {
                 make.left.top.equalTo(self.view).offset(16)
            }
            if #available(iOS 11.0, *) {
                make.right.equalTo(self.view.safeAreaLayoutGuide).offset(-16)
            } else {
                make.right.equalTo(self.view).offset(-16)
            }
        }
        
        saveButton.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.bottom.right.equalTo(self.view.safeAreaLayoutGuide).offset(-16)
            } else {
                make.bottom.right.equalTo(self.view).offset(-16)
            }
            if #available(iOS 11.0, *) {
                make.left.equalTo(self.view.safeAreaLayoutGuide).offset(16)
            } else {
                make.left.equalTo(self.view.snp.left).offset(16)
            }
            make.height.equalTo(44)
        }
        
    }
    
    //    MARK: Targets
    // Targets from buttons, gestures and other targets
    @objc private func changeProfileInfo() {
        
        var request = ApiRequests.getBanners
        
        switch changeType {
        case .email:
            
            if let cell = self.tableView.visibleCells.first as? TextFieldCell {
                if (cell.textField.isEmpty) {
                    SVProgressHUD.showError(withStatus: "Пожалуйста заполните email".localized())
                    return
                }
                if (!(cell.textField.text?.isValidEmail ?? false)) {
                    SVProgressHUD.showError(withStatus: "Не правильный email адрес".localized())
                    return
                }
                
                request = ApiRequests.changeEmail(email: cell.textField.text ?? "")
            }
            break
        case .phone:
            if let cell = self.tableView.visibleCells.first as? TextFieldCell {
                if (cell.textField.isEmpty) {
                    SVProgressHUD.showError(withStatus: "Пожалуйста заполните номер телефона".localized())
                    return
                }
                if (cell.textField.text?.count != 18) {
                    SVProgressHUD.showError(withStatus: "Не правильный номер телефона".localized())
                    return
                }
                
                request = ApiRequests.changePhoneNumber(phone: cell.textField.text ?? "")
                
            }
        }
        
        SVProgressHUD.show()
        
        NetworkManager.shared.makeRequest(apiRequest: request) { (result: Result<String>) in
            
            switch result {
            case .failure(let error):
                SVProgressHUD.showError(withStatus: error.localizedDescription)
                /// Remove
                if let customError = error as? CustomError {
                
                    /// Remove
                    if customError.errorDescription == "Смс не отправлена".localized() {
                        let vc = SMSCodeVerificationViewController()
                        let cell = self.tableView.visibleCells.first as? TextFieldCell
                        vc.phone = cell?.textField.text ?? ""
                        vc.navTitle = "Изменение телефона".localized()
                        self.navigationController?.pushViewController(vc, animated: true)
                    } else {
                        SVProgressHUD.showError(withStatus: customError.errorDescription)
                    }
                    
                } else {
                    SVProgressHUD.showError(withStatus: error.localizedDescription)
                }
            case .success(let data):
                SVProgressHUD.showSuccess(withStatus: data)
            }
            
        }
        
    }
    
    //    MARK: Functions
    
    
}

/// UITable view data source functions
extension ChangeInfoViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withClass: TextFieldCell.self, for: indexPath)
        
        switch changeType {
        case .email:
            cell.textField.placeholder = "E-mail"
            cell.textField.keyboardType = .emailAddress
        case .phone:
            cell.textField.placeholder = "Телефон".localized()
            cell.textField.keyboardType = .phonePad
            cell.textField.setFormatting("+#-(###)-###-##-##", replacementChar: "#")
        }
        
        return cell
    }
    
}

/// UITableView delegate functions
extension ChangeInfoViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
}
