
import UIKit
import Alamofire
import SVProgressHUD

class FeedbackViewController: UIViewController, UITextFieldDelegate {
    
    lazy var tableView: UITableView = {
        let tableView = UITableView()
        tableView.register(QustionsCell.self, forCellReuseIdentifier: "QustionsCell")
        tableView.register(cellWithClass: FeedbackTableCell.self)
        tableView.separatorStyle = .none
        tableView.delegate      = self
        tableView.dataSource    = self
        tableView.backgroundColor = Global.grey()
        tableView.showsVerticalScrollIndicator = false
        return tableView
    }()
    
    lazy var feedbackCell: FeedbackTableCell = {
        let cell = FeedbackTableCell()
        cell.sendButton.addTarget(self, action: #selector(sendFeedback), for: .touchUpInside)
        cell.backgroundColor = Global.white()
        return cell
    }()
    
    lazy var textView: UITextView = {
        let tView = UITextView()
        tView.font = UIFont(name: "AvenirNext-Medium", size: 15)
        tView.isScrollEnabled = true
        tView.isUserInteractionEnabled = true
        tView.sizeToFit()
        tView.layer.borderWidth = 1.0
        
        tView.layer.borderColor = UIColor.blue.cgColor
        tView.layer.cornerRadius = 4
        return tView
    }()
    
    lazy var sendButton : UIButton = {
        let button = UIButton()
        button.yellowBtnProperty()
        button.setTitle("Отправить".localized(), for: UIControl.State.normal)
        button.addTarget(self, action: #selector(sendFeedback), for: .touchUpInside)
        return button
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(hex: 0xE4F1FD)
        setupButtons()
        setupConstraints()
        
        self.hideKeyboard()
        
        navigationItem.title = "ПООБЩАЕМСЯ?".localized().uppercased()
        self.navigationController?.setUpShadow()
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        guard let text = textField.text else { return true }
        let newLength = text.count + string.count - range.length
        return newLength <= 50 // Bool
    }
    
    @objc func sendFeedback() {
        
        var phoneFilled = false
        var emailFilled = false
        var textFilled  = false
        
        guard let name = feedbackCell.obrashenieTField.text, name != "" else {
            let alert = UIAlertController(title: "Пожалуйста заполните поле как к тебе обращаться".localized())
            self.present(alert, animated: true, completion: nil)
            return
        }
        
        if (feedbackCell.zvonokTField.isEmpty) {
            
        } else if (feedbackCell.zvonokTField.text.count != 18) {
            let alert = UIAlertController(title: "Номер телефона не правильный. Пожалуйста исправте номер телефона".localized())
            self.present(alert, animated: true, completion: nil)
            
            return
        } else {
            phoneFilled = true
        }
        
        let email = feedbackCell.napisatTField.text
        
        if (!(email?.isEmpty ?? true)) {
            if (!(email?.isValidEmail ?? true)) {
                let alert = UIAlertController(title: "Пожалуйста введите Email который действителен".localized())
                self.present(alert, animated: true, completion: nil)
                
                return
            } else {
                emailFilled = true
            }
        }
        
        if emailFilled {
            if feedbackCell.textView.text.isEmpty {
                let alert = UIAlertController(title: "Пожалуйста напишите текст обращение".localized())
                self.present(alert, animated: true, completion: nil)
            } else {
                textFilled = true
            }
        }
        
        if !phoneFilled {
            if !(emailFilled && textFilled) {
                let alert = UIAlertController(title: "Пожалуйста заполните номер телефона или email адрес".localized())
                self.present(alert, animated: true, completion: nil)
                
                return
            }
        }
        
        
        if phoneFilled || (emailFilled && textFilled) {
        
            let request = ApiRequests.sendFeedback(name: name , phone: feedbackCell.zvonokTField.text, email: email ?? "", text: feedbackCell.textView.text ?? "")
            
            SVProgressHUD.show()
            
            NetworkManager.shared.makeRequest(apiRequest: request) { (result: Result<String>) in
                
                switch result {
                    
                case .failure(let error):
                    SVProgressHUD.showError(withStatus: error.localizedDescription)
                case .success(let data):
                    SVProgressHUD.showSuccess(withStatus: data)
                    self.clearFeedback()
                }
                
            }
        }
        
    }
    
    private func clearFeedback() {
        
        feedbackCell.napisatTField.text = ""
        feedbackCell.obrashenieTField.text = ""
        feedbackCell.zvonokTField.text = ""
        feedbackCell.textView.text = ""
        feedbackCell.placeholder.isHidden = false
        
    }
    
    
}


extension FeedbackViewController {
    
    func setupButtons() {
        self.view.addSubview(tableView)
    }
    
    func setupConstraints() {
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
}


extension FeedbackViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.section {
        case 0:
            let cell = tableView.dequeueReusableCell(withIdentifier: "QustionsCell", for: indexPath) as! QustionsCell
            return cell
        case 1:
            return feedbackCell
        default:
            let cell = UITableViewCell(style: .value1, reuseIdentifier: String(describing: UITableViewCell.self))
            cell.accessoryType = .disclosureIndicator
            cell.selectionStyle = .none
            return cell
        }
    }
    
}


extension FeedbackViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        guard let headerView = view as? UITableViewHeaderFooterView else { return }
        
        headerView.textLabel?.font = UIFont.systemFont(ofSize: 13)
        headerView.backgroundColor = UIColor(hexString: "#E4F1FD")
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 0 {
            let vc = FrequentlyQuestionsViewController()
            navigationController?.pushViewController(vc)
        }
    }
    
}
