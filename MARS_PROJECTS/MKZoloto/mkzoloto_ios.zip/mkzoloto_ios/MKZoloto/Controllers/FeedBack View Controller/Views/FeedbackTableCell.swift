
import UIKit
import RxSwift
import RxAtomic
import Alamofire
import SVProgressHUD

class FeedbackTableCell: UITableViewCell,UITextViewDelegate {

    lazy var nameGeneratorBtn : UIButton = {
        let button = UIButton()
        
        let attr = NSMutableAttributedString(string: "Возьми себе прозвище".localized())
        attr.addAttribute(.underlineStyle, value: NSUnderlineStyle.single.rawValue, range: NSMakeRange(0, attr.length))
        
        button.setAttributedTitle(attr, for: .normal)
        button.setTitleColor(Global.dark(), for: .normal)
        button.titleLabel?.font = Global.sfRegular(size: StaticSize.s12)
        button.addTarget(self, action: #selector(generateName), for: .touchUpInside)
        return button
    }()
    
    lazy var obrashenieTField: UITextField = {
        let textField = UITextField()
        textField.borderWidth = 1
        textField.borderColor = Global.textFiledBorderColor()
        textField.cornerRadius = 4
        textField.backgroundColor = Global.grey()
        textField.setPlaceHolderTextColor(Global.dark())
        textField.attributedPlaceholder = NSAttributedString(string: "Как к тебе обращаться?".localized(),
                                                             attributes: [NSAttributedString.Key.foregroundColor: Global.dark()])
        textField.font = Global.sfMedium(size: StaticSize.s15)
        textField.addPaddingLeft(16)
        return textField
    }()
    
    lazy var zvonokTField: VSTextField = {
        let textField = VSTextField()
        textField.borderWidth = 1
        textField.borderColor = Global.textFiledBorderColor()
        textField.cornerRadius = 4
        textField.backgroundColor = Global.grey()
        textField.font = Global.sfMedium(size: StaticSize.s15)
        textField.setPlaceHolderTextColor(Global.dark())
        textField.attributedPlaceholder = NSAttributedString(string: "Куда тебе позвонить?".localized(),
                                                             attributes: [NSAttributedString.Key.foregroundColor: Global.dark()])
        textField.keyboardType = .phonePad
        textField.setFormatting("+#-(###)-###-##-##", replacementChar: "#")
        textField.addPaddingLeft(16)
        return textField
    }()
    
    lazy var napisatTField: UITextField = {
        let textField = UITextField()
        textField.borderWidth = 1
        textField.borderColor = Global.textFiledBorderColor()
        textField.cornerRadius = 4
        textField.backgroundColor = Global.grey()
        textField.attributedPlaceholder = NSAttributedString(string: "Куда тебе написать?".localized(),
                                                   attributes: [NSAttributedString.Key.foregroundColor: Global.dark()])
        textField.font = Global.sfMedium(size: StaticSize.s15)
        textField.addPaddingLeft(16)
        textField.keyboardType = .emailAddress
        return textField
    }()
    
    lazy var textView: UITextView = {
        let tView = UITextView()
        tView.isScrollEnabled = true
        tView.isUserInteractionEnabled = true
        tView.sizeToFit()
        tView.font = Global.sfMedium(size: StaticSize.s15)
        tView.borderWidth = 1
        tView.borderColor = Global.textFiledBorderColor()
        tView.cornerRadius = 4
        tView.backgroundColor = Global.grey()
        tView.layer.sublayerTransform = CATransform3DMakeTranslation(10, 4, 0)
        tView.delegate = self
        return tView
    }()
    
    lazy var placeholder: UILabel = {
        let label = UILabel()
        label.font = Global.sfMedium(size: StaticSize.s15)
        label.textColor = Global.dark()
        label.text = "Текст сообщения".localized()
        return label
    }()
    
    lazy var sendButton : UIButton = {
        let button = UIButton()
        button.yellowBtnProperty()
        button.setTitle("Отправить".localized(), for: UIControl.State.normal)
        return button
    }()
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
        setupConstraints()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        self.selectionStyle = .none
        self.textView.addSubview(placeholder)
        self.addSubviews([nameGeneratorBtn, obrashenieTField, napisatTField, zvonokTField, textView, sendButton])
    }
    
    func textViewDidChange(_ textView: UITextView) {
        placeholder.isHidden = !textView.text.isEmpty
    }
    
    private func setupConstraints() {
        
        placeholder.snp.makeConstraints { (placeholder) in
            placeholder.left.equalToSuperview().offset(6)
            placeholder.top.equalToSuperview().offset(8)
        }
        
        nameGeneratorBtn.snp.makeConstraints { (make) in
            make.top.equalTo(obrashenieTField.snp.bottom).offset(8)
            make.right.equalToSuperview().offset(-16)
            make.height.equalTo(24)
        }
        
        obrashenieTField.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(16)
            make.right.equalToSuperview().offset(-16)
            make.height.equalTo(44)
            make.top.equalToSuperview().offset(16)
        }
        
        zvonokTField.snp.makeConstraints { (make) in
            make.left.right.height.equalTo(obrashenieTField)
            make.top.equalTo(nameGeneratorBtn.snp.bottom).offset(16)
        }
        
        napisatTField.snp.makeConstraints { (make) in
            make.left.right.height.equalTo(obrashenieTField)
            make.top.equalTo(zvonokTField.snp.bottom).offset(8)
        }
        
        textView.snp.makeConstraints { (make) in
            make.top.equalTo(napisatTField.snp.bottom).offset(8)
            make.left.equalToSuperview().offset(16)
            make.right.equalToSuperview().offset(-16)
            make.height.equalTo(160)
        }
        
        sendButton.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(16)
            make.right.equalToSuperview().offset(-16)
            make.height.equalTo(44)
            make.top.equalTo(textView.snp.bottom).offset(16)
            make.bottom.equalToSuperview().offset(-16)
        }
    }
    
    
    
    @objc private func generateName() {
        
        SVProgressHUD.show()
        NetworkManager.shared.makeRequest(apiRequest: .getRandomName) { (result: Result<String>) in
            
            switch result {
                
            case .failure(let error):
                SVProgressHUD.showError(withStatus: error.localizedDescription)
            case .success(let data):
                SVProgressHUD.dismiss()
                self.obrashenieTField.text = data
                
            }
            
        }
        
    }
    
}
