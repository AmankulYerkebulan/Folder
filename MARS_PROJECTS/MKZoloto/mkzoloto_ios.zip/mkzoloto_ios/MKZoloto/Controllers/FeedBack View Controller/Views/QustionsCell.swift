
import UIKit
import RxSwift
import RxAtomic
import Alamofire
import SVProgressHUD

class QustionsCell: UITableViewCell {
    
    private lazy var placeholder: UILabel = {
        let label = UILabel()
        label.font = Global.sfRegular(size: StaticSize.s14)
        label.textColor = Global.dark()
        let attributes = [NSAttributedString.Key.font: Global.stroke(size: StaticSize.s17)]
        let fullString = NSMutableAttributedString(string: "  ", attributes: attributes)
        let image1Attachment = NSTextAttachment()
        image1Attachment.image = UIImage(named: "question")!
        image1Attachment.bounds = CGRect(x: 0, y: -(StaticSize.s8 - 3), width: StaticSize.s20, height: StaticSize.s20)
        let image1String = NSAttributedString(attachment: image1Attachment)
        fullString.append(image1String)
        let text = NSAttributedString(string: "  " + "Часто задаваемые вопросы".localized().uppercased(), attributes: [ NSAttributedString.Key.font: Global.stroke(size: StaticSize.s14)])
        fullString.append(text)
        
        label.attributedText = fullString
        label.numberOfLines = 1
        return label
    }()
    
    lazy var button: UIButton = {
        let button = UIButton()
        button.setImage(#imageLiteral(resourceName: "Icon"), for: UIControl.State.normal)
        return button
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
        setupConstraints()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        
        contentView.cornerRadius = 5
        if ScreenSize.SCREEN_WIDTH - 32 < contentView.frame.size.width {
            contentView.frame = contentView.frame.inset(by: UIEdgeInsets(top: 16, left: 16, bottom: 16, right: 16))
        }
    }
    
    
    private func setupViews() {
        
        contentView.backgroundColor = Global.white()
        self.contentView.addSubview(placeholder)
        self.contentView.addSubview(button)
        self.backgroundColor = Global.grey()
        self.selectionStyle = .none
    }
    
    private func setupConstraints() {
        
        placeholder.snp.makeConstraints { (placeholder) in
            placeholder.left.equalToSuperview()
            placeholder.right.equalToSuperview()
            placeholder.height.equalTo(55)
            placeholder.bottom.equalToSuperview().offset(-8)
            placeholder.top.equalToSuperview().offset(8)
        }
        
        button.snp.makeConstraints { (button) in
            button.right.equalTo(placeholder.snp.right).offset(-8)
            button.size.equalTo(12)
            button.centerY.equalToSuperview()
        }
    }
    
}
