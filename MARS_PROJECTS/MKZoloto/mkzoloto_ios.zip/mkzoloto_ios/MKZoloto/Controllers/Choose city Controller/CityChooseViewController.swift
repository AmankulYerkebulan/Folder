import UIKit

class CityChooseViewController: UIViewController {
    
    var branchViewModel: BranchViewModel?
    
    lazy var tableView: UITableView = {
        let tableView = UITableView()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(cellWithClass: UITableViewCell.self)
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViews()
        setupConstraints()
        
        self.branchViewModel?.fetchCities {
            self.tableView.reloadData()
        }
        
    }
    
    private func setupViews() {
        
        self.view.addSubview(tableView)
        
    }
    
    private func setupConstraints() {
        
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
    }
    
}

extension CityChooseViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.branchViewModel?.cities.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withClass: UITableViewCell.self, for: indexPath)
        
        if let city = self.branchViewModel?.cities[indexPath.row] {
            cell.textLabel?.text = city.name
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if let city = self.branchViewModel?.cities[indexPath.row] {
            self.branchViewModel?.currentCity?.onNext(city)
            StoreManager.shared().setupCurrentCity(model: city)
        }
        
        self.navigationController?.popViewController()
    }
    
}
