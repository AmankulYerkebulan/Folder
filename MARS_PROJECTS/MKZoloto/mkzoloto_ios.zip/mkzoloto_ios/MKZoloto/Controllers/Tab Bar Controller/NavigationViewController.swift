

import UIKit

class NavigationController: UINavigationController, UINavigationControllerDelegate, UIGestureRecognizerDelegate {
    
//    MARK: Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        delegate = self
        interactivePopGestureRecognizer?.delegate = self
        
        /// Setting design
        navigationBar.setupNavigationAppearance()
        
    }
    
    /// Setting back button to controller automatically if is not first controller in stack
    func navigationController(_ navigationController: UINavigationController, willShow viewController: UIViewController, animated: Bool) {
        if viewController != self.viewControllers.first { 
            let backButton = UIBarButtonItem(image: UIImage(named: "BackArrow"), style: .plain, target: self, action: #selector(popViewController(animated:)) )
            viewController.navigationItem.leftBarButtonItem = backButton
            /// Hiding tabbar when pushed new controller
            viewController.tabBarController?.tabBar.isHidden = true
        } else {
            viewController.tabBarController?.tabBar.isHidden = false
        }
    }
    
    /// Setting gesture to swiping back
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldBeRequiredToFailBy otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        return true
    }
    
    /// Setting appilication status bar to light
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .default
    }
    
}
