
import UIKit
import SwifterSwift

class TabBarViewController: UITabBarController {
    
    //MARK: - Properties
    
    lazy var mainController: UINavigationController = {
        let controller = MainViewController()
        controller.tabBarItem = UITabBarItem(title: "Главная".localized(), image: #imageLiteral(resourceName: "Group 2").withRenderingMode(UIImage.RenderingMode.alwaysOriginal), selectedImage: #imageLiteral(resourceName: "Group 3").withRenderingMode(UIImage.RenderingMode.alwaysOriginal))
        let nvController = NavigationController(rootViewController: controller)
        return nvController
    }()
    
    lazy var ServicesController: UINavigationController = {
        let services = ServiceViewController()
        services.tabBarItem = UITabBarItem(title: "Кто мы?".localized(), image: #imageLiteral(resourceName: "Group").withRenderingMode(UIImage.RenderingMode.alwaysOriginal), selectedImage: #imageLiteral(resourceName: "Group-1").withRenderingMode(UIImage.RenderingMode.alwaysOriginal))
        
        let nvController = NavigationController(rootViewController: services)
        return nvController
    }()
    
    lazy var mapController: UINavigationController = {
        let services = BranchesViewController()
        services.tabBarItem = UITabBarItem(title: "Загляни к нам".localized(), image: UIImage(named: "Like")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal), selectedImage: UIImage(named: "LikeS")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal))
        
        let nvController = NavigationController(rootViewController: services)
        return nvController
    }()
    
    lazy var companyController: UINavigationController = {
        let company = FeedbackViewController()
        company.tabBarItem = UITabBarItem(title: "Пообщаемся?".localized(), image: UIImage(named: "call")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal), selectedImage: UIImage(named: "callS")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal).withRenderingMode(UIImage.RenderingMode.alwaysOriginal))
        
        let nvController = NavigationController(rootViewController: company)
        return nvController
    }()
    
    lazy var profileController: UINavigationController = {
        var cabinet: UIViewController = AuthorizationViewController()
        
        if StoreManager.shared().getIsAuth() ?? false == true {
            cabinet = CabinetViewController()
        }
        
        cabinet.tabBarItem = UITabBarItem(title: "Мой Ломбард".localized(), image: UIImage(named: "Profile")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal), selectedImage: UIImage(named: "ProfileS")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal))
        
        let nvController = NavigationController(rootViewController: cabinet)

        return nvController
        
    }()
    
    //MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupControllers()
    }
    
    private func setupControllers() {
        
        viewControllers = [mainController, mapController, profileController, companyController, ServicesController]
    }
    
}
