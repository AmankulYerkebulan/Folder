
import UIKit
import Cartography

class ItemWithImageCell: UITableViewCell {
    
    lazy var Title: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textColor = Global.dark()
        label.font = Global.sfRegular(size: StaticSize.s12)
        return label
    }()
    
    lazy var imageItem: UIImageView = {
        let switcher = UIImageView()
        switcher.cornerRadius = 3
        switcher.borderColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 0.5)
        switcher.borderWidth = 1
        return switcher
    }()
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("Some error")
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
        setupConstraints()
    }
}


extension ItemWithImageCell {
    
    private func setupViews() {
        
        self.addSubviews([Title, imageItem])
    }
    
    private func setupConstraints() {
        
        Title.snp.makeConstraints { (make) in
            make.left.equalTo(self.snp.left).offset(16)
            make.right.equalTo(imageItem.snp.left).offset(-16)
            make.centerY.equalTo(imageItem.snp.centerY)
        }
        
        imageItem.snp.makeConstraints { (make) in
            make.top.equalTo(self.snp.top).offset(13)
            make.right.equalTo(self.snp.right).offset(-16)
            make.width.equalTo(54)
            make.height.equalTo(54)
            make.bottom.equalTo(self.snp.bottom).offset(-13)
        }
    }
    
}





