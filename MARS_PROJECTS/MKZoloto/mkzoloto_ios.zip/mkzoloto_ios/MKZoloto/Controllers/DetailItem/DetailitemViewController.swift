
import UIKit

class DetailitemViewController: UIViewController {
    
    var data: PurchasedItem?
    var index: Int?
    
    private lazy var tableView : UITableView = {
        let tView = UITableView()
        tView.register(UITableViewCell.self, forCellReuseIdentifier: "cell1")
        tView.register(ItemWithImageCell.self, forCellReuseIdentifier: "ItemWithImageCell")
        tView.delegate = self
        tView.dataSource = self
        tView.separatorStyle = .none
        tView.backgroundColor = Global.grey()
        return tView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.addSubview(tableView)
        if index != nil {
            self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Удалить".localized(), style: UIBarButtonItem.Style.plain, target: self, action: #selector(removeItem))
        }
        tableView.snp.makeConstraints { (make) in
            make.width.equalToSuperview()
            make.height.equalToSuperview()
        }
    }

}

extension DetailitemViewController: UITableViewDelegate,UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.index == nil {
            return 5
        }
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let data = data else {return UITableViewCell()}
        
        if indexPath.row != 4 {
            let cell = UITableViewCell(style: .value1, reuseIdentifier: String(describing: UITableViewCell.self))
            cell.textLabel?.textColor = Global.dark()
            cell.textLabel?.font = Global.sfMedium(size: StaticSize.s15)
            cell.detailTextLabel?.textColor = Global.dark()
            cell.detailTextLabel?.font = Global.sfMedium(size: StaticSize.s15)
            cell.setUpCellShadow()
            cell.backgroundColor = Global.white()
            if indexPath.row == 0 {
                cell.textLabel?.text = data.name
            } else if indexPath.row == 1 {
                cell.textLabel?.text = "Проба золота".localized()
                if self.index == nil {
                    cell.detailTextLabel?.text = "Au: " + (data.probe ?? "")
                } else {
                    cell.detailTextLabel?.text = data.au999
                }
            } else if indexPath.row == 2 {
                cell.textLabel?.text = "Вес изделия, грамм".localized()
                cell.detailTextLabel?.text = data.weight
            } else {
                cell.textLabel?.text = "Содержание Au999, грамм".localized()
                cell.detailTextLabel?.text = data.au999
            }
            return cell
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ItemWithImageCell", for: indexPath) as! ItemWithImageCell

        cell.Title.text = data.description
        cell.imageItem.kf.setImage(with: URL(string: data.image ?? ""), placeholder: nil, options: nil, progressBlock: nil) { (result) in
            
        }
        return cell
    }
    
    @objc private func removeItem() {
        NotificationCenter.default.post(name: NSNotification.Name("ITEMRREMOVED"), object: self.index)
        self.navigationController?.popViewController()
    }
    
}
