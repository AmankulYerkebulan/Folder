//
//  Constants.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 5/23/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import UIKit

struct Constants {
    static var width = UIScreen.main.bounds.width
    
    static var mainViewSectionOffset    : CGFloat = 0
    static var mainViewCellOffset       : CGFloat = (16 / 375) * Constants.width
    static var s16                      : CGFloat = (16 / 375) * Constants.width
    
}
