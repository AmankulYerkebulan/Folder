
import Foundation
import UIKit

extension UINavigationBar {
    
    func setupNavigationAppearance() {
        titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.black]
        backIndicatorImage = UIImage()
        backIndicatorTransitionMaskImage = UIImage()
    }
}

extension UINavigationController {
    
    func setUpShadow() {
        
        self.navigationBar.layer.masksToBounds = false
        self.navigationBar.layer.shadowColor = Global.black().withAlphaComponent(0.2).cgColor
        self.navigationBar.layer.shadowOpacity = 0.5
        self.navigationBar.layer.shadowOffset = CGSize(width: 0, height: 2.0)
        self.navigationBar.layer.shadowRadius = 2
    }
}


extension UILabel {
    func halfTextColorChange (fullText : String , changeText : String, fontSize: CGFloat = StaticSize.s15) {
        let strNumber: NSString = fullText as NSString
        let range = (strNumber).range(of: changeText)
        let attribute = NSMutableAttributedString.init(string: fullText)
        attribute.addAttribute(NSAttributedString.Key.font, value: Global.sfBold(size: fontSize) , range: range)
        self.attributedText = attribute
    }
}

extension String {
    
    func formatToNorm() -> String {
        let formatterr = NumberFormatter()
        formatterr.numberStyle = .decimal
        formatterr.locale = Locale(identifier: "fr_FR")
        let price = NSNumber(value: Int(self) ?? 0)
        return formatterr.string(from: price) ?? "0"
    }
    
    func formattedDate() -> String {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        let date = dateFormatter.date(from: self) ?? Date()
        
        let formatter = DateFormatter()
        formatter.dateFormat = "dd.MM.yyyy"
        
        return formatter.string(from: date)
        
    }
    
}

extension UIViewController {
    
    func setupBackButton() {
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(named: "BackArrow"), style: .plain, target: self, action: #selector(UINavigationController.popViewController(animated:)))
        
    }
    
    func activityStartAnimating(activityColor: UIColor = .gray, backgroundColor: UIColor = .white) {
        
        let backgroundView = UIView()
        backgroundView.frame = CGRect.init(x: 0, y: 0, width: 100, height: 100)
        backgroundView.backgroundColor = backgroundColor
        backgroundView.tag = 475647
        backgroundView.cornerRadius = 10
        
        var activityIndicator: UIActivityIndicatorView = UIActivityIndicatorView()
        activityIndicator = UIActivityIndicatorView(frame: CGRect.init(x: 0, y: 0, width: 50, height: 50))
        activityIndicator.center = backgroundView.center
        activityIndicator.hidesWhenStopped = true
        activityIndicator.style = UIActivityIndicatorView.Style.gray
        activityIndicator.color = activityColor
        activityIndicator.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        backgroundView.addSubview(activityIndicator)
        backgroundView.center = self.view.center
        
        self.view.addSubview(backgroundView)
    }
    
    func activityStopAnimating() {
        if let background = self.view.viewWithTag(475647){
            background.removeFromSuperview()
        }
        self.view.isUserInteractionEnabled = true
    }
    
}

extension UIView {
    
    func setRoundCircle() {
        
        self.cornerRadius = self.height * 0.5
    }
}

extension CALayer {
    
    func addBorder(edge: UIRectEdge, color: UIColor, thickness: CGFloat) {
        
        let border = CALayer()
        
        switch edge {
        case UIRectEdge.top:
            border.frame = CGRect(x: 0, y: 0, width: self.bounds.width, height: thickness)
            
        case UIRectEdge.bottom:
            border.frame = CGRect(x: 0, y: self.bounds.height - thickness,  width: UIScreen.main.bounds.width, height: thickness)
            
        case UIRectEdge.left:
            border.frame = CGRect(x: 0, y: 0,  width: thickness, height: self.bounds.height)
            
        case UIRectEdge.right:
            border.frame = CGRect(x: self.bounds.width - thickness, y: 0,  width: thickness, height: self.bounds.height)
        default:
            break
        }
        border.backgroundColor = color.cgColor;
        self.addSublayer(border)
    }
    
    func addDashedBorder(edge: UIRectEdge, color: UIColor, thickness: CGFloat) {
        
        let border = CAShapeLayer()
        border.strokeColor = UIColor.black.cgColor
        border.lineDashPattern = [4, 4]
        border.fillColor = nil
        
        switch edge {
        case UIRectEdge.top:
            border.frame = CGRect(x: Constants.s16 * 2, y: 0, width: (Constants.width - Constants.s16 * 4), height: thickness)
            
        case UIRectEdge.bottom:
            border.frame = CGRect(x: 0, y: self.bounds.height - thickness,  width: UIScreen.main.bounds.width, height: thickness)
            
        case UIRectEdge.left:
            border.frame = CGRect(x: 0, y: 0,  width: thickness, height: self.bounds.height)
            
        case UIRectEdge.right:
            border.frame = CGRect(x: self.bounds.width - thickness, y: 0,  width: thickness, height: self.bounds.height)
        default:
            break
        }
        
        border.path = UIBezierPath(rect: border.bounds).cgPath
        
        border.backgroundColor = color.cgColor;
        self.addSublayer(border)
    }
    
}


extension UIColor {
    convenience init(red: Int, green: Int, blue: Int) {
        assert(red >= 0 && red <= 255, "Invalid red component")
        assert(green >= 0 && green <= 255, "Invalid green component")
        assert(blue >= 0 && blue <= 255, "Invalid blue component")
        
        self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
    }
    
    convenience init(rgb: Int) {
        self.init(
            red: (rgb >> 16) & 0xFF,
            green: (rgb >> 8) & 0xFF,
            blue: rgb & 0xFF
        )
    }
}

extension UITextField {
    enum PaddingSide {
        case left(CGFloat)
        case right(CGFloat)
        case both(CGFloat)
    }
    
    func addPadding(_ padding: PaddingSide) {
        self.leftViewMode = .always
        self.layer.masksToBounds = true
        
        switch padding {
            
        case .left(let spacing):
            let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: spacing, height: self.frame.height))
            self.leftView = paddingView
            self.rightViewMode = .always
            
        case .right(let spacing):
            let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: spacing, height: self.frame.height))
            self.rightView = paddingView
            self.rightViewMode = .always
            
        case .both(let spacing):
            let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: spacing, height: self.frame.height))
            // left
            self.leftView = paddingView
            self.leftViewMode = .always
            // right
            self.rightView = paddingView
            self.rightViewMode = .always
        }
    }
}

extension UITextField {
    
    enum Direction {
        case Left
        case Right
    }
    
    func setUpTextFiledUI() {
        self.font = Global.sfMedium(size: StaticSize.s15)
        self.textColor = Global.black()
        self.layer.borderWidth = 1.0
        self.layer.borderColor = Global.textFiledBorderColor().cgColor
        self.layer.cornerRadius = 4
        self.setPlaceHolderTextColor(Global.textFiledPlaceholderColor())
        self.backgroundColor = Global.grey()
        self.addPadding(.left(20))
    }
    
    // add image to textfield
    func withImage(direction: Direction, image: UIImage, colorSeparator: UIColor, colorBorder: UIColor){
        let mainView = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 45))
        mainView.layer.cornerRadius = 5
        
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 45))
        view.backgroundColor = .clear
        view.clipsToBounds = true
        view.layer.cornerRadius = 5
        view.layer.borderWidth = CGFloat(0.5)
        view.layer.borderColor = colorBorder.cgColor
        mainView.addSubview(view)
        
        let imageView = UIImageView(image: image)
        imageView.contentMode = .scaleAspectFill
        imageView.frame = CGRect(x: 12.0, y: 10.0, width: 24.0, height: 24.0)
        view.addSubview(imageView)
        
        let seperatorView = UIView()
        seperatorView.backgroundColor = colorSeparator
        mainView.addSubview(seperatorView)
        
        if(Direction.Left == direction){ // image left
            seperatorView.frame = CGRect(x: 45, y: 0, width: 5, height: 45)
            self.leftViewMode = .always
            self.leftView = mainView
        } else { // image right
            seperatorView.frame = CGRect(x: 0, y: 0, width: 5, height: 45)
            self.rightViewMode = .always
            self.rightView = mainView
        }
        
        self.layer.borderColor = colorBorder.cgColor
        self.layer.borderWidth = CGFloat(1)
        self.layer.cornerRadius = 5
    }
}

extension UIButton {
    
    func yellowBtnProperty() {
        self.layer.cornerRadius = 4
        self.backgroundColor    = Global.yellow()
        self.setTitleColor(Global.dark(), for: UIControl.State.normal)
        self.titleLabel?.font = Global.sfSemiBold(size: StaticSize.s17)
    }
}


extension SSRadioButton {
    
    func radioProperties(){
        self.setTitleColor(UIColor.blue, for: .normal)
        self.titleLabel?.font           = UIFont(name: "AvenirNext-Medium", size: 13)
        self.setTitleColor(UIColor.blue.withAlphaComponent(0.25), for: UIControl.State.highlighted)
        self.contentHorizontalAlignment = .left
        self.circleColor                = UIColor(rgb: 0x297FCA)
        self.circleRadius               = 9
        self.strokeColor = UIColor(rgb: 0x297FCA)
    }
}

extension UILabel {
    
    func label13Properties() {
        self.font = UIFont(name: "AvenirNext-Medium", size: 13)
        self.textColor = UIColor(rgb: 0x297FCA)
    }
    
    func label15Properties() {
        self.font = UIFont(name: "AvenirNext-Medium", size: 15)
        self.textColor = UIColor(rgb: 0x297FCA)
    }
    
    
    func label17Properties() {
        self.font = UIFont(name: "AvenirNext-Medium", size: 17)
        self.textColor = UIColor(rgb: 0x297FCA)
    }
}

extension UISegmentedControl {
    func removeBorder(){
        let backgroundImage = UIImage.getColoredRectImageWith(color: UIColor.white.cgColor, andSize: self.bounds.size)
        self.setBackgroundImage(backgroundImage, for: .normal, barMetrics: .default)
        self.setBackgroundImage(backgroundImage, for: .selected, barMetrics: .default)
        self.setBackgroundImage(backgroundImage, for: .highlighted, barMetrics: .default)
        
        let deviderImage = UIImage.getColoredRectImageWith(color: UIColor.white.cgColor, andSize: CGSize(width: 1.0, height: self.bounds.size.height))
        self.setDividerImage(deviderImage, forLeftSegmentState: .selected, rightSegmentState: .normal, barMetrics: .default)
        self.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.gray], for: .normal)
        self.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: Global.dark()], for: .selected)
    }
    
    func addUnderlineForSelectedSegment(){
        
        removeBorder()
        let underlineWidth: CGFloat = self.bounds.size.width / CGFloat(self.numberOfSegments)
        let underlineHeight: CGFloat = 0.5
        let underlineXPosition = CGFloat(selectedSegmentIndex * Int(underlineWidth))
        let underLineYPosition = self.bounds.size.height - 1.0
        let underlineFrame = CGRect(x: underlineXPosition, y: underLineYPosition, width: underlineWidth, height: underlineHeight)
        let underline = UIView(frame: underlineFrame)
        underline.backgroundColor = Global.dark()
        underline.tag = 1
        underline.layer.zPosition = 1
        self.addSubview(underline)
    }
    
    func changeUnderlinePosition(){
        guard let underline = self.viewWithTag(1) else {return}
        let underlineFinalXPosition = (self.bounds.width / CGFloat(self.numberOfSegments)) * CGFloat(selectedSegmentIndex)
        UIView.animate(withDuration: 0.1, animations: {
            underline.frame.origin.x = underlineFinalXPosition
            underline.layer.zPosition = 1
        })
    }
}

extension UIImage{
    
    class func getColoredRectImageWith(color: CGColor, andSize size: CGSize) -> UIImage{
        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
        let graphicsContext = UIGraphicsGetCurrentContext()
        graphicsContext?.setFillColor(color)
        let rectangle = CGRect(x: 0.0, y: 0.0, width: size.width, height: size.height)
        graphicsContext?.fill(rectangle)
        let rectangleImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return rectangleImage!
    }
}

extension UIViewController
{
    func hideKeyboard()
    {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(UIViewController.dismissKeyboard))
        
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard()
    {
        view.endEditing(true)
    }
}

extension UICollectionViewFlowLayout {
    func setProperty() {
        self.sectionInset    = UIEdgeInsets(top: 5, left: 8, bottom: 5, right: 0)
        self.scrollDirection = .horizontal
        self.minimumLineSpacing = 10
    }
    
    func setProperty2() {
        self.sectionInset    = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        self.scrollDirection = .horizontal
    }
}

extension UICollectionView {
    func setProperty() {
        self.backgroundColor                = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        self.showsHorizontalScrollIndicator = false
        self.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 8)
    }
    
    func setProperty2() {
        self.backgroundColor                = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        self.showsHorizontalScrollIndicator = false
        self.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
}

extension UIView {
    
    func setUpCellShadow() {
        addShadow(ofColor: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1).withAlphaComponent(0.7), radius: 1, offset: CGSize(width: 0, height: 1), opacity: 0.1)
    }
}

extension String {
    
    func setUpDay() -> String {
        let day = Int(self) ?? 0
        
        if (day.digits.count > 1) {
            if (day.digits[day.digits.count - 2] == 1) {
                return "дней".localized()
            }
        }
        
        if (day.digits.last! == 0 || day.digits.last! >= 5) {
            return "дней".localized()
        } else if (day.digits.last! == 2 || day.digits.last! == 3 || day.digits.last! == 4) {
            return "дня".localized()
        } else {
            return "день".localized()
        }
    }
}

extension UITextField {
    
    func setUptextFiled() {
        let textField = self
        textField.borderWidth = 1
        textField.borderColor = Global.textFiledBorderColor()
        textField.backgroundColor = Global.grey()
        textField.setPlaceHolderTextColor(Global.textFiledPlaceholderColor())
        textField.font = Global.sfMedium(size: StaticSize.s15)
        textField.cornerRadius = 4
    }
    
}

extension UITapGestureRecognizer {
    
    func didTapAttributedTextInLabel(label: UILabel, inRange targetRange: NSRange) -> Bool {
        
        let layoutManager = NSLayoutManager()
        let textContainer = NSTextContainer(size: CGSize.zero)
        let textStorage = NSTextStorage(attributedString: label.attributedText!)
        
        layoutManager.addTextContainer(textContainer)
        textStorage.addLayoutManager(layoutManager)
        
        textContainer.lineFragmentPadding = 0.0
        textContainer.lineBreakMode = label.lineBreakMode
        textContainer.maximumNumberOfLines = label.numberOfLines
        let labelSize = label.bounds.size
        textContainer.size = labelSize
        
        let locationOfTouchInLabel = self.location(in: label)
        let textBoundingBox = layoutManager.usedRect(for: textContainer)
        let textContainerOffset = CGPoint(x: (labelSize.width - textBoundingBox.size.width) * 0.5 - textBoundingBox.origin.x,
                                          y:(labelSize.height - textBoundingBox.size.height) * 0.5 - textBoundingBox.origin.y);
        let locationOfTouchInTextContainer = CGPoint(x:locationOfTouchInLabel.x - textContainerOffset.x,
                                                     y:locationOfTouchInLabel.y - textContainerOffset.y);
        let indexOfCharacter = layoutManager.characterIndex(for: locationOfTouchInTextContainer, in: textContainer, fractionOfDistanceBetweenInsertionPoints: nil)
        
        return NSLocationInRange(indexOfCharacter, targetRange)
    }
}

extension UILabel {
    
    func addImageWith(name: String, behindText: Bool) {
        
        let attachment = NSTextAttachment()
        attachment.image = UIImage(named: name)
        let attachmentString = NSAttributedString(attachment: attachment)
        
        guard let txt = self.text else {
            return
        }
        
        if behindText {
            let strLabelText = NSMutableAttributedString(string: txt)
            strLabelText.append(attachmentString)
            self.attributedText = strLabelText
        } else {
            let strLabelText = NSAttributedString(string: txt)
            let mutableAttachmentString = NSMutableAttributedString(attributedString: attachmentString)
            mutableAttachmentString.append(strLabelText)
            self.attributedText = mutableAttachmentString
        }
    }
    
    func removeImage() {
        let text = self.text
        self.attributedText = nil
        self.text = text
    }
}

extension String {
    func lastWord() -> String? {
        let stringArray = self.components(separatedBy: NSCharacterSet.whitespacesAndNewlines)
        return stringArray.last
    }
}
