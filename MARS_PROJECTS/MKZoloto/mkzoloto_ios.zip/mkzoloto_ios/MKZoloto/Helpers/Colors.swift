//
//  Colors.swift
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import UIKit

extension UIColor {
    
    static let grayBackgroundColor  = UIColor(hexString: "#F7F7F7") ?? .gray
    static let cellBorderColor      = UIColor(hexString: "#ECECEC") ?? .gray
    
    static let yellowColor          = UIColor(hexString: "#FFF200") ?? .yellow
    
}
