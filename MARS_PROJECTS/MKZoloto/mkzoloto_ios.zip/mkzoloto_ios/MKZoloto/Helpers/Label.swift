//
//  Label.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 3/29/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import UIKit

class Label: UILabel {
    
    var intrinsicWidth: Double = 1
    
    override var intrinsicContentSize: CGSize {
        return CGSize(width: intrinsicWidth, height: 20)
    }
    
}
