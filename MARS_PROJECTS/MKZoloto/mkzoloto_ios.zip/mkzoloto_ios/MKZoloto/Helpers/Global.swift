
import Foundation
import UIKit

class Global {
    
    class func yellow() -> UIColor {
        return #colorLiteral(red: 1, green: 0.9490196078, blue: 0, alpha: 1)
    }
    
    class func black() -> UIColor {
        return #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
    }
    
    class func dark() -> UIColor {
        return #colorLiteral(red: 0.2, green: 0.2, blue: 0.2, alpha: 1)
    }
    
    class func darkGray() -> UIColor {
        return UIColor(hexString: "#E5E5E5") ?? .gray
    }
    
    class func grey() -> UIColor {
        return #colorLiteral(red: 0.968627451, green: 0.968627451, blue: 0.968627451, alpha: 1)
    }
    
    class func gray() -> UIColor {
        return UIColor(hexString: "#FAFAFA") ?? .gray
    }
    
    class func blue() -> UIColor {
        return #colorLiteral(red: 0, green: 0.5333333333, blue: 1, alpha: 1)
    }

    class func red() -> UIColor {
        return #colorLiteral(red: 1, green: 0.231372549, blue: 0.1882352941, alpha: 1)
    }
    
    class func white() -> UIColor {
        return #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
    }
    
    class func textFiledBorderColor() -> UIColor {
        return #colorLiteral(red: 0.9254901961, green: 0.9254901961, blue: 0.9254901961, alpha: 1)
    }
    
    class func textFiledPlaceholderColor() -> UIColor {
        return #colorLiteral(red: 0.2, green: 0.2, blue: 0.2, alpha: 0.5)
    }
        
    class func sfRegular(size: CGFloat) -> UIFont {
        return UIFont(name: "SFProDisplay-Regular", size: size)!
    }
    
    class func sfMedium(size: CGFloat) -> UIFont {
        return UIFont(name: "SFProDisplay-Medium", size: size)!
    }
    
    class func sfBold(size: CGFloat) -> UIFont {
        return UIFont(name: "SFProDisplay-Bold", size: size)!
    }
    
    class func sfSemiBold(size: CGFloat) -> UIFont {
        return UIFont(name: "SFProDisplay-Semibold", size: size)!
    }
    
    class func stroke(size: CGFloat) -> UIFont {
        return UIFont(name: "Stroke(RUS BY LYAJKA)", size: size)!
    }
    
}

struct ScreenSize
{
    static let SCREEN_WIDTH         = UIScreen.main.bounds.size.width
    static let SCREEN_HEIGHT        = UIScreen.main.bounds.size.height
    static let SCREEN_MAX_LENGTH    = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    static let SCREEN_MIN_LENGTH    = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
}

struct StaticSize {
    static let s14 = ScreenSize.SCREEN_WIDTH / 26.7
    static let s30 = ScreenSize.SCREEN_WIDTH / 12.5
    static let s44 = ScreenSize.SCREEN_WIDTH / 8.5
    static let s18 = ScreenSize.SCREEN_WIDTH / 20.8
    static let s20 = ScreenSize.SCREEN_WIDTH / 18.75
    static let s16 = ScreenSize.SCREEN_WIDTH / 23.4
    static let s12 = ScreenSize.SCREEN_WIDTH / 31.25
    static let s19 = ScreenSize.SCREEN_WIDTH / 19.7
    static let s60 = ScreenSize.SCREEN_WIDTH / 6.25
    static let s76 = ScreenSize.SCREEN_WIDTH / 4.93
    static let s9  = ScreenSize.SCREEN_WIDTH / 41.6
    static let s260 = ScreenSize.SCREEN_WIDTH / 1.44
    static let s150 = ScreenSize.SCREEN_WIDTH / 2.5
    static let s22 = ScreenSize.SCREEN_WIDTH / 17
    static let s17 = ScreenSize.SCREEN_WIDTH / 22
    static let s100 = ScreenSize.SCREEN_WIDTH / 3.75
    static let s28 = ScreenSize.SCREEN_WIDTH / 13.39
    static let s118 = ScreenSize.SCREEN_WIDTH / 3.23 + 2
    static let s23 = ScreenSize.SCREEN_WIDTH / 16.3
    static let s24 = (24 / 375) * ScreenSize.SCREEN_WIDTH
    static let s241 = (241 / 375) * ScreenSize.SCREEN_WIDTH
    static let s242 = (242 / 375) * ScreenSize.SCREEN_WIDTH
    static let s5 = (5 / 375) * ScreenSize.SCREEN_WIDTH
    static let s6 = (6 / 375) * ScreenSize.SCREEN_WIDTH
    static let s13 = (13 / 375) * ScreenSize.SCREEN_WIDTH 
    static let s36 = ScreenSize.SCREEN_WIDTH / 10.4
    static let s34 = ScreenSize.SCREEN_WIDTH / 11
    static let s40 = ScreenSize.SCREEN_WIDTH / 9.375
    static let s10 = ScreenSize.SCREEN_WIDTH / 37.5
    static let s240 = ScreenSize.SCREEN_WIDTH / 1.56
    static let s243 = ScreenSize.SCREEN_WIDTH / 1.42
    static let s200 = ScreenSize.SCREEN_WIDTH / 1.875
    static let s135 = ScreenSize.SCREEN_WIDTH / 2.7
    static let s184 = ScreenSize.SCREEN_WIDTH / 2
    static let s316 = ScreenSize.SCREEN_WIDTH / 1.18
    static let s75 = ScreenSize.SCREEN_WIDTH / 5
    static let s50 = ScreenSize.SCREEN_WIDTH / 7.5
    static let s86 = ScreenSize.SCREEN_WIDTH / 4.36
    static let s15 = ScreenSize.SCREEN_WIDTH / 25
    static let s42 = ScreenSize.SCREEN_WIDTH / 8.92
    static let s11 = ScreenSize.SCREEN_WIDTH / 34
    static let s57 = ScreenSize.SCREEN_WIDTH / 6.81 + 2
    static let s46 = ScreenSize.SCREEN_WIDTH / 8.15
    static let s70 = ScreenSize.SCREEN_WIDTH / 5.357
    static let s55 = ScreenSize.SCREEN_WIDTH / 6.81
    static let s128 = ScreenSize.SCREEN_WIDTH / 2.92
    static let s140 = ScreenSize.SCREEN_WIDTH / 2.67
    static let s188 = ScreenSize.SCREEN_WIDTH / 1.99
    static let s90 = ScreenSize.SCREEN_WIDTH / 4.16
    static let s80 = ScreenSize.SCREEN_WIDTH / 4.68
    static let s26 = ScreenSize.SCREEN_WIDTH / 14.42
    static let s138 = ScreenSize.SCREEN_WIDTH / 2.71
    static let s115 = ScreenSize.SCREEN_WIDTH / 3.26
    static let s8 = ScreenSize.SCREEN_WIDTH / 46.875
    static let s105 = ScreenSize.SCREEN_WIDTH / 3.57
    static let s25 = ScreenSize.SCREEN_WIDTH / 15
    static let s227 = ScreenSize.SCREEN_WIDTH / 1.65
    static let s160 = ScreenSize.SCREEN_WIDTH / 2.34
    static let s194 = ScreenSize.SCREEN_WIDTH / 1.93
    static let s276 = ScreenSize.SCREEN_WIDTH / 1.35
    static let s121 = ScreenSize.SCREEN_WIDTH / 3.1
    static let s218 = ScreenSize.SCREEN_WIDTH / 1.72
    static let s174 = ScreenSize.SCREEN_WIDTH / 2.15
}
