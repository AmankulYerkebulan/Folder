
import UIKit

/**
 Self sized table view invalidates constraints after adding cell or reloading cell
 */
class SelfSizedTableView: UITableView {
    
    
    override var contentSize: CGSize {
        didSet {
            invalidateIntrinsicContentSize()
            self.isScrollEnabled = false
        }
    }

    override var intrinsicContentSize: CGSize {
        layoutIfNeeded()
        return CGSize(width: UIView.noIntrinsicMetric, height: contentSize.height)
    }
    
}

