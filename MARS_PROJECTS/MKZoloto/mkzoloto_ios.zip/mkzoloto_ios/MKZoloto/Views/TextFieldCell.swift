
import UIKit

class TextFieldCell: UITableViewCell {
    
    lazy var textField: VSTextField = {
        let textField = VSTextField()
        textField.borderWidth = 1
        textField.borderColor = .cellBorderColor
        textField.backgroundColor = .grayBackgroundColor
        textField.cornerRadius = 4
        
        textField.keyboardType = .numberPad
        textField.addPaddingLeft(16)
        return textField
    }()
    
    //    MARK: Init
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        setupViews()
        setupConstraints()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        
        self.addSubviews([textField])
        self.selectionStyle = .none
        
    }
    
    //    MARK: Constraints
    private func setupConstraints() {
        
        textField.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(8)
            make.bottom.equalToSuperview().offset(-8)
            make.left.equalToSuperview().offset(16)
            make.right.equalToSuperview().offset(-16)
        }
        
    }
    
}
