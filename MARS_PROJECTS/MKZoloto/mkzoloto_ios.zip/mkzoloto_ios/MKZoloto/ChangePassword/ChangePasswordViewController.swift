
import UIKit
import SnapKit
import SVProgressHUD
import Alamofire

class ChangePasswordViewController: UIViewController {
    
    private lazy var mainView : UIView = {
        let view = UIView()
        view.backgroundColor = Global.white()
        view.cornerRadius = 5
        view.addShadow(ofColor: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), radius: 3, offset: .zero, opacity: 0.1)
        return view
    }()
    
    lazy var currentPass : UITextField = {
        let tField = UITextField()
        tField.placeholder = "Текущий пароль".localized()
        tField.addPadding(.left(16))
        tField.setUptextFiled()
        return tField
    }()
    
    lazy var newPass : UITextField = {
        let tField = UITextField()
        tField.placeholder = "Новый пароль".localized()
        tField.addPadding(.left(16))
        tField.setUptextFiled()
        return tField
    }()
    
    lazy var againPass : UITextField = {
        let tField = UITextField()
        tField.placeholder = "Новый пароль повторно".localized()
        tField.addPadding(.left(16))
        tField.setUptextFiled()
        return tField
    }()
    
    lazy var savePassBtn: UIButton = {
        let button = UIButton()
        button.yellowBtnProperty()
        button.setTitle("Сохранить".localized(), for: UIControl.State.normal)
        button.addTarget(self, action: #selector(changePassword), for: .touchUpInside)
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        setupButton()
        setConstraints()
        
        navigationItem.title = "Изменение пароля".localized()
    }
    
    @objc private func changePassword() {
        
        guard let currentPassword = currentPass.text,
                let newPassword   = newPass.text,
                let againPassword = againPass.text else {
            SVProgressHUD.showError(withStatus: "Заполните все поля".localized())
            return
        }
        
        if (currentPassword.isEmpty || newPassword.isEmpty || againPassword.isEmpty) {
            SVProgressHUD.showError(withStatus: "Заполните все поля".localized())
            return
        }
        
        if (newPassword != againPassword) {
            SVProgressHUD.showError(withStatus: "Пароль и повторный пароль не совпадает".localized())
            return
        }
        
        let request = ApiRequests.changePassword(oldPassword: currentPassword, newPassword: newPassword)
        
        SVProgressHUD.show()
        
        NetworkManager.shared.makeRequest(apiRequest: request) { (result: Result<String>) in
            
            switch result {
            case .failure(let error):
                SVProgressHUD.showError(withStatus: error.localizedDescription)
            case .success(let data):
                SVProgressHUD.showSuccess(withStatus: data)
                self.navigationController?.popViewController()
            }
            
        }
        
    }
    
}


extension ChangePasswordViewController {
    
    private func setupButton() {
        
        self.view.addSubview(mainView)
        self.view.addSubview(savePassBtn)
        self.view.backgroundColor = Global.grey()
        self.mainView.addSubviews([currentPass, newPass, againPass])
    }
    
    private func setConstraints() {
        
        mainView.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.top.equalTo(self.view.safeAreaLayoutGuide).offset(StaticSize.s12)
            } else {
                make.top.equalTo(self.view).offset(StaticSize.s12)
            }
            make.left.equalToSuperview().offset(StaticSize.s16)
            make.right.equalToSuperview().offset(-StaticSize.s16)
        }
        
        currentPass.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.top.equalTo(self.mainView.safeAreaLayoutGuide).offset(StaticSize.s16)
            } else {
                 make.top.equalTo(self.mainView).offset(StaticSize.s16)
            }
            make.left.equalToSuperview().offset(StaticSize.s16)
            make.right.equalToSuperview().offset(-StaticSize.s16)
            make.height.equalTo(StaticSize.s44)
        }
        
        newPass.snp.makeConstraints { (make) in
            make.top.equalTo(currentPass.snp.bottom).offset(StaticSize.s8)
            make.left.right.height.equalTo(currentPass)
        }
        
        againPass.snp.makeConstraints { (make) in
            make.top.equalTo(newPass.snp.bottom).offset(StaticSize.s8)
            make.left.right.height.equalTo(newPass)
            make.bottom.equalTo(mainView.snp.bottom).offset(-StaticSize.s16)
        }
        
        savePassBtn.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(self.view.safeAreaLayoutGuide).offset(-16)
            } else {
                make.bottom.equalTo(self.view).offset(-16)
            }
            make.left.right.height.equalTo(newPass)
        }
    }
    
}
