
import UIKit
import CommonCrypto
import IQKeyboardManagerSwift
import OneSignal
import Fabric
import Crashlytics

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
    
        Fabric.with([Crashlytics.self])
        IQKeyboardManager.shared.enable = true
        
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.makeKeyAndVisible()
        let rootController = TabBarViewController()
        window?.rootViewController = rootController
        NotificationCenter.default.addObserver(self, selector: #selector(tokenIsRequired), name: NSNotification.Name("TOKENREQUIRED"), object: nil)
        let attributes = [NSAttributedString.Key.font: Global.stroke(size: StaticSize.s17)]
        UINavigationBar.appearance().titleTextAttributes = attributes
        UINavigationBar.appearance().tintColor = Global.dark()
        UINavigationBar.appearance().shadowImage = UIImage()
        UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: Global.dark()], for: .selected)
        UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.clear], for: .normal)
        
        let onesignalInitSettings = [kOSSettingsKeyAutoPrompt: false]
        
        OneSignal.initWithLaunchOptions(launchOptions,
                                        appId: "46105af0-9ea5-43fa-ad4f-e438302cd771",
                                        handleNotificationAction: nil,
                                        settings: onesignalInitSettings)
        
        OneSignal.inFocusDisplayType = OSNotificationDisplayType.notification;
        
        OneSignal.promptForPushNotifications(userResponse: { accepted in
            print("User accepted notifications: \(accepted)")
        })
        
        return true
    }
    
    func applicationWillResignActive(_ application: UIApplication) {
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
    }

    func applicationWillTerminate(_ application: UIApplication) {
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name("TOKENREQUIRED"), object: nil)
    }
}

extension AppDelegate {
    
    //MARK: - Functions
    
    @objc private func tokenIsRequired() {
        
        if let root = window?.rootViewController as? TabBarViewController {
            let cabinet = AuthorizationViewController()
            cabinet.tabBarItem = UITabBarItem(title: "Мой Ломбард".localized(), image: UIImage(named: "Profile")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal), selectedImage: UIImage(named: "ProfileS")!.withRenderingMode(UIImage.RenderingMode.alwaysOriginal))
            let nvController = NavigationController(rootViewController: cabinet)
            StoreManager.shared().setIsAuth(bool: false)
            cabinet.isTouchIdUsable = StoreManager.shared().isTouchIdUsable()
            StoreManager.shared().removeAllGoldSamples()
            root.viewControllers?[2] = nvController
        }
    }
    
}
