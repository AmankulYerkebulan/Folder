//
//  CityModel.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 5/1/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import Foundation

struct CityModel: Codable {
    
    var name        : String
    var cityEnglish : String
    
    private enum CodingKeys: String, CodingKey {
        case name = "city"
        case cityEnglish = "city_eng"
    }
    
}
