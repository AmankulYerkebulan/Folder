//
//  BranchModel.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 4/29/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import Foundation

struct BranchModel: Codable {
    let id: Int
    let city: String
    let address: String
    let lat: String
    let lng: String
    let alias: String
    let phone: String
    let operationMode: String
    let weekends: String
    let services: String
    let VIP: Bool
    let image: String?
    
    private enum CodingKeys: String, CodingKey {
        case id
        case city = "city"
        case address = "address"
        case lat
        case lng
        case alias
        case phone
        case operationMode = "RezhimRaboty"
        case weekends = "Vyhodnye"
        case services = "Uslugi"
        case VIP = "VIP"
        case image
    }
}
