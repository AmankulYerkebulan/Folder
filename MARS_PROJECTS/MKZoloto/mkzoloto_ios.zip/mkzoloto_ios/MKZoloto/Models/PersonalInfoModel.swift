//
//  PersonalInfoModel.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 5/21/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import Foundation

struct PersonalInfoModel: Codable {
    let name: String
    let phone: String
    let email: String
    let iin: String
    let birthday: String
}
