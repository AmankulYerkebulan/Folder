//
//  OrderModel.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 5/27/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import Foundation

struct OrderModel: Codable {
    let order: Int
    let place: String
    let date: String
    let status: String
    let totalSum: Int
    let loans: [Loans]
    
    private enum CodingKeys: String, CodingKey {
        case order
        case place
        case date
        case status
        case totalSum = "total_sum"
        case loans
    }
}

struct OrderModelWithURL:Codable {
    let url : String
    let order : Int
    private enum CodingKeys: String, CodingKey {
        
        case order
        case url
    }
}

struct Status:Codable {
    let status: String
    private enum CodingKeys: String, CodingKey {
        
        case status
    }
}

struct Loans: Codable {
    let loanId: Int
    let amount: Int
    let operationType: String
    private enum CodingKeys: String, CodingKey {
        case loanId = "loan_id"
        case amount
        case operationType = "operation_type"
    }
}
