//
//  BannerModel.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 5/31/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import Foundation

struct BannerModel: Codable {
    let name: String
    let order: Int
    let desktop: String
    let mobile: String
    let text1: String?
    let text2: String?
    let text3: String?
    let text4: String?
    let link: String?
}
