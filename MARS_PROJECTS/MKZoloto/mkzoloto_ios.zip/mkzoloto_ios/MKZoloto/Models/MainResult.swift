//
//  MainResult.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 4/29/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import Foundation

struct MainResult<T: Codable>: Codable {
    
    let error: String?
    let data: T?
    
}

struct MainResultError<T: Codable>: Codable {
    
    let error: ErrorData?
}

struct ErrorData:Codable {
    let message : String?
}
