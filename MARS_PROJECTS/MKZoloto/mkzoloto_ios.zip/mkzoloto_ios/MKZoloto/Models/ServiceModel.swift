
import Foundation

struct ServiceModel: Codable {
    
    let id: Int
    let clickable: Bool
    let order: Int
    let title_mobile: String
    let webviewMobile: String?
    let show_in_mobile : Bool
    let nativeType : String?
    
}
