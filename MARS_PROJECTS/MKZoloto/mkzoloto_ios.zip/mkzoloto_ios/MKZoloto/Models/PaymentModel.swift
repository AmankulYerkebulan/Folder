//
//  PaymentModel.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 5/28/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import Foundation

struct PaymentModel: Codable {
    let url: String
}
