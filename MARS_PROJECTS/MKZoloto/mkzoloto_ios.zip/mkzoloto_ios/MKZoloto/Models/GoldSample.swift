//
//  GoldSample.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 4/29/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import Foundation

struct GoldSample: Codable {
    
    var id      : Int
    var key     : String
    var value   : Int
    
}

class GoldSampleForStorage: Codable {
    
    var id      : Int?
    var key     : String?
    var value   : Int?
    var name    : String?
    var weight  : Double?
    var au      : String?
    
    init(id: Int?,key: String?,value: Int?,name: String?,weight : Double?,au: String?) {
        self.id = id
        self.key = key
        self.value = value
        self.name = name
        self.weight = weight
        self.au = au
    }
}
