//
//  QuestionModel.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 5/1/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import Foundation

struct QuestionModel: Codable {
    
    var order       : Int
    var question    : String
    var answer      : String
    
    var isExpanded  : Bool = false
    
    private enum CodingKeys: String, CodingKey {
        
        case order, question, answer
        
    }
    
}
