
import Foundation

struct LoginModel: Codable {
    
    let accessToken: String
    let tokenType: String
    let expiresIn: Int
    private enum CodingKeys: String, CodingKey {
        case accessToken = "access_token"
        case tokenType = "token_type"
        case expiresIn = "expires_in"
    }
    
}

struct EmptyModel: Codable {
    
}

struct CalculationModel: Codable {
    let amount: Int
    let new_term : String
}

struct OpertaionTypes:Codable {
    let name: String
    let id: Int
}

struct ExpressProlongation: Codable {
    
    var loanId: Int
    var minRenewal: Int
    var maxRenewal: Int
    var loanTerm: String
    
    init(loanId: Int,minRenewal: Int,maxRenewal: Int,loanTerm: String) {
        self.loanTerm = loanTerm
        self.minRenewal = minRenewal
        self.maxRenewal = maxRenewal
        self.loanId = loanId
    }
    
    private enum CodingKeys: String, CodingKey {
        case loanId = "loan_id"
        case minRenewal = "min_renewal"
        case maxRenewal = "max_renewal"
        case loanTerm = "new_term"
    }
    
}

//struct PurchasedItems:Codable {
//
//    let purchasedItems:[PurchasedItem]
//}

struct PurchasedItem:Codable {
    
    var code: Int?
    var name: String?
    var probe: String?
    var weight : String?
    var au999: String?
    var maxAmountDateIssuse : Int?
    var image : String?
    var description: String?
    var isFromServer = true
    init(name: String,prob: String,weight: String,au: String) {
        self.name = name
        self.probe = prob
        self.weight = weight
        self.code = nil
        self.au999 = au
        self.maxAmountDateIssuse = nil
        self.image = nil
        self.isFromServer = false
    }
    
    private enum CodingKeys: String, CodingKey {
        case code = "item_code"
        case probe = "probe"
        case weight = "weight"
        case name = "name"
        case image = "image"
        case au999 = "au999content"
        case maxAmountDateIssuse = "max_amount_date_issue"
        case description
    }
}


