//
//  CalculatorParams.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 4/29/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import Foundation

struct CalculatorParameters: Codable {
    
    var maxTerm     : Int
    var maxWeight   : Int
    var defaultTerm : Int
    
    enum CodingKeys: String, CodingKey {
        case maxTerm        = "max_term"
        case maxWeight      = "max_weight"
        case defaultTerm    = "default_term"
    }
    
    init(from decoder: Decoder) throws {
    
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        maxTerm     = try container.decode(Int.self, forKey: .maxTerm)
        maxWeight   = try container.decode(Int.self, forKey: .maxWeight)
        defaultTerm = try container.decode(Int.self, forKey: .defaultTerm)
        
    }
    
}
