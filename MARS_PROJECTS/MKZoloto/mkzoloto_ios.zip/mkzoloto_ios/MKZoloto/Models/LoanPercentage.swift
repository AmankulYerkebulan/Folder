//
//  LoanPercentage.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 5/1/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import Foundation

struct LoanPercentage: Codable {
    
    var id      : Int
    var key     : String
    var value   : String
    
}
