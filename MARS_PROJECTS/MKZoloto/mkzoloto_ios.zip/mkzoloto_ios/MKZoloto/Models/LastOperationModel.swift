
import Foundation

struct LastOperationModel: Codable {
    
    let order: Int
    let place: String
    let date: String
    let status: String?
    let totalSum: Int
    
    let loans: [Loan]
    
    private enum CodingKeys: String, CodingKey {
        case order
        case place
        case date
        case status
        case totalSum = "total_sum"
        case loans
    }
}

struct Loan: Codable {
    
    let loanId: String?
    let amount: Int
    let operationType: String
    
    private enum CodingKeys: String, CodingKey {
        case loanId = "loan_id"
        case amount
        case operationType = "operation_type"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        self.amount = try values.decode(Int.self, forKey: .amount)
        self.operationType = try values.decode(String.self, forKey: .operationType)
        if let loanId = try? values.decode(Int.self, forKey: .loanId) {
            self.loanId = "\(loanId)"
        }else{
            self.loanId = try? values.decode(String.self, forKey: .loanId)
        }
    }
}
