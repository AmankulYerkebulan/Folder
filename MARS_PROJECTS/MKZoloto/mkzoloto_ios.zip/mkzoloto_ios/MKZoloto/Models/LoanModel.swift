
import Foundation

struct LoanOrderModel {
    var loanId: String
    var loanCount: String
    var operationType: Int
}

struct LoanModel: Codable {
    
    let user                : String
    let loanId              : Int
    let point               : String
    let point_id            : Int?
    let maxDaysExtension    : Int
    let minDaysExtension    : Int
    let overdueDays         : Int
    let city                : String
    let loanTerm            : String
    let guarantyTime        : String
    let returnTotal         : Double
    let loanPercent         : Int
    let loanBalance         : Int
    let percentDelayLoan    : Int
    let percentPay          : Int
    let minAmountPay        : Int
    let maxAmountPay        : Int
    var defaultPay          : Double
    var count               = 0
    
    var products            : [Products]
    var isCollapsed         = true
    var operationType       = 1
    
    private enum CodingKeys: String, CodingKey {
        case user
        case loanId = "loan_id"
        case point
        case maxDaysExtension = "max_days_extension"
        case minDaysExtension = "min_days_extension"
        case overdueDays = "overdue_days"
        case city
        case loanTerm = "loan_term"
        case guarantyTime = "guaranty_time"
        case returnTotal = "return_total"
        case loanPercent = "loan_percent"
        case loanBalance = "loan_balance"
        case percentDelayLoan = "percent_delay_loan"
        case percentPay = "percent_pay"
        case minAmountPay = "min_amount_pay"
        case maxAmountPay = "max_amount_pay"
        case products
        case point_id
        case defaultPay = "default_pay"
    }
    
}

struct Products: Codable {
    
    let loanId              : Int
    let itemCode            : Int
    let name                : String
    let probe               : String
    let weight              : String
    let au999content        : String
    let maxAmountDateIssue  : Int
    var isOpened            = false
    var description        : String?
    var image              : String?
    
    private enum CodingKeys: String, CodingKey {
        case loanId = "loan_id"
        case itemCode = "item_code"
        case name, probe, weight, au999content,image,description
        case maxAmountDateIssue = "max_amount_date_issue"
    }

}
