
import Foundation
import Cache

class StoreManager: NSObject {
    
    //MARK: - Variables
    
    private var storage : Storage?  //Cache manager
    
    //MARK: - Keys
    
    private let DISKCONFIGURATIONKEY    = "DISKCONFIGURATIONKEY"
    private let user                    = "USER"
    private let AUTH                    = "AUTH"
    private let accesstouchId           = "ACCESSTOUCHID"
    private let language                = "LANGUAGE"
    private let notification            = "NOTIFICATION"
    private let touchId                 = "TOUCHID"
    private let goldSample              = "GOLDSAMPLE"
    private let city                    = "CITY"
    private let firstLaunch             = "FIRSTLAUNCH"
    
    // MARK: - Public functions
    
    class func shared() -> StoreManager {
        return sharedManager
    }
    
    private static var sharedManager: StoreManager = {
        let manager = StoreManager()
        return manager
    }()
    
    //MARK: - Init
    
    private override init() {
        super.init()
        self.setupStorage()
    }
    
    func cleanCache() {
        try? self.storage?.removeAll()
    }
    
    //MARK: - Private functions
    
    private func setupStorage() {
        
        let disk = DiskConfig(name: DISKCONFIGURATIONKEY)
        let memory = MemoryConfig(expiry: .never, countLimit: 0, totalCostLimit: 0)
        storage = try! Storage(diskConfig: disk, memoryConfig: memory)
    }
    
    //MARK: - Storage functions
    
    //Auth
    func setIsAuth(bool: Bool) {
        
        try? storage?.setObject(bool, forKey: AUTH)
    }
    
    func getIsAuth() -> Bool? {
        
        if ((try? storage?.object(ofType: Bool.self, forKey: AUTH)) != nil) {
            return (try! storage?.object(ofType: Bool.self, forKey: AUTH))
        }
        return nil
    }
    
    func userAccessTouchID(iin: String,password: String) {
        try? storage?.setObject(["iin":iin,"password":password], forKey: self.accesstouchId)
    }
    
    func getUserAccessTouchId() -> [String : String]? {
        if ((try? storage?.object(ofType: [String : String].self, forKey: self.accesstouchId)) != nil) {
            return (try! (storage?.object(ofType: [String : String].self, forKey: self.accesstouchId)))
        }
        return nil
    }
    
    func isFirstLaunch() -> Bool {
        if ((try? storage?.object(ofType: Bool.self, forKey: self.firstLaunch)) != nil) {
            return (try! (storage?.object(ofType: Bool.self, forKey: self.firstLaunch) ?? false))
        }
        return false
    }
    
    func setFirsiLaunch() {
        try? storage?.setObject(true, forKey: self.firstLaunch)
    }
    
    func saveUser(user: LoginModel) {
        try? storage?.setObject(user, forKey: self.user)
    }
    
    func getUser() -> LoginModel? {
        if ((try? storage?.object(ofType: LoginModel.self, forKey: self.user)) != nil) {
            return (try! storage?.object(ofType: LoginModel.self, forKey: self.user))
        }
        return nil
    }
    
    func setLanguage(lang: LanguageModel) {
        try? storage?.setObject(lang, forKey: self.language)
    }
    
    func getLanguage() -> LanguageModel? {
        if ((try? storage?.object(ofType: LanguageModel.self, forKey: self.language)) != nil) {
            return (try! storage?.object(ofType: LanguageModel.self, forKey: self.language))
        }
        return nil
    }
    
    func setNotificationState(isTurnedOn: Bool) {
        try? storage?.setObject(isTurnedOn, forKey: self.notification)
    }
    
    func isNotificationTurnedOn() -> Bool {
        if ((try? storage?.object(ofType: Bool.self, forKey: self.notification)) != nil) {
            return (try! storage?.object(ofType: Bool.self, forKey: self.notification) ?? false)
        }
        return false
    }
    
    func setTouchIdUsable(isUsable: Bool) {
        try? storage?.setObject(isUsable, forKey: self.touchId)
    }
    
    func isTouchIdUsable() -> Bool {
        if ((try? storage?.object(ofType: Bool.self, forKey: self.touchId)) != nil) {
            return (try! storage?.object(ofType: Bool.self, forKey: self.touchId) ?? false)
        }
        return false
    }
    
    func setGoldSampleForStorage(value: GoldSampleForStorage) {
        if ((try? storage?.object(ofType: [GoldSampleForStorage].self, forKey: self.goldSample)) != nil) {
            var array = (try! storage?.object(ofType: [GoldSampleForStorage].self, forKey: self.goldSample))
            array?.append(value)
            try? storage?.setObject(array, forKey: self.goldSample)
        } else {
            try? storage?.setObject([value], forKey: self.goldSample)
        }
    }
    
    func goldSamplesForStorage() -> [GoldSampleForStorage] {
        if ((try? storage?.object(ofType: [GoldSampleForStorage].self, forKey: self.goldSample)) != nil) {
            return (try! storage?.object(ofType: [GoldSampleForStorage].self, forKey: self.goldSample) ?? [])
        }
        return []
    }
    
    func removeGoldSampleForStorage(index: Int) {
        let array = goldSamplesForStorage()
        try? storage?.removeObject(forKey: self.goldSample)
        for (_index,i) in array.enumerated() {
            if index != _index {
                self.setGoldSampleForStorage(value: i)
            }
        }
    }
    
    func setupCurrentCity(model: CityModel) {
        try? storage?.setObject(model, forKey: self.city)
    }
    
    func getCurrentCity() -> CityModel? {
        if ((try? storage?.object(ofType: CityModel.self, forKey: self.city)) != nil) {
            return (try! storage?.object(ofType: CityModel.self, forKey: self.city))
        }
        return nil
    }
        
    func removeAllGoldSamples() {
        try? storage?.removeObject(forKey: self.goldSample)
    }
    
}
