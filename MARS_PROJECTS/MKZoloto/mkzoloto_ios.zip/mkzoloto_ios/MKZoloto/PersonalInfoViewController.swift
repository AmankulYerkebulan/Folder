
import UIKit
import SnapKit

class PersonalInfoViewController: UIViewController {
    
    var personalInfoViewModel = PersonalInfoViewModel()
    
    private lazy var menuTableView: UITableView = {
        let tableView = UITableView()
        tableView.register(cellWithClass: UITableViewCell.self)
        tableView.separatorStyle = .none
        tableView.delegate   = self
        tableView.dataSource = self
        tableView.backgroundColor = Global.grey()
        tableView.isScrollEnabled = false
        return tableView
    }()
    
    private lazy var hiteLbl: UILabel = {
        let label = UILabel()
        label.font = Global.sfRegular(size: StaticSize.s12)
        label.textColor = Global.dark()
        let fullString = NSMutableAttributedString(string: "")
        let style = NSMutableParagraphStyle()
        style.alignment = NSTextAlignment.center
        let image1Attachment = NSTextAttachment()
        image1Attachment.image = UIImage(named: "key")!
        image1Attachment.bounds = CGRect(x: 0, y: -3.5, width: StaticSize.s14, height: StaticSize.s16)
        let image1String = NSAttributedString(attachment: image1Attachment)
        fullString.append(image1String)
        fullString.append(NSAttributedString(string: "  " + "Данные можно изменить только в филиалах ломбарда".localized()))
        fullString.addAttribute(.paragraphStyle, value: style, range: NSMakeRange(0, fullString.length))
        label.attributedText = fullString
        label.numberOfLines = 0
        label.contentMode = .center
        return label
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupButton()
        setConstraints()
        
        navigationItem.title = "Личные данные".localized()
        self.navigationController?.setUpShadow()
        self.personalInfoViewModel.fetchUserInfo {
            self.hiteLbl.snp.makeConstraints { (make) in
                if #available(iOS 11.0, *) {
                    make.top.equalTo(self.view.safeAreaLayoutGuide).offset(44 * CGFloat(self.personalInfoViewModel.tableData.count) + StaticSize.s16)
                } else {
                    make.top.equalTo(self.view).offset(44 * CGFloat(self.personalInfoViewModel.tableData.count) + StaticSize.s16)
                }
                make.left.equalTo(self.view.snp.left).offset(StaticSize.s23)
                make.right.equalTo(self.view.snp.right).offset(-StaticSize.s23)
            }
            self.menuTableView.reloadData()
        }
        
    }
    
}


extension PersonalInfoViewController {
    
    private func setupButton() {

        self.view.backgroundColor = .white
        self.view.addSubviews([menuTableView])
        self.view.insertSubview(hiteLbl, aboveSubview: menuTableView)
    }

    private func setConstraints() {
        menuTableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
}

extension PersonalInfoViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if (indexPath.row == 3 || indexPath.row == 4 || indexPath.row == 5) {
            let cell = UITableViewCell(style: .value1, reuseIdentifier: String(describing: UITableViewCell.self))
            cell.textLabel?.text = self.personalInfoViewModel.tableData[indexPath.row]
            cell.accessoryType = .disclosureIndicator
            cell.detailTextLabel?.textColor = Global.dark()
            cell.detailTextLabel?.font = Global.sfSemiBold(size: StaticSize.s15)
            cell.textLabel?.textColor = Global.dark()
            cell.textLabel?.font = Global.sfSemiBold(size: StaticSize.s15)
            cell.backgroundColor = Global.white()
            if indexPath.row == 3 {
                cell.textLabel?.text = "Телефон".localized()
                cell.detailTextLabel?.text = self.personalInfoViewModel.tableData[indexPath.row]
            } else if indexPath.row == 4 {
                cell.textLabel?.text = "E-mail"
                cell.detailTextLabel?.text = self.personalInfoViewModel.tableData[indexPath.row]
            } else {
                cell.textLabel?.text = "Пароль".localized()
                cell.detailTextLabel?.text = "Изменить".localized()
                cell.detailTextLabel?.textColor = Global.textFiledPlaceholderColor()
                cell.detailTextLabel?.font = Global.sfMedium(size: StaticSize.s15)
            }
            cell.accessoryView = UIImageView(image: #imageLiteral(resourceName: "Icon"))
            cell.selectionStyle = .none
            cell.setUpCellShadow()
            cell.selectionStyle = .none
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withClass: UITableViewCell.self, for: indexPath)
            cell.backgroundColor = Global.white()
            cell.textLabel?.textColor = Global.dark()
            cell.textLabel?.font = Global.sfSemiBold(size: StaticSize.s15)
            cell.textLabel?.text = self.personalInfoViewModel.tableData[indexPath.row]
            cell.accessoryView = UIImageView(image: #imageLiteral(resourceName: "key"))
            cell.selectionStyle = .none
            cell.setUpCellShadow()
            cell.selectionStyle = .none
            return cell
        }
    }

    // MARK - Настройка Header
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.personalInfoViewModel.tableData.count
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.row == 5 {
            let vc = ChangePasswordViewController()
            self.navigationController?.pushViewController(vc)
        } else if indexPath.row == 4 {
            let vc = ChangeInfoViewController()
            vc.navigationItem.title = "E-mail"
            self.navigationController?.pushViewController(vc)
        } else if indexPath.row == 3 {
            let vc = ChangeInfoViewController()
            vc.changeType = .phone
            vc.navigationItem.title = "Телефон".localized()
            self.navigationController?.pushViewController(vc)
        }
        
        
    }
    
}

