
import Alamofire
import SVProgressHUD

class PersonalInfoViewModel {
    
    var data: PersonalInfoModel?
    
    var tableData: [String] = []
    
    init() { }
    
    func fetchUserInfo(completion: @escaping () -> ()) {
        
        SVProgressHUD.show()
        
        NetworkManager.shared.makeRequest(apiRequest: .getUserInfo) { (result: Result<PersonalInfoModel>) in
            
            result.ifSuccess {
                self.data = result.value
                
                self.setTableInfo()
                
                SVProgressHUD.dismiss()
                completion()
            }
            result.ifFailure {
                SVProgressHUD.showError(withStatus: result.error?.localizedDescription ?? "Error")
            }
            
        }
        
    }
    
    private func setTableInfo() {
        
        guard let selfInfo = self.data else {
            return
        }
        
        self.tableData.append("ФИО".localized() + ": \(selfInfo.name)")
        self.tableData.append("ИИН".localized() + ": \(selfInfo.iin)")
        self.tableData.append("Дата рождения".localized() + ": \(selfInfo.birthday)")
        self.tableData.append("\(selfInfo.phone)")
        self.tableData.append("\(selfInfo.email)")
        self.tableData.append("Пароль".localized())
        
    }
    
}
