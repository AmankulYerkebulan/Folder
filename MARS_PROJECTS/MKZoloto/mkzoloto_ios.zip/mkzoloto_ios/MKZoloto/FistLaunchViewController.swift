
import UIKit
import SnapKit

class FirstLaunchViewController: UIViewController {
    
    //MAR: - Properties
    
    private var imagesArr: [String] = ["iPhone", "iPhone", "iPhone", "iPhone"]
    var sliderTitle : [String] = ["BFF", "KFC", "McDonald", "BurgerKing" ]
    
    var skipButton: UIButton!
    
    var currentPage = 0
    
    //MARK - Slider
    
    private lazy var pageController : UIPageControl = {
        let pageContr                           = UIPageControl()
        pageContr.numberOfPages                 = imagesArr.count
        pageContr.currentPage                   = 0
        pageContr.tintColor                     = .red
        pageContr.pageIndicatorTintColor        = .black
        pageContr.currentPageIndicatorTintColor = .green
        return pageContr
    }()
    
    //Белая Вьюшка на переднем плане
    private lazy var swipingCollectView : UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        layout.itemSize = CGSize(width: self.view.bounds.width, height: self.view.bounds.height)
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.scrollDirection = .horizontal
        
        let collectionView = UICollectionView(frame: self.view.frame, collectionViewLayout: layout)
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.isPagingEnabled = true
        collectionView.backgroundColor = UIColor(rgb: 0xE4F1FD)
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.contentOffset.x = 0
        collectionView.register(SwipingController.self, forCellWithReuseIdentifier: "collectionCell")
        return collectionView
    }()
    
    
    //MARK: - Lifecycles
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupButtons()
        setConstraints()
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

}

// MARK: - Setup Buttons and etc.

extension FirstLaunchViewController {
    
    func setupButtons() {
        
        skipButton = UIButton()
        skipButton.setTitle("SKIP", for: UIControl.State.normal)
        skipButton.titleLabel?.font = UIFont(name: "Avenir Next-Medium", size: 17)
        skipButton.setTitleColor(UIColor(rgb: 0x297FCA), for: .normal)
        skipButton.setTitleColor(UIColor(rgb: 0x297FCA).withAlphaComponent(0.25), for: .highlighted)
        skipButton.layer.cornerRadius = 4
        skipButton.backgroundColor = UIColor(rgb: 0x3FA2F7).withAlphaComponent(0.12)
        skipButton.addTarget(self, action: #selector(test), for: UIControl.Event.touchUpInside)
        
        // MARK - Set zPositions
        self.view.addSubviews([pageController, swipingCollectView, skipButton])

        self.view.bringSubviewToFront(swipingCollectView)
        self.view.bringSubviewToFront(pageController)
        self.view.bringSubviewToFront(skipButton)
        
    }
}

// MARK - Settings constraints

extension FirstLaunchViewController {
    
    private func setConstraints () {
        
        swipingCollectView.snp.makeConstraints { (make) in
            make.top.bottom.equalTo(self.view)
            make.left.right.equalTo(self.view)
        }
        
        skipButton.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(self.view.safeAreaLayoutGuide).offset(-16)
            } else {
                make.bottom.equalTo(self.view).offset(-16)
            }
            make.left.equalTo(self.view).offset(16)
            make.right.equalTo(self.view).offset(-16)
        }
        
        pageController.snp.makeConstraints { (make) in
            make.centerX.equalTo(self.view)
            make.bottom.equalTo(skipButton.snp.top).offset(-25)
            make.size.equalTo(CGSize(width: 53, height: 8))
        }
    }
}

// MARK - Collection View Delegate

extension FirstLaunchViewController: UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imagesArr.count
    }
    
    // MARK - Func to change position of Page Controller
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let frameWidth = scrollView.frame.width
        self.currentPage = Int((scrollView.contentOffset.x + frameWidth / 4) / frameWidth)
        self.pageController.currentPage = self.currentPage
    }
}


// MARK - CollectionView Data Source
extension FirstLaunchViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionCell", for: indexPath) as! SwipingController
        cell.setUpDetails(image: imagesArr[indexPath.row], title: sliderTitle[indexPath.row], label: "A small river named Duden flows by their place and supplies it with the necessary regelialia")
        return cell
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
}


extension FirstLaunchViewController{
    @objc private func test(sender:UIButton) {
        UserDefaults.standard.set("1", forKey: "Key")
        performSegue(withIdentifier: "launchToMain", sender: self)
    }
    
}
