
import UIKit
import Cartography

class SwipingController: UICollectionViewCell {
    
    private lazy var swipeImg: UIImageView = {
        let image = UIImageView(frame: CGRect(x: 0, y: 0, width: 0 , height: 0))
        image.contentMode = .scaleAspectFit
        return image
    }()
    
    private lazy var swipeTitle: UILabel = {
        let title = UILabel()
        title.textColor = UIColor(rgb: 0x297FCA)
        title.font = UIFont(name: "AvenirNext-Medium", size: 22)
        title.textAlignment = .center
        return title
    }()
    
    private lazy var swipeDescr: UILabel = {
        let label = UILabel()
        label.font = UIFont(name: "AvenirNext-Medium", size: 17)
        label.numberOfLines = 0
        label.textColor = UIColor(rgb: 0x297FCA)
        label.textAlignment = .center
        label.sizeToFit()
        return label
    }()
    
    private lazy var swipeView : UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("Some error")
    }
    
    override init(frame: CGRect) {
        super.init(frame:frame)
        self.setUp()

        swipeImg.layer.zPosition = -1
        swipeView.layer.zPosition = 0
        swipeTitle.layer.zPosition = 1
        swipeDescr.layer.zPosition = 1
    }
}

extension SwipingController {
    
    private func setUp() {

        self.addSubviews([self.swipeImg, self.swipeTitle, self.swipeDescr, self.swipeView])

        constrain(self.swipeImg, self.swipeTitle, self.swipeDescr, self.swipeView ) { image, title, descr, view in
            
            image.top    == image.superview!.top + 68
            image.left   == image.superview!.left + 68
            image.right  == image.superview!.right - 68
            image.bottom == image.superview!.bottom - 114
            
            view.left    == view.superview!.left
            view.right   == view.superview!.right
            view.bottom  == view.superview!.bottom
            view.height  == 264
            
            title.top    == view.top + 32
            title.left   == view.left + 8
            title.right  == view.right - 8
            title.height == 27
            
            descr.top    == title.bottom + 8
            descr.left   == view.left + 8
            descr.right  == view.right - 8
            descr.height == 72
        }
    }
    
    func setUpDetails(image: String, title: String, label: String) {
        self.swipeImg.image   = UIImage(named: image)
        self.swipeTitle.text = title
        self.swipeDescr.text = label
    }
}
