//
//  NetworkManager.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 4/15/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import UIKit
import Alamofire
import SVProgressHUD

/**
 Custom error types
 */

enum CustomError: Error {
    case errorWithDecoding
    case internalError(string: String)
    
    var errorDescription: String {
        
        switch self {
        case .errorWithDecoding:
            return "Error with decoding data"
        case .internalError(let message):
            return message
        }
    }
    
}

/**
 Class which do a requests
 */

class NetworkManager {
    
    static let shared = NetworkManager()
    
    private init() {}
    
    var golfStorage : GoldSampleForStorage?
    
    public func makeRequest<T: Codable>(apiRequest: ApiRequests, completion: @escaping (Result<T>) -> ()) {
        
        request(apiRequest.completedUrl, method: apiRequest.httpMethod, parameters: apiRequest.bodyParameters, encoding: JSONEncoding.default, headers: apiRequest.headers).responseData { (responseResult) in
            
            switch responseResult.result {
            case .failure(let error):
                completion(Result.failure(error))
                
                /// Hiding activity indicator
            //                HUD.hide(animated: true)
            case .success(let data):
                
                do {
                    /// Getting result and decoding to T generic model
                    print(apiRequest.description)
                    print(String.init(data: data, encoding: .utf8))
                    let model = try JSONDecoder().decode(MainResult<T>.self, from: data)
                    
                    if let error = model.error {
                        if responseResult.response?.statusCode == 401 {
                            
                            NotificationCenter.default.post(name: NSNotification.Name("TOKENREQUIRED"), object: nil)
                            SVProgressHUD.dismiss()
                            return
                        }
                        completion(Result.failure(CustomError.internalError(string: error)))
                    } else {
                        if let decodedData = model.data {
                            completion(Result.success(decodedData))
                        } else {
                            completion(Result.failure(CustomError.errorWithDecoding))
                        }
                    }
                    
                } catch let error {
                    
                    do {
                        let model = try JSONDecoder().decode(MainResultError<T>.self, from: data)
                        SVProgressHUD.showError(withStatus: model.error?.message)
                    } catch {
                        completion(Result.failure(error))
                    }
                }
                
            }
            
        }
        
    }
    
    /// Request method with Alamofire
    public func makeRequestWithImages<T: Codable>(apiRequest: ApiRequests, completion: @escaping (Result<T>) -> Void) {
        
        /// Showing activity indicator to top controller
        SVProgressHUD.show()
        
        upload(multipartFormData: { (multipartFormData) in
            
            /// Appending body parameters to server
            for (key, value) in apiRequest.bodyParameters ?? [:] {
                multipartFormData.append("\(value)".data(using: .utf8) ?? Data(), withName: key)
            }
            
            /// Uploading images to server
            for (key, value) in apiRequest.imageDatas ?? [:] {
                
                for (index, image) in value.enumerated() {
                    
                    multipartFormData.append(image, withName: "\(key)[\(index)]", mimeType: "image/jpg")
                    
                }
                
            }
            
            
        }, usingThreshold: UInt64(), to: apiRequest.completedUrl, method: apiRequest.httpMethod, headers: apiRequest.headers) { (response) in
            
            switch response {
            case .failure(let error):
                completion(Result.failure(error))
            case .success(let result, _, _):
                
                result.responseData(completionHandler: { (responseResult) in
                    switch responseResult.result {
                    case .failure(let error):
                        completion(Result.failure(error))
                        
                        /// Hiding activity indicator
                        SVProgressHUD.dismiss()
                    case .success(let data):
                        
                        do {
                            /// Getting result and decoding to T generic model
                            print(apiRequest.description)
                            print(String.init(data: data, encoding: .utf8))
                            let model = try JSONDecoder().decode(MainResult<T>.self, from: data)
                            
                            if let error = model.error {
                                if responseResult.response?.statusCode == 401 {
                                    
                                    NotificationCenter.default.post(name: NSNotification.Name("TOKENREQUIRED"), object: nil)
                                    
                                    SVProgressHUD.dismiss()
                                    return
                                }
                                completion(Result.failure(CustomError.internalError(string: error)))
                            } else {
                                if let decodedData = model.data {
                                    completion(Result.success(decodedData))
                                    SVProgressHUD.dismiss()
                                } else {
                                    completion(Result.failure(CustomError.errorWithDecoding))
                                }
                            }
                            
                        } catch let error {
                            completion(Result.failure(error))
                        }
                        
                    }
                })
                
            }
            
        }
        
    }
    
}

extension UIApplication {
    class func topViewController(controller: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController {
        if let navigationController = controller as? UINavigationController {
            return topViewController(controller: navigationController.visibleViewController)
        }
        if let tabController = controller as? UITabBarController {
            if let selected = tabController.selectedViewController {
                return topViewController(controller: selected)
            }
        }
        if let presented = controller?.presentedViewController {
            return topViewController(controller: presented)
        }
        return controller ?? UIViewController()
    }
}

