//
//  NetworkManager.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 4/8/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import Foundation
import Alamofire

/**
 Enum cases that contains all requests with necessary parameters and header
 For Example this request gets all commenst from specific post (postId)
 
 
 # USING EXAMPLE
 ````
 ADDING TO REQUEST CASES
 case getComments(postId: Int)
 
 SETTING INSIDE EXTENSION BEGIN
 var path: String {
     switch self {
     case .getComments(_):
        return "/comments"
     }
 }
 
 var httpMethod: HTTPMethod {
     switch self {
     case .getComments(_):
        return .get
     }
 }
 
 var urlParameters: [String : String]? {
     switch self {
     case .getComments(let postId):
        return ["postId" : "\(postId)"]
     default:
        return nil
     }
 }
 SETTING INSIDE EXTENSION BEGIN
 
 USING INSIDE CONTROLLERS
 let endPoint = ApiRequests.getComments(postId: 1)
 
 NetworkManager.shared.makeRequest(apiRequest: endPoint) { result: Result<[Test]> in
     switch result {
         case .success(let data):
            break
         case .failure(let error):
            print(error)
         }
     }
 }
 ````
 -important: **If you add a case, you should set all information about this request (path, method, parameters**)
 */
enum ApiRequests {
    
    /// case getComments(postId: Int)
    
    case getGoldSamples
    
    case getDefaultGoldSample
    
    case getCalculatorParameters
    
    case getBranches
    
    case getClosestBranches(latitude: Double, longitude: Double, limit: Int)
    
    case getBranchesByCity(city: String)
    
    case getRates
    
    case getCities
    
    case getCityByCoordinate(latitude: Double, longitude: Double)
    
    case getFaq
    
    case getMyLoans
    
    case login(iin: String, password: String)
    
    case registration(iin: String, phone: String)
    
    case smsVerification(iin: String, smsCode: String)
    
    case setPassword(phone: String, password: String)
    
    case getBanners
    
    case resendSms(iin: String, phone: String)
    
    case logout
    
    case resetPassword(iin: String,password: String)
    
    case smsVerify(code: String,iin: String)
    
    case smsVerifyWhenPhoneChanged(code: String)
    
    case setPassword(password: String,phone: String)
    
    case expressProlongation(iin: String,loadId: String)
    
    case calculation(loan_id: String, operation_type: String)
    
    case getRandomName
    
    case sendFeedback(name: String, phone: String, email: String, text: String)
    
    case getOperations
    
    case getUserInfo
    
    case purchasedItems
    
    case getMenus
    
    case changePassword(oldPassword: String, newPassword: String)
    
    case changePhoneNumber(phone: String)
    
    case changeEmail(email: String)
    
    case generateOrder(loanId: String, countDays: String)
    
    case orderPayment(orderId: String)
    
    case getPointById(id: Int)
    
    case generateLoansOrder(loans: [Parameters])

    case expresPayStatus(id: String)
    
    case getBanner
    
    case operationTypes
    
    case orderLoans(orderId: String)
    
    case orderLoanStatus(orderId: String)
    
    case calculationByFast(loan_id: String,operation_type: String)

}

/**
 Extension for the description of requests
 */
extension ApiRequests: Request {
    
    var path: String {
        switch self {
        case .getGoldSamples:
            return "/probes"
        case .getDefaultGoldSample:
            return "/default_probe"
        case .getCalculatorParameters:
            return "/calculator"
        case .getBranches:
            return "/points"
        case .getRates:
            return "/rates"
        case .getClosestBranches(_, _, _):
            return "/closestPoints"
        case .getCities:
            return "/cities"
        case .getCityByCoordinate(_):
            return "/getCityByCoordinates"
        case .getBranchesByCity(_):
            return "/getPointsByCity"
        case .getFaq:
            return "/faq"
        case .getMyLoans:
            return "/ru/auth/loans"
        case .login(_, _):
            return "/ru/auth/login"
        case .getBanners:
            return "/banners"
        case .registration:
            return "/ru/auth/register"
        case .smsVerification(_, _):
            return "/ru/auth/sms_verify"
        case .setPassword(_, _):
            return "/ru/auth/set_password"
        case .resendSms(_, _):
            return "/ru/auth/resend_sms"
        case .logout:
            return "/ru/auth/logout"
        case .resetPassword(_,_):
            return "/ru/auth/reset_password"
        case .smsVerify(_,_):
            return "/ru/auth/sms_verify"
        case .expressProlongation(_,_):
            return "/express_prolongation"
        case .calculation(_,_):
            return "/ru/auth/calculation"
        case .calculationByFast(_,_):
            return "/ru/auth/exp_calculation"
        case .getRandomName:
            return "/random_name"
        case .sendFeedback(_, _, _, _):
            return "/feedback"
        case .getOperations:
            return "/ru/auth/operations"
        case .getUserInfo:
            return "/ru/auth/me"
        case .purchasedItems:
            return "/ru/auth/purchased_item"
        case .getMenus:
            return "/menus"
        case .changePassword(_, _):
            return "/ru/auth/password_change"
        case .changePhoneNumber:
            return "/ru/auth/change_phone"
        case .changeEmail:
            return "/ru/auth/change_email"
        case .generateOrder:
            return "/ru/auth/generate_order"
        case .getPointById(_):
            return "/getPointById"
        case .orderPayment:
            return "/express_pay"
        case .generateLoansOrder:
            return "/ru/auth/regular_pay_order"
        case .smsVerifyWhenPhoneChanged:
            return "/ru/auth/phone_verification"
        case .expresPayStatus(_):
            return "/exp_pay_status"
        case .getBanner:
            return "/banners"
        case .operationTypes:
            return "/operation_types"
        case .orderLoans:
            return "/ru/auth/req_pay"
        case .orderLoanStatus:
            return "/ru/auth/reg_pay_status"
        }
    }
    
    var httpMethod: HTTPMethod {
        switch self {
        case .getGoldSamples,
             .getDefaultGoldSample,
             .getCalculatorParameters,
             .getBranches,
             .getRates,
             .getCities,
             .getFaq,
             .getMyLoans,
             .getBanners,
             .getRandomName,
             .getOperations,
             .purchasedItems,
             .getMenus,
             .getBanner,
             .operationTypes:
            return .get
        default:
            return .post
        }
    }
    
    
    var bodyParameters: Parameters? {
        switch self {
        case .getClosestBranches(let latitude, let longitude, let limit):
            return [
                "lat" : latitude,
                "lng" : longitude,
                "limit" : limit
            ]
        case .getCityByCoordinate(let latitude, let longitude):
            return [
                "lat" : latitude,
                "lng" : longitude
            ]
        case .getBranchesByCity(let city):
            return [
                "city" : city
            ]
        case .login(let iin, let password) :
            return [
                "iin" : iin,
                "password" : password
            ]
        case .registration(let iin, let phone), .resendSms(let iin, let phone), .resetPassword(let iin , let phone):

            return [
                "iin" : iin,
                "phone" : phone
            ]
        case .smsVerification(let iin, let smsCode):
            return [
                "iin"       : iin,
                "sms_code"  : smsCode
            ]
        case .setPassword(let password, let phone):
            return [
                "phone"     : phone,
                "password"  : password
            ]
        case .smsVerify(let code,let iin):
            return [
                "iin"       : iin,
                "sms_code"  : code
            ]
        case .expressProlongation(let iin,let loadId):
            return [
                "iin"       : iin,
                "loan_id"   : loadId
            ]
        case .calculation(let loan_id, let operation_type):
            return [
                "loan_id"           : loan_id,
                "operation_type"    : operation_type
            ]
        case .calculationByFast(let loan_id,let operation_type):
            return [
                "loan_id"           : loan_id,
                "operation_type"    : operation_type
            ]
        case .sendFeedback(let name, let phone, let email, let text):
            return [
                "name"  : name,
                "phone" : phone,
                "email" : email,
                "text"  : text
            ]
        case .changePassword(let oldPassword, let newPassword):
            return [
                "old_pwd" : oldPassword,
                "new_pwd" : newPassword
            ]
        case .changeEmail(let email):
            return [
                "new_mail" : email
            ]
        case .changePhoneNumber(let phone):
            return [
                "new_phone" : phone
            ]
        case .generateOrder(let loanId, let countDays):
            return [
                "loan_id" : loanId,
                "count_days" : countDays
            ]
        case .getPointById(let id):
            return ["point_id":"\(id)"]
        case .orderPayment(let orderId), .orderLoans(let orderId):
            return [
                "order_id" : orderId
            ]
        case .generateLoansOrder(let loans):
            return [
                "loans" : loans
            ]
        case .smsVerifyWhenPhoneChanged(let code):
            return [
                "sms_code" : code
            ]
        case .expresPayStatus(let id), .orderLoanStatus(let id):
            return ["order":id]
        default:
            return nil
        }
    }
    
    var urlParameters: [String : String]? {
        switch self {
        default:
            return nil
        }
    }
    
}
