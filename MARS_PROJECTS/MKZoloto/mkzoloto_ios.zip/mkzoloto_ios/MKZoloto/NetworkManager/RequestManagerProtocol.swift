//
//  NetworkManagerProtocol.swift
//  MKZoloto
//
//  Created by Нуржан Орманали on 4/15/19.
//  Copyright © 2019 Нуржан Орманали. All rights reserved.
//

import Alamofire

/**
 Main protocol to requests
 */
protocol Request {
    /// Base url for API
    var baseUrl:        URL         { get }
    /// Paths for base url
    var path:           String      { get }
    /// Url combined with base, path and url parameters
    var completedUrl:   URL         { get }
    /// Method of the request (.get, .post, .delete)
    var httpMethod:     HTTPMethod  { get }
    /// Body parameters for request
    var bodyParameters: Parameters? { get }
    /// Url Parameters for request
    var urlParameters:  [String : String]?  { get }
    /// Images that uploading to server
    var imageDatas:     [String : [Data]]?  { get }
    /// Headers for request
    var headers:        HTTPHeaders?        { get }
}
