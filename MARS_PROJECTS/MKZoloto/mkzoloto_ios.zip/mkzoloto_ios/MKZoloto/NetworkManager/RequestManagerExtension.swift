
import Alamofire

/// Immutable types
/// Change properties if needed

extension ApiRequests {
    
    var baseUrl: URL {
        
//        let languageModel = StoreManager.shared().getLanguage()
//        let lang = languageModel?.language ?? "ru"
        
        return URL(string: "https://mk-backend.mars.studio/api") ?? URL(fileURLWithPath: "")
    }
    
    var completedUrl: URL {
        
        var url = baseUrl.appendingPathComponent(path)
        
        url = url.appendingQueryParameters(urlParameters ?? [:])
        
        return url
        
    }
    
    var imageDatas: [String : [Data]]? {
        switch self {
        default:
            return nil
        }
    }
    
    var headers: HTTPHeaders? {
        
        switch self {
        case .logout, .getMyLoans, .getOperations, .getUserInfo, .purchasedItems, .changePassword, .changeEmail, .generateOrder, .changePhoneNumber, .generateLoansOrder, .smsVerifyWhenPhoneChanged, .orderLoans, .orderLoanStatus:
            let userTockek = StoreManager.shared().getUser()?.accessToken
            return ["Authorization":"Bearer \(userTockek ?? "")"]
        default:
            return nil
        }
    }
    
    var description: String {
        
        return """
        Completed URL:      \(self.completedUrl)
        HTTP Method:        \(self.httpMethod)
        Body Parameters:    \(String(describing: self.bodyParameters))
        Headers:            \(String(describing: self.headers))
        """
    }
    
}
