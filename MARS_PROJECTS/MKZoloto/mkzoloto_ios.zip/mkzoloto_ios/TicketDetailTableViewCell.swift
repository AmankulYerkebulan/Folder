
import UIKit
import SnapKit

class TicketDetailTableViewCell: UITableViewCell {
    
    private lazy var imagee: UIImageView = {
        let image = UIImageView()
        image.layer.cornerRadius = 4
        return image
    }()
    
    private lazy var data: UILabel = {
        let label = UILabel()
        label.label15Properties()
        return label
    }()
    
    private lazy var justLabel: UILabel = {
        let label = UILabel()
        label.text = "Продление"
        label.label13Properties()
        return label
    }()
    
    private lazy var summa: UILabel = {
        let label = UILabel()
        label.label13Properties()
        return label
    }()
    
    private lazy var address: UILabel = {
        let label = UILabel()
        label.numberOfLines = 2
        label.lineBreakMode = .byWordWrapping
        label.label13Properties()
        return label
    }()
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("Some error")
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.setUp()
    }
}


extension TicketDetailTableViewCell {
    
    private func setUp() {
        
        self.addSubviews([imagee, data, justLabel, summa, address])

        imagee.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(20)
            make.left.equalToSuperview().offset(16)
            make.height.width.equalTo(24)
        }
        
        data.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.left.equalTo(imagee.snp.right).offset(20)
            make.right.equalToSuperview().offset(-16)
            make.height.equalTo(18)
        }
        
        justLabel.snp.makeConstraints { (make) in
            make.top.equalTo(data.snp.bottom).offset(6)
            make.left.equalTo(imagee.snp.right).offset(20)
            make.height.equalTo(15)
            make.right.equalTo(data)
        }
        
        summa.snp.makeConstraints { (make) in
            make.top.equalTo(justLabel.snp.bottom).offset(6)
            make.left.equalTo(imagee.snp.right).offset(20)
            make.right.equalTo(data.snp.right)
            make.height.equalTo(15)
        }
        
        address.snp.makeConstraints { (make) in
            make.top.equalTo(summa.snp.bottom).offset(4)
            make.left.equalTo(imagee.snp.right).offset(20)
            make.right.equalTo(data)
            make.bottom.equalToSuperview().offset(-16)
        }
        
    }
    
    func setUpDetails(image: String, title: String, secondTitle: String, thirdTitle : String) {
        self.imagee.image   = UIImage(named: image)
        self.data.text    = title
        self.summa.text = secondTitle
        self.address.text = thirdTitle
    }
}





